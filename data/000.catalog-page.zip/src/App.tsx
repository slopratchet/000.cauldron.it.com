/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Header from './components/Header';
import CatalogList from './components/CatalogList';
import ArtifactViewer from './components/ArtifactViewer';
import Footer from './components/Footer';
import MobileNav from './components/MobileNav';

export default function App() {
  return (
    <div className="parchment-texture text-on-surface selection:bg-primary selection:text-on-primary min-h-screen flex flex-col">
      <Header />
      <div className="flex flex-1 relative">
        <main className="flex-1 p-margin-edge overflow-y-auto custom-scrollbar">
          <div className="flex flex-col h-full">
            <div className="mb-gutter-md flex items-center gap-2 text-label-mono font-label-mono text-primary/50">
              <span>ROOT</span> / <span>ARCHIVES</span> / <span className="text-primary font-bold">CATALOG_VIEW</span>
            </div>
            
            <div className="flex flex-1 gap-gutter-md overflow-hidden">
              <CatalogList />
              <ArtifactViewer />
            </div>
          </div>
        </main>
      </div>
      <Footer />
      <MobileNav />
    </div>
  );
}

