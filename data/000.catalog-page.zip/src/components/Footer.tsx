export default function Footer() {
  return (
    <footer className="w-full flex justify-between items-center px-margin-edge py-2 bg-primary text-on-primary z-50">
      <div className="text-label-mono font-label-mono font-bold">
        © 1974 SYSTEM_70_CORE // VER_4.2.1
      </div>
      <div className="flex gap-4">
        <a className="text-label-mono font-label-mono text-on-primary/70 hover:text-on-primary transition-colors" href="#">DATA_SAFETY</a>
        <a className="text-label-mono font-label-mono text-on-primary/70 hover:text-on-primary transition-colors" href="#">PROTOCOL_V</a>
      </div>
    </footer>
  );
}
