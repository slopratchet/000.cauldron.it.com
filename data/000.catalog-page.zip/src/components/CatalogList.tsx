export default function CatalogList() {
  const specimens = [
    { index: '013', status: 'ACTIVE', active: true },
    { index: '012', status: 'STABLE', active: false },
    { index: '011', status: 'VOLATILE', active: false, error: true },
    { index: '010', status: 'STABLE', active: false },
    { index: '009', status: 'SECURED', active: false },
  ];

  return (
    <div className="w-1/3 flex flex-col border-thick border-primary bg-surface overflow-hidden hover:translate-x-[1px] hover:translate-y-[1px] transition-transform">
      <div className="p-2 bg-primary text-on-primary font-label-mono text-[10px] flex justify-between">
        <span>CATALOG_INDEX</span>
        <span>TOTAL_ENTRIES: 13</span>
      </div>
      <div className="flex-1 overflow-y-auto custom-scrollbar">
        {specimens.map((specimen, idx) => {
          if (specimen.active) {
            return (
              <div key={idx} className="p-4 border-b border-primary bg-secondary-container flex justify-between items-center cursor-pointer hover:translate-x-[1px] hover:translate-y-[1px] transition-transform">
                <div className="flex flex-col">
                  <span className="font-label-mono text-xs text-primary/60 italic">INDEX_{specimen.index}</span>
                  <span className="font-headline-md">SPECIMEN_{specimen.index}</span>
                </div>
                <span className="text-[10px] font-label-mono bg-primary text-on-primary px-2 py-0.5">
                  {specimen.status}
                </span>
              </div>
            );
          }

          return (
            <div key={idx} className="p-4 border-b border-primary hover:bg-surface-container transition-all flex justify-between items-center cursor-pointer group hover:translate-x-[1px] hover:translate-y-[1px]">
              <div className="flex flex-col">
                <span className="font-label-mono text-xs text-primary/60">INDEX_{specimen.index}</span>
                <span className="font-headline-md group-hover:underline">SPECIMEN_{specimen.index}</span>
              </div>
              <span className={`text-[10px] font-label-mono px-2 py-0.5 border ${specimen.error ? 'border-error text-error' : 'border-primary'}`}>
                {specimen.status}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
