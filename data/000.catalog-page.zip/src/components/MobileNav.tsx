export default function MobileNav() {
  return (
    <nav className="md:hidden fixed bottom-0 left-0 w-full bg-surface border-t-border-thick border-primary flex justify-around py-3 z-50">
      <button className="flex flex-col items-center gap-1 text-primary">
        <span className="material-symbols-outlined">dashboard</span>
        <span className="text-[10px] font-label-mono">DASH</span>
      </button>
      <button className="flex flex-col items-center gap-1 text-primary">
        <span className="material-symbols-outlined">search</span>
        <span className="text-[10px] font-label-mono">EXPLORE</span>
      </button>
      <button className="flex flex-col items-center gap-1 text-on-primary bg-primary px-4 py-1">
        <span className="material-symbols-outlined">auto_stories</span>
        <span className="text-[10px] font-label-mono">TOME</span>
      </button>
      <button className="flex flex-col items-center gap-1 text-primary">
        <span className="material-symbols-outlined">person</span>
        <span className="text-[10px] font-label-mono">UNIT</span>
      </button>
    </nav>
  );
}
