export default function Header() {
  return (
    <header className="flex justify-between items-center w-full px-margin-edge py-4 max-w-full border-b-border-thick border-primary bg-surface z-50 sticky top-0">
      <div className="text-headline-md font-headline-md font-black text-primary uppercase tracking-tighter">CHRONOS SYSTEMS // ARTIFACT DIRECTORY</div>
      <nav className="hidden md:flex gap-gutter-md">
        <a className="text-primary hover:underline decoration-border-thick text-label-mono font-label-mono px-2 py-1 transition-colors duration-75" href="#">DASHBOARD</a>
        <a className="text-primary hover:underline decoration-border-thick text-label-mono font-label-mono px-2 py-1 transition-colors duration-75" href="#">ROSTER</a>
        <a className="text-on-primary bg-primary text-label-mono font-label-mono px-2 py-1 translate-y-0.5" href="#">ARCHIVES</a>
        <a className="text-primary hover:underline decoration-border-thick text-label-mono font-label-mono px-2 py-1 transition-colors duration-75" href="#">SYSTEM</a>
      </nav>
      <div className="flex items-center gap-4">
        <button className="material-symbols-outlined text-primary hover:bg-primary hover:text-on-primary transition-colors p-1">settings</button>
        <button className="material-symbols-outlined text-primary hover:bg-primary hover:text-on-primary transition-colors p-1">terminal</button>
      </div>
    </header>
  );
}
