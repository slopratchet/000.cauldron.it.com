import { useEffect, useState } from 'react';

const Typist = ({ text, delay = 30 }: { text: string, delay?: number }) => {
  const [displayed, setDisplayed] = useState('_');
  
  useEffect(() => {
    let i = 0;
    setDisplayed('_');
    const interval = setInterval(() => {
      if (i < text.length) {
        setDisplayed(text.substring(0, i + 1) + '_');
        i++;
      } else {
        setDisplayed(text);
        clearInterval(interval);
      }
    }, delay);
    return () => clearInterval(interval);
  }, [text, delay]);

  return <span>{displayed}</span>;
};

export default function ArtifactViewer() {
  return (
    <div className="w-2/3 flex flex-col gap-gutter-md overflow-y-auto custom-scrollbar pr-2">
      <div className="grid grid-cols-1 gap-gutter-md">
        
        {/* Hero Detail */}
        <div className="border-thick border-primary bg-black p-1 relative overflow-hidden hover:translate-x-[1px] hover:translate-y-[1px] transition-transform">
          <div className="absolute top-0 left-0 bg-primary text-on-primary px-3 py-1 z-10 text-label-mono font-label-mono">
            SELECTED_ARTIFACT_VISUAL
          </div>
          <img 
            alt="Accursed Artifact Crown" 
            className="w-full h-64 object-cover grayscale brightness-110 contrast-125 block" 
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuA2Nz9Udmiell8wnkV7FV0uWy6f7PXDZdYNgIgZH0NfrQWuzCR0i9wknWNX8VpjUo4P1HtUnQnCAf-MRJ6XuVXVtqRbP5Nm5nFoIeZ_tkjqHDBEvy30CtO4W_86tdyFHoLVU4ZVOzycC8UytUwDfo-ZbHXDpWgFSgXFUx6bXgzypGAGwF8rZ7D0ZKURwsCDX9qdZWiV3pcBz5wx-Ck93qzRTUJYC87pYetDza5gL5I57c8TX290-HkhZj5kn0aN_eVkyk3QAFyWak0B"
          />
        </div>

        {/* Detail Panels */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-gutter-md">
          <div className="space-y-gutter-md">
            <div className="border-thick border-primary p-gutter-md bg-surface relative hover:translate-x-[1px] hover:translate-y-[1px] transition-transform">
              <div className="absolute -top-3 left-4 bg-primary text-on-primary px-2 py-1 text-label-mono font-label-mono text-[10px]">OBJECT_ID</div>
              <h1 className="font-headline-lg text-headline-md uppercase leading-none mb-1">ACCURSED ARTIFACT</h1>
              <p className="font-label-mono text-label-mono text-primary/60 tracking-widest">SPECIMEN NO. 013</p>
            </div>
            <div className="border-thin border-primary bg-surface-container overflow-hidden hover:translate-x-[1px] hover:translate-y-[1px] transition-transform">
              <table className="w-full text-left font-data-table text-[12px]">
                <thead><tr className="bg-secondary-container"><th className="p-1 border-r border-primary/20">PARAM</th><th className="p-1">VAL</th></tr></thead>
                <tbody>
                  <tr className="border-b border-primary/10"><td className="p-1 border-r border-primary/20 bg-surface">RARITY</td><td className="p-1"><Typist text="0.0031%" /></td></tr>
                  <tr className="border-b border-primary/10"><td className="p-1 border-r border-primary/20 bg-surface">SOURCE</td><td className="p-1"><Typist text="VOID_KING" /></td></tr>
                  <tr><td className="p-1 border-r border-primary/20 bg-surface">BIND</td><td className="p-1"><Typist text="SOUL_LNK" /></td></tr>
                </tbody>
              </table>
            </div>
          </div>
          <div className="border-thick border-primary p-gutter-md relative bg-surface-container-lowest hover:translate-x-[1px] hover:translate-y-[1px] transition-transform">
            <div className="absolute -top-3 left-4 bg-primary text-on-primary px-2 py-1 text-label-mono font-label-mono text-[10px]">ARCHIVAL_LORE</div>
            <p className="font-body-md text-xs italic leading-relaxed">
              "The iron of the crown was forged not in fire, but in the silence of the spaces between stars. To wear it is to hear the collective whispers of the 13th dynasty."
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
