/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// API route to generate custom retro RPG character dossiers securely via Gemini 3.5 Flash
app.post("/api/records/generate", async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt) {
      res.status(400).json({ error: "Missing prompt parameter" });
      return;
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      res.status(500).json({
        error: "GEMINI_API_KEY environment variable is not configured. Please add it to your secrets panel.",
      });
      return;
    }

    // Lazy initialization of Gemini client to prevent load-time crash
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `Create a comprehensive D&D 5e / tabletop RPG character data block conforming exactly to the requested concept: "${prompt}".
Store it in the Chronos Systems Interface / Elden Records.
The response must reflect a retro-futuristic data-scan layout. Incorporate detailed stats, equipment, slots, level log, and lore.`,
      config: {
        systemInstruction: "You are the Chronos Records terminal engine of Elden Records. You generate highly thematic D&D character scanned files in valid JSON matching the schema precisely. Make sure to generate detailed, lore-friendly content that matches the retro printed RPG terminal vibe.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            meta: {
              type: Type.OBJECT,
              properties: {
                character_id: { type: Type.STRING, description: "A unique slug, e.g. custom_uuid_xxxx" },
                user_id: { type: Type.STRING, description: "Lower-cased technical analyst ID, e.g. usr_analyst_xx" },
                schemaVersion: { type: Type.STRING, description: "Schema tracking code, e.g. 5.1" },
                active_sources: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "Active books like ['SRD', 'PHB2024']"
                },
                createdAt: { type: Type.STRING, description: "ISO timestamp format" },
                updatedAt: { type: Type.STRING, description: "ISO timestamp format" }
              },
              required: ["character_id", "user_id", "schemaVersion", "active_sources", "createdAt", "updatedAt"]
            },
            identity: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING, description: "Name of character, e.g. Elias Thorne" },
                alignment: { type: Type.STRING, description: "Lawful Good, Neutral, etc" },
                background: { type: Type.STRING, description: "D&D background, e.g. Outlander" },
                species: { type: Type.STRING, description: "E.g. Human, Gnome, Elf, Tiefling" }
              },
              required: ["name", "alignment", "background", "species"]
            },
            description: {
              type: Type.OBJECT,
              properties: {
                age: { type: Type.INTEGER, description: "Age in cycles" },
                height: { type: Type.STRING },
                weight: { type: Type.STRING },
                eyes: { type: Type.STRING },
                skin: { type: Type.STRING },
                hair: { type: Type.STRING }
              },
              required: ["age", "height", "weight", "eyes", "skin", "hair"]
            },
            personality: {
              type: Type.OBJECT,
              properties: {
                traits: { type: Type.STRING },
                ideals: { type: Type.STRING },
                bonds: { type: Type.STRING },
                flaws: { type: Type.STRING }
              },
              required: ["traits", "ideals", "bonds", "flaws"]
            },
            notes: { type: Type.STRING, description: "Atmospheric logs scanning bios and legends of deep marsh / universe contexts in 3-4 professional sentences." },
            definition: {
              type: Type.OBJECT,
              properties: {
                abilityScoreGeneration: {
                  type: Type.OBJECT,
                  properties: {
                    method: { type: Type.STRING, description: "PointBuy or StandardArray" },
                    scores: {
                      type: Type.OBJECT,
                      properties: {
                        Strength: { type: Type.INTEGER },
                        Dexterity: { type: Type.INTEGER },
                        Constitution: { type: Type.INTEGER },
                        Intelligence: { type: Type.INTEGER },
                        Wisdom: { type: Type.INTEGER },
                        Charisma: { type: Type.INTEGER }
                      },
                      required: ["Strength", "Dexterity", "Constitution", "Intelligence", "Wisdom", "Charisma"]
                    }
                  },
                  required: ["method", "scores"]
                },
                levelProgression: {
                  type: Type.OBJECT,
                  description: "Object with keys mapping 1 to 20 to Class level progressions."
                }
              },
              required: ["abilityScoreGeneration", "levelProgression"]
            },
            proficiencies: {
              type: Type.OBJECT,
              properties: {
                skills: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING },
                      source: { type: Type.STRING },
                      modifier: { type: Type.STRING, description: "expertise or proficient" }
                    },
                    required: ["name", "source", "modifier"]
                  }
                },
                saving_throws: { type: Type.ARRAY, items: { type: Type.STRING } },
                armor: { type: Type.ARRAY, items: { type: Type.STRING } },
                weapons: { type: Type.ARRAY, items: { type: Type.STRING } },
                tools: { type: Type.ARRAY, items: { type: Type.STRING } },
                languages: { type: Type.ARRAY, items: { type: Type.STRING } }
              },
              required: ["skills", "saving_throws", "armor", "weapons", "tools", "languages"]
            },
            spellcasting: {
              type: Type.OBJECT,
              properties: {
                sources: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      source: { type: Type.STRING, description: "e.g. Class: Bard" },
                      ability: { type: Type.STRING, description: "Charisma" },
                      cantrips: { type: Type.ARRAY, items: { type: Type.STRING } },
                      known_spells: { type: Type.ARRAY, items: { type: Type.STRING } }
                    },
                    required: ["source", "ability", "cantrips", "known_spells"]
                  }
                }
              },
              required: ["sources"]
            },
            currentState: {
              type: Type.OBJECT,
              properties: {
                xp: { type: Type.INTEGER },
                currentHp: { type: Type.INTEGER },
                temporaryHp: { type: Type.INTEGER },
                usedHitDice: {
                  type: Type.OBJECT,
                  properties: {
                    d8: { type: Type.INTEGER, description: "Used d8 count" },
                    d6: { type: Type.INTEGER, description: "Used d6 count" }
                  }
                },
                deathSaves: {
                  type: Type.OBJECT,
                  properties: {
                    successes: { type: Type.INTEGER },
                    failures: { type: Type.INTEGER }
                  },
                  required: ["successes", "failures"]
                },
                conditions: { type: Type.ARRAY, items: { type: Type.STRING } },
                exhaustionLevel: { type: Type.INTEGER },
                inspiration: { type: Type.BOOLEAN },
                activeEffects: { type: Type.ARRAY, items: { type: Type.STRING } },
                usedResources: {
                  type: Type.OBJECT,
                  description: "Resources tracker, e.g. {'Sorcery Points': 0}"
                },
                usedSpellSlots: {
                  type: Type.OBJECT,
                  properties: {
                    level_1: { type: Type.INTEGER },
                    level_2: { type: Type.INTEGER },
                    level_3: { type: Type.INTEGER },
                    level_4: { type: Type.INTEGER },
                    level_5: { type: Type.INTEGER },
                    level_6: { type: Type.INTEGER },
                    level_7: { type: Type.INTEGER },
                    level_8: { type: Type.INTEGER },
                    level_9: { type: Type.INTEGER }
                  },
                  required: ["level_1", "level_2", "level_3", "level_4", "level_5", "level_6", "level_7", "level_8", "level_9"]
                },
                usedItemCharges: {
                  type: Type.OBJECT,
                  description: "Object mapping uuid keys to used integer charges"
                },
                inventory: {
                  type: Type.OBJECT,
                  properties: {
                    currency: {
                      type: Type.OBJECT,
                      properties: {
                        cp: { type: Type.INTEGER },
                        sp: { type: Type.INTEGER },
                        gp: { type: Type.INTEGER },
                        pp: { type: Type.INTEGER }
                      },
                      required: ["cp", "sp", "gp", "pp"]
                    },
                    items: {
                      type: Type.OBJECT,
                      description: "Object mapping uuid string keys to Item objects"
                    },
                    loadout: {
                      type: Type.OBJECT,
                      properties: {
                        worn: { type: Type.ARRAY, items: { type: Type.STRING } },
                        held: {
                          type: Type.OBJECT,
                          properties: {
                            main_hand: { type: Type.STRING },
                            off_hand: { type: Type.STRING }
                          },
                          required: ["main_hand", "off_hand"]
                        },
                        attuned_items: { type: Type.ARRAY, items: { type: Type.STRING } }
                      },
                      required: ["worn", "held", "attuned_items"]
                    }
                  },
                  required: ["currency", "items", "loadout"]
                }
              },
              required: [
                "xp",
                "currentHp",
                "temporaryHp",
                "deathSaves",
                "conditions",
                "exhaustionLevel",
                "inspiration",
                "activeEffects",
                "usedResources",
                "usedSpellSlots",
                "inventory"
              ]
            }
          },
          required: [
            "meta",
            "identity",
            "description",
            "personality",
            "notes",
            "definition",
            "proficiencies",
            "spellcasting",
            "currentState"
          ]
        },
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response generated from Gemini models.");
    }

    const cleanedText = text.trim();
    const resultJson = JSON.parse(cleanedText);
    res.json(resultJson);
  } catch (error: any) {
    console.error("Gemini Scan Generation Failure:", error);
    res.status(500).json({ error: error.message || "Unknown proxy error" });
  }
});

// Configure Vite integration for dev vs prod running states
const startServer = async () => {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Chronos Hub] Server locked on port ${PORT}`);
  });
};

startServer();
