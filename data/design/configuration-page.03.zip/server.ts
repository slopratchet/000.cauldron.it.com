import express from "express";
import path from "path";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";
import { initialEntries } from "./src/initialData.js";
import { TomeEntry } from "./src/types.js";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// In-Memory REST API Database Store initialized with initial entries
let databaseStore: TomeEntry[] = [...initialEntries];

// REST API: Get Full JSON Database Object
app.get("/api/database", (req, res) => {
  const worldsAndSessions = databaseStore.filter(
    (e) => e.type === "class" || (e.type === "spell" && !!e.parentWorldId)
  );
  const adventuresOfTheVoid = databaseStore.filter((e) => e.type === "beast");
  const ancientEncounters = databaseStore.filter((e) => e.type === "relic");

  res.json({
    databaseInfo: {
      title: "The Tome 1970 Edition - Master JSON Database",
      status: "connected",
      recordCount: databaseStore.length,
      lastUpdated: new Date().toISOString(),
    },
    sections: {
      "01_campaign_worlds_and_sessions": {
        title: "01. Campaign Worlds & Active Sessions",
        count: worldsAndSessions.length,
        data: worldsAndSessions,
      },
      "03_adventures_of_the_void": {
        title: "03. Adventures of the Void",
        count: adventuresOfTheVoid.length,
        data: adventuresOfTheVoid,
      },
      "04_ancient_encounters": {
        title: "04. Ancient Encounters",
        count: ancientEncounters.length,
        data: ancientEncounters,
      },
    },
    allEntries: databaseStore,
  });
});

// REST API: Get All Entries (with optional ?type= or ?section= filter)
app.get("/api/entries", (req, res) => {
  const { type, section } = req.query;

  let results = [...databaseStore];

  if (type) {
    results = results.filter((e) => e.type === type);
  }

  if (section === "01") {
    results = results.filter((e) => e.type === "class" || (e.type === "spell" && !!e.parentWorldId));
  } else if (section === "03") {
    results = results.filter((e) => e.type === "beast");
  } else if (section === "04") {
    results = results.filter((e) => e.type === "relic");
  }

  res.json({
    count: results.length,
    entries: results,
  });
});

// REST API: Get Single Entry by ID
app.get("/api/entries/:id", (req, res) => {
  const entry = databaseStore.find((e) => e.id === req.params.id);
  if (!entry) {
    return res.status(404).json({ error: "Entry not found in JSON database." });
  }
  res.json(entry);
});

// REST API: Create New Entry (Scribed or Cloned Campaign)
app.post("/api/entries", (req, res) => {
  const newEntry: TomeEntry = req.body;
  if (!newEntry.name || !newEntry.type) {
    return res.status(400).json({ error: "Name and type are required." });
  }
  if (!newEntry.id) {
    newEntry.id = `${newEntry.type}-${Date.now()}`;
  }
  databaseStore.unshift(newEntry);
  res.status(201).json({
    message: "Entry created successfully in JSON database.",
    entry: newEntry,
  });
});

// REST API: Update Existing Entry (e.g., Edit World parameters or status)
app.put("/api/entries/:id", (req, res) => {
  const index = databaseStore.findIndex((e) => e.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: "Entry not found in JSON database." });
  }
  databaseStore[index] = { ...databaseStore[index], ...req.body };
  res.json({
    message: "Entry updated successfully in JSON database.",
    entry: databaseStore[index],
  });
});

// REST API: Delete Entry
app.delete("/api/entries/:id", (req, res) => {
  const index = databaseStore.findIndex((e) => e.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: "Entry not found in JSON database." });
  }
  const deleted = databaseStore.splice(index, 1)[0];
  res.json({
    message: "Entry deleted from JSON database.",
    id: deleted.id,
  });
});

// REST API: Reset Database to Seed State
app.post("/api/database/reset", (req, res) => {
  databaseStore = [...initialEntries];
  res.json({ message: "Database reset to initial seed state.", count: databaseStore.length });
});

// Initialize Gemini SDK server-side only
const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    })
  : null;

// API endpoint to scribe a new entry using Gemini AI
app.post("/api/scribe/generate", async (req, res) => {
  try {
    const { type, prompt } = req.body;

    if (!type || !prompt) {
      return res.status(400).json({ error: "Type and prompt are required." });
    }

    if (!ai) {
      return res.status(503).json({
        error:
          "Gemini API key is not configured on the server. Please add GEMINI_API_KEY in the Secrets / Environment variables panel.",
      });
    }

    const typeLabel =
      type === "class"
        ? "Character Class"
        : type === "spell"
          ? "Grimoire Spell"
          : type === "beast"
            ? "Void Beast"
            : "Relic Artifact";

    const systemInstruction = `You are a legendary, archaic 1970s tabletop RPG writer and dark fantasy cartographer of "The Tome: 1970 Edition", a manual cataloging heretical character classes, spells, void beasts, and ancient relics.
Your writing style is highly poetic, slightly creepy, theatrical, archaic, and deeply evocative (reminiscent of EB Garamond TTRPG style from 1974).
Provide a brand new entry in JSON format for a ${typeLabel} based on the user's prompt. Make it fit the vintage 1970s dark fantasy tone.

For Character Classes: should have a pageRef (between 100-199).
For Spells: should have a pageRef (between 200-399) and a level (e.g. "LVL: I", "LVL: IV").
For Beasts: should have a pageRef (between 400-599) and a challenge rating (e.g. "CR: 15", "CR: 5").
For Relics: should have a pageRef (between 600-799) and a rarity (e.g. "RARITY: ARCHEO", "RARITY: FORBIDDEN").

Each entry must also include 2-3 mechanical Game Actions with dice rolling formulas (e.g. d20, d10, d6) that a player can trigger. For example:
- "Void Strike: Roll 2d10 + 4 psychic damage"
- "Summon Husk: Roll 1d6 for number of minor shadows summoned"
- "Check Resolve: Roll d20 + Wisdom to withstand cosmic dread"`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `Generate a new heretical ${typeLabel} inspired by: "${prompt}"`,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["name", "description", "pageRef", "flavorText", "expandedLore", "actions"],
          properties: {
            name: {
              type: Type.STRING,
              description: "The dark, evocative name of the entry (e.g., Blood Siphon, Crypt Warden)",
            },
            description: {
              type: Type.STRING,
              description: "A short, dense, justified-slab paragraph (2-3 sentences) summarizing its origin or mechanism in archaic prose.",
            },
            pageRef: {
              type: Type.STRING,
              description: "The page reference matching the range (e.g., PAGE 142)",
            },
            level: {
              type: Type.STRING,
              description: "For Spells only. Roman numerals (e.g., LVL: IV).",
            },
            cr: {
              type: Type.STRING,
              description: "For Beasts only. Challenge rating level (e.g., CR: 18).",
            },
            rarity: {
              type: Type.STRING,
              description: "For Relics only. Ancient rarity classification (e.g., RARITY: UNHOLY).",
            },
            flavorText: {
              type: Type.STRING,
              description: "A deeply flavor-rich quote or heretical text from an ancient scholar.",
            },
            expandedLore: {
              type: Type.STRING,
              description: "A longer, 1-2 paragraph expanded manuscript narrative revealing secret mechanics, weaknesses, or historical events surrounding it.",
            },
            actions: {
              type: Type.ARRAY,
              description: "2-3 mechanical actions with rolls",
              items: {
                type: Type.OBJECT,
                required: ["name", "formula", "description"],
                properties: {
                  name: {
                    type: Type.STRING,
                    description: "Name of the attack, spell-cast, or skill check",
                  },
                  formula: {
                    type: Type.STRING,
                    description: "The exact dice roll formula (e.g., '2d10+4', '1d20+2', '1d6')",
                  },
                  description: {
                    type: Type.STRING,
                    description: "What happens on a hit or trigger",
                  },
                },
              },
            },
          },
        },
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error("Empty response from Gemini.");
    }

    const data = JSON.parse(text);
    const generatedEntry: TomeEntry = {
      id: `${type}-${Date.now()}`,
      type,
      name: data.name,
      description: data.description,
      pageRef: data.pageRef,
      level: data.level,
      cr: data.cr,
      rarity: data.rarity,
      flavorText: data.flavorText,
      expandedLore: data.expandedLore,
      actions: data.actions,
      isCustom: true,
    };
    databaseStore.unshift(generatedEntry);
    return res.json(generatedEntry);
  } catch (error: any) {
    console.error("Gemini Scribe generation error:", error);
    return res.status(500).json({ error: error.message || "Failed to scribe entry." });
  }
});

// Serve Vite frontend static assets in production, proxy in development
async function start() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`The Tome is active and bound to http://localhost:${PORT}`);
  });
}

start();
