# Design System: The Archive Protocol

## 1. Overview & Creative North Star
### Creative North Star: "The Analog Superintendent"
This design system rejects the fluid, rounded aesthetic of modern SaaS in favor of "Analog Superintendent"—a high-fidelity digital translation of 1970s mainframe terminals and technical field manuals. It is a system built on the authority of the grid, the permanence of print, and the stark clarity of monochromatic data visualization.

By utilizing intentional asymmetry (such as the narrow utility sidebar vs. expansive content stage) and rigid, zero-radius containers, we move away from "apps" and toward "instruments." This experience should feel heavy, tactile, and indisputable.

---

## 2. Colors
The palette is strictly monochromatic, rooted in high-contrast utility. We use an off-white base to simulate aged vellum or matte CRT screens, paired with absolute blacks for ink-on-paper authority.

- **Primary (`#000000`)**: Used for all structural borders, primary headings, and heavy-duty interactive states.
- **Surface (`#fcf9f2`)**: The primary background, providing a warm, non-glare "paper" feel.
- **Surface Tiers**: We use `surface_container_low` (`#f6f3ec`) and `surface_container_high` (`#ebe8e1`) to define secondary content zones without breaking the monochromatic spell.

### The Rules of Engagement
*   **The "Structural Stroke" Rule:** Unlike modern "borderless" trends, this system uses 1px and 2px solid strokes (`primary`) to define the grid. However, internal grouping should be achieved via **Surface Hierarchy** (e.g., nesting a `surface_container_highest` block within a `surface` section) to avoid visual clutter.
*   **Signature Textures:** For high-importance CTAs or headers, use a subtle gradient transition from `primary` (`#000000`) to `primary_container` (`#3b3b3b`) to give a "buffed plastic" or "pressed ink" feel.
*   **Zero-Opacity Glass:** Floating elements (like tooltips) should utilize `surface` with a 90% opacity and a `backdrop-blur` of 8px, simulating a frosted glass overlay placed atop a physical map.

---

## 3. Typography
Typography is the core of this system. We mix three distinct voices to create a "readout" hierarchy.

*   **Display & Headlines (Epilogue):** Bold, aggressive sans-serif. Use for the "DM COMMAND CENTER" identity and major section headers. It conveys the "Terminal" authority.
*   **Narrative & Body (Newsreader):** A sophisticated serif. Used for lore, descriptions, and long-form notes. It provides the "Manual/Field Guide" contrast to the rigid UI.
*   **Data & Labels (Space Grotesk):** A monospaced-leaning sans. Used for technical readouts (HP, AC, LVL) and UI labels. It represents the "Computer Output."

---

## 4. Elevation & Depth
In a world of flat grids, depth is an intentional act. We do not use "soft" shadows; we use **Tonal Layering** and **Architectural Stacking**.

*   **The Layering Principle:** Depth is expressed through the `surface-container` scale. A "Player Card" sits at `surface_container_lowest` against a `surface_container_low` column. This creates a "recessed" or "inset" look common in analog dashboards.
*   **Ghost Borders:** For non-interactive grouping, use `outline_variant` at 20% opacity. This creates a "guide line" feel without the weight of a functional border.
*   **Hard-Edge Elevation:** If a floating menu is required, use a 4px hard-offset "drop shadow" using `primary` at 10% opacity—no blur. This mimics the shadow of a physical sheet of paper on a desk.

---

## 5. Components

### Buttons & Interaction
*   **Primary Action:** Solid `primary` background with `on_primary` text. Square corners (`0px`).
*   **Tertiary/In-Line:** `spaceGrotesk` caps with an underline.
*   **States:** On hover, primary buttons shift to `primary_container`. Active states involve a 1px inset border to simulate a "physical press."

### Custom Iconography
Icons must be "Technical Glyphs"—single-weight line art with no rounded caps. Every icon should fit within a strictly square bounding box, mirroring the "Comms," "Spells," and "Config" icons in the navigation.

### Input Fields
*   **Text Inputs:** A simple bottom-border (2px `primary`) with a `spaceGrotesk` label.
*   **The "Live Query":** Surrounded by a 1px solid box. Use `surface_container_highest` for the background to suggest an active data-entry area.

### Cards & Data Blocks
*   **PC Status Cards:** Use a vertical 2px left-accent border. No internal dividers; use 0.9rem (`4`) spacing to separate HP/AC stats from the name.
*   **Header Blocks:** Use inverted colors (Black background, Off-white text) for sub-headers like "SESSION OVERVIEW" to create an "inverted tape-label" effect.

---

## 6. Do's and Don'ts

### Do
*   **Do** use extreme white space. The 5.5rem (`24`) spacing token is your friend for separating the major columns.
*   **Do** embrace asymmetry. The sidebar should feel intentionally "too narrow" to emphasize its utility.
*   **Do** use monospaced fonts for any numerical value. It ensures data remains readable and aligned.

### Don't
*   **Don't** use border-radius. Ever. Every element must have a `0px` radius to maintain the "Industrial" feel.
*   **Don't** use standard "web" blues or greens for success/info states. Use high-contrast black/white or very muted secondary tones (`#5e5e5e`).
*   **Don't** use dividers between list items. Use the `surface_container` shifts or vertical rhythm (`spacing-4`) to separate content. Lines should only be used for major structural architecture.