import { HeroSection } from './components/HeroSection';
import { ArchiveModules } from './components/ArchiveModules';
import { FooterData } from './components/FooterData';
import { GlobalFooter } from './components/GlobalFooter';

export default function App() {
  return (
    <div className="bg-ink-wash min-h-screen paper-texture selection:bg-dark-orange selection:text-white flex flex-col font-body-md text-primary">
      <main className="max-w-[1400px] mx-auto p-margin-page md:p-stack-lg space-y-stack-lg w-full flex-1">
        <HeroSection />
        
        <div className="w-full h-1 bg-primary relative my-stack-lg">
          <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-ink-wash px-8 pt-1 font-headline-md text-headline-md text-parchment-deep uppercase border-2 border-primary whitespace-nowrap">
            The Archive Modules
          </div>
        </div>

        <ArchiveModules />
        <FooterData />
      </main>
      <GlobalFooter />
    </div>
  );
}
