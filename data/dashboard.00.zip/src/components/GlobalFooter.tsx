export function GlobalFooter() {
  return (
    <footer className="bg-primary border-t-4 border-primary flex flex-col md:flex-row justify-between items-center px-margin-page py-stack-lg w-full mt-auto">
      <div className="font-headline-md text-headline-md text-parchment-deep">THE TOME</div>
      <div className="flex flex-wrap justify-center gap-stack-md my-4 md:my-0">
        {['Privacy Policy', 'Terms of Service', 'Legal Notices', 'Contact'].map((link) => (
          <a key={link} href="#" className="font-label-sm text-label-sm text-on-primary-fixed-variant opacity-80 hover:text-dark-orange transition-colors duration-75">
            {link}
          </a>
        ))}
      </div>
      <div className="font-label-sm text-label-sm text-parchment-deep opacity-50">
        © 1970 THE TOME PRODUCTIONS. ALL RIGHTS RESERVED.
      </div>
    </footer>
  );
}
