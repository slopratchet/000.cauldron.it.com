import { FolderOpen, History } from 'lucide-react';

export function HeroSection() {
  return (
    <section className="grid grid-cols-1 lg:grid-cols-12 gap-gutter relative">
      {/* Left Side */}
      <div className="lg:col-span-7 bg-parchment-deep border-4 border-primary p-stack-md shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] relative overflow-hidden group">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/old-map.png')] opacity-20 pointer-events-none"></div>
        
        <div className="flex justify-between items-start border-b-2 border-primary pb-4 mb-stack-md">
          <div>
            <h1 className="font-headline-xl text-headline-xl uppercase leading-none ink-bleed">Performance<br/>Title</h1>
            <p className="font-label-sm text-label-sm mt-2 opacity-70">Case File: 70-PROD-ALPHA | Archive Status: SECURE</p>
          </div>
          <div className="bg-primary text-parchment-deep p-2 border-2 border-primary">
            <FolderOpen className="w-12 h-12 stroke-[1.5]" />
          </div>
        </div>

        <div className="relative aspect-video w-full border-2 border-primary overflow-hidden grayscale contrast-125 mb-stack-md">
          <img 
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuAcbLdkyQSnAvn5L-_ksO-G0p0V5iIvfz-aWz9mzu6XQPafhHmykFVxjzmzRN9ETKncVHGuvNT2MI9M7HWYlTrXN63rLg59qubbEYJl0Fi1ruxc9J_MiqXD51mWKQ8XdCnbsvE9VR7TGjqMt00z_SaMKXTnGD68843ntUy2IN31xfLucBkXepLYk7ej6fWJeDwf56h_EGiINcHEt-iz4iR8AQKgvybcxy_GSkte77B9TVaio4GzbxD4kIcwprpNaIHIJj9ds1ZOj_Zn" 
            alt="Archival material" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/10 mix-blend-multiply"></div>
          <div className="absolute top-4 left-4 bg-parchment-deep/90 border border-primary px-3 py-1 font-label-sm text-label-sm">
            Reference: Operations Plan
          </div>
        </div>

        <div className="grid grid-cols-2 gap-stack-md">
          <div className="space-y-2">
            <h3 className="font-label-md text-label-md border-b-2 border-primary pb-1">Site Protocol</h3>
            <p className="font-body-md text-body-md">All performances documented herein were subject to 1970 standard safety regulations. Note the target seat designations on the central chart for VIP extraction protocols.</p>
          </div>
          <div className="space-y-2">
            <h3 className="font-label-md text-label-md border-b-2 border-primary pb-1">Archive Integrity</h3>
            <p className="font-body-md text-body-md italic text-body-italic">Ink bleed and edge fraying are inherent to the aging process of the ledger. Handle with tactical gloves only.</p>
          </div>
        </div>
      </div>

      {/* Right Side */}
      <div className="lg:col-span-5 space-y-stack-lg flex flex-col">
        <div className="bg-primary text-parchment-deep border-4 border-primary p-stack-md shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
          <div className="flex items-center gap-4 mb-4">
            <div className="border-2 border-parchment-deep p-2">
              <History className="w-8 h-8 stroke-[1.5]" />
            </div>
            <h2 className="font-headline-md text-headline-md uppercase">Legacy Stats</h2>
          </div>
          <div className="space-y-stack-sm font-label-md text-label-md">
            <div className="flex justify-between border-b border-parchment-deep/30 py-2">
              <span>Total Shows</span>
              <span className="font-bold">428</span>
            </div>
            <div className="flex justify-between border-b border-parchment-deep/30 py-2">
              <span>Tickets Sold</span>
              <span className="font-bold">12,490</span>
            </div>
            <div className="flex justify-between border-b border-parchment-deep/30 py-2">
              <span>Operational Efficiency</span>
              <span className="font-bold">98.2%</span>
            </div>
          </div>
        </div>

        <div className="bg-parchment-deep border-4 border-primary p-stack-md shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] flex flex-col items-center text-center flex-1 justify-center">
          <div className="w-32 h-32 border-2 border-primary p-2 mb-4 bg-white">
            <img 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuCODNw3soXSAoJLWBAfI-BRFrvAQgyQW0PGgFvB3BHdZe7XXGNF89ueTn0uw8bro6d8Z06k4Y-doHtkCuelejRk5P9OM_6BmDx7R-jnmLqWya5-zeul9TAqzeDTrtzJ5VqJgIECgF9Jw0CwVkQ9gzL6EU2Y2tBOzo-g-CMvos_sWB_hltk1bWHgtkGXrf3U5Y4gsAlKXoavKVwo1qKn-ltCZES-fF3cmm-4ZgELCpLrL1zLxZLeu1XSXrPM66BrYgj1oWjNwVPweJVh" 
              alt="QR Link" 
              className="w-full h-full grayscale opacity-80"
            />
          </div>
          <p className="font-label-sm text-label-sm tracking-widest">Digital Authentication Key</p>
          <p className="font-body-md text-body-md mt-2">Scan to verify ledger authenticity via mainframe terminal.</p>
        </div>
      </div>
    </section>
  );
}
