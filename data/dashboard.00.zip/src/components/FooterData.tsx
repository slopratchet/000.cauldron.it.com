export function FooterData() {
  return (
    <section className="bg-primary-container p-stack-md border-4 border-primary text-parchment-deep grid grid-cols-1 md:grid-cols-4 gap-stack-md">
      <div className="border-l-4 border-dark-orange pl-4">
        <div className="font-label-sm text-label-sm opacity-50">Authorized By</div>
        <div className="font-headline-md text-headline-md uppercase">Director V.</div>
      </div>
      <div className="border-l-4 border-dark-orange pl-4">
        <div className="font-label-sm text-label-sm opacity-50">Ledger Index</div>
        <div className="font-headline-md text-headline-md uppercase">VOL. 07</div>
      </div>
      <div className="border-l-4 border-dark-orange pl-4">
        <div className="font-label-sm text-label-sm opacity-50">Document State</div>
        <div className="font-headline-md text-headline-md uppercase">FINALIZED</div>
      </div>
      <div className="flex items-center justify-start md:justify-end">
        <button className="bg-parchment-deep text-primary font-label-md text-label-md px-6 py-2 border-2 border-primary shadow-[4px_4px_0px_0px_#D35400] hover:bg-dark-orange hover:text-white transition-all cursor-pointer">
          Print Archive
        </button>
      </div>
    </section>
  );
}
