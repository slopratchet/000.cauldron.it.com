const modules = [
  {
    id: "204",
    date: "June 14, 1970",
    title: "The Gilded Atrium",
    tagColor: "bg-dark-orange text-white",
    stubClass: "text-dark-orange",
    stubTitle: "ADMIT ONE",
    stubSubtitle: "SECTOR ALPHA - ROW G - SEAT 12",
    mapImg: "https://lh3.googleusercontent.com/aida-public/AB6AXuCePGOc_atV-C-J_fCeZx-wt2x-eNnU-ZbkSplBMyWeAfW-mc-lHtIEqAWEqUX_PPPlGMgQRGn0N_UeNhGkfA04SXrlUca0nDVRwooDr_OHYJu4rM7hKBLEECiJScwcrqKTR2NTcwKRL9KfUQpReJeHZK1tMwOq6YOF7ynNLDypGs_gfBclqjFN03jyI2tg5DoGY4VvMO3SO9X6_T-9j60j07WDyCjGtm91MpviRWyUYa1oF0ZuugVdKvQz0yU7sQ0wR3Ij_327JySY",
    hasDot: true
  },
  {
    id: "205",
    date: "July 02, 1970",
    title: "Shadow Chamber",
    tagColor: "bg-primary text-white",
    stubClass: "text-primary",
    stubTitle: "VIP GUEST",
    stubSubtitle: "BALCONY - BOX IV",
    mapImg: "https://lh3.googleusercontent.com/aida-public/AB6AXuDkRbMcZ20iY7PxRvvkYJwjbHhPAPOt2VAsy7zbQl5yaSzS-zz06KwEMn2wAPD2BBG6PFsnMbrfMFYZvMLxGKra-279hFtwRDLaOaFw-2WckljGE5fPOWzNyp1786d1Gabuo3ocsjla_rY5231JKkWIgaYj5jiDZXtDL1_nsmlKmVMdZtOJ4bki8oJ9Cd2nblDIBufFlYeMDO7m2lcHwyDuh3y1Sunxp15mC4y6XUASlS2Nqbik09OnEPmneVOntfZ9dQZF0l9mQHG5",
    hasDot: false
  },
  {
    id: "206",
    date: "August 19, 1970",
    title: "The Velvet Void",
    tagColor: "bg-primary text-white",
    stubClass: "text-dark-orange",
    stubTitle: "EXPIRED",
    stubSubtitle: "GENERAL ADMISSION",
    mapImg: "https://lh3.googleusercontent.com/aida-public/AB6AXuAE8vhCH11F7WjIKCmXMZEQ97e01SEl2imH5_d0NGQpxUiUZ7Y35VjyPHAmJEJyCZQoOtaa2eqT_ck3a1VHdTsB35zeNTG4FGIhd4SwdTIOjV0uVRVAXuhWGQqr84i32TKnoooh_Yp2RS9A2br4HjTtUR9UskKkpzpq6eEhKZ_jM6Ru7RChU9LShtGAr9VMB06OYaXMVr0ZSAqLcHgsSmlHo3SMgWYzbCg4RAMpe_t17utDu2fOizcj-EtaUAOMGRaXvk-lmSxq5vbk",
    hasDot: false
  }
];

export function ArchiveModules() {
  return (
    <section className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-stack-lg pt-stack-md">
      {modules.map((mod) => (
        <div key={mod.id} className="bg-parchment-deep border-2 border-primary shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover-lift group flex flex-col">
          <div className="h-2 w-full bg-primary mb-1"></div>
          <div className="p-stack-md space-y-4 flex flex-col flex-1">
            <div className="flex justify-between items-start">
              <span className={`${mod.tagColor} px-2 py-0.5 font-label-sm text-label-sm tracking-tighter`}>
                Event #{mod.id}
              </span>
              <span className="font-label-sm text-label-sm">{mod.date}</span>
            </div>
            
            <h3 className="font-headline-md text-headline-md uppercase leading-tight">{mod.title}</h3>
            
            {/* Stub Aesthetic */}
            <div className="border-2 border-dashed border-primary/40 p-3 bg-white/50 relative overflow-hidden">
              <div className="absolute top-0 bottom-0 left-0 w-4 flex flex-col justify-between py-1 opacity-20">
                <div className="w-1 h-1 bg-black rounded-full"></div>
                <div className="w-1 h-1 bg-black rounded-full"></div>
                <div className="w-1 h-1 bg-black rounded-full"></div>
                <div className="w-1 h-1 bg-black rounded-full"></div>
              </div>
              <div className="pl-6 space-y-1">
                <div className="text-[10px] font-label-sm opacity-60">Ticket Stub Reference</div>
                <div className={`font-headline-md text-headline-md leading-none ${mod.stubClass}`}>
                  {mod.stubTitle}
                </div>
                <div className="font-label-md text-label-md font-bold">
                  {mod.stubSubtitle}
                </div>
              </div>
            </div>

            {/* Mini Map */}
            <div className="aspect-square w-full border border-primary bg-white/30 p-2 flex items-center justify-center relative mt-auto">
              <img 
                src={mod.mapImg} 
                alt="Seating chart" 
                className="w-full h-full object-contain grayscale opacity-60 mix-blend-multiply" 
              />
              {mod.hasDot && (
                <div className="absolute top-2 right-2 flex gap-1">
                  <div className="w-2 h-2 bg-dark-orange rounded-full animate-pulse"></div>
                </div>
              )}
            </div>
          </div>
        </div>
      ))}
    </section>
  );
}
