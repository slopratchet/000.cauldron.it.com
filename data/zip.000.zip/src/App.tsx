/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Sidebar } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { DossierProfile } from './components/DossierProfile';

export default function App() {
  return (
    <div className="min-h-screen flex flex-col md:flex-row antialiased selection:bg-primary selection:text-surface font-sans">
      <Sidebar />
      <main className="flex-1 flex flex-col min-w-0 bg-surface">
        <TopBar />
        <DossierProfile />
      </main>
    </div>
  );
}
