export function TopBar() {
  return (
    <header className="h-16 brutalist-border-bottom flex items-center justify-between px-6 bg-surfaceBright z-10 sticky top-0">
      <div className="flex items-center space-x-4">
        <span className="font-mono font-bold text-xl uppercase">Dossier: Veteran</span>
        <span className="hidden md:inline-block px-2 py-1 bg-primary text-surface text-xs font-mono uppercase">Classified Level 4</span>
      </div>
      <div className="flex items-center space-x-4 font-mono text-sm">
        <span className="hidden sm:inline-block border-2 border-border px-2 py-1">ID: VET-8492-X</span>
        <button className="bg-primary text-surface px-4 py-2 hover:bg-surface hover:text-primary brutalist-border-medium transition-colors font-bold uppercase">Print File</button>
      </div>
    </header>
  );
}
