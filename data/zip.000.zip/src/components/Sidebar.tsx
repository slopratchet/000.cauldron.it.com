export function Sidebar() {
  return (
    <aside className="w-full md:w-64 flex-shrink-0 brutalist-border-right border-b-4 md:border-b-0 border-border bg-surface flex flex-col z-20 sticky top-0 md:h-screen">
      <div className="p-4 brutalist-border-bottom bg-primary text-surface">
        <h1 className="text-2xl font-black uppercase tracking-widest font-mono leading-tight">CHRONOS<br/>SYS.</h1>
        <p className="text-xs mt-1 font-mono uppercase opacity-80">Terminal Interface v7.4</p>
      </div>
      <nav className="flex-1 overflow-y-auto p-4 space-y-2">
        <div className="mb-6">
          <h2 className="text-xs font-bold uppercase tracking-widest text-primary mb-2 border-b-2 border-border pb-1">Database</h2>
          <ul className="space-y-1">
            <li>
              <a className="block px-2 py-1 hover:bg-primary hover:text-surface transition-colors font-mono text-sm border border-transparent hover:border-primary" href="#">Personnel Files</a>
            </li>
            <li>
              <a className="block px-2 py-1 bg-surfaceDim font-mono text-sm border-l-4 border-primary font-bold" href="#">Active Profile</a>
            </li>
            <li>
              <a className="block px-2 py-1 hover:bg-primary hover:text-surface transition-colors font-mono text-sm border border-transparent hover:border-primary" href="#">Incident Reports</a>
            </li>
          </ul>
        </div>
      </nav>
      <div className="p-4 brutalist-border-top border-border bg-surfaceDim text-xs font-mono">
        <p>STATUS: <span className="font-bold text-green-700">ONLINE</span></p>
        <p>UPTIME: 94:12:05</p>
        <p>USER: ADMIN_01</p>
      </div>
    </aside>
  );
}
