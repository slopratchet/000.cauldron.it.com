export function DossierProfile() {
  const skills = [
    "Automatic weapons", "Dagger", "Dodge",
    "Parachuting", "Interrogation", "First Aid",
    "Hide", "Throwing weapons", "Climb",
    "Drive car", "Motor mechanics", "Piloting",
    "Handgun", "Radio communications", "Swimming",
    "Sneak", "Demolition", "Martial arts: commando",
    "Heavy weapons", "Survival"
  ];

  return (
    <div className="p-4 md:p-8 flex-1 overflow-y-auto pattern-bg">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header Block */}
        <div className="brutalist-border bg-surface p-6 sm:p-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
            <svg fill="none" height="120" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" width="120">
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
            </svg>
          </div>
          <h1 className="text-5xl sm:text-7xl font-black uppercase tracking-tighter mb-2 leading-none">Veteran</h1>
          <h2 className="text-xl sm:text-2xl font-mono uppercase tracking-widest text-primary border-t-4 border-border pt-2 inline-block">Operator Profile</h2>
        </div>

        {/* Narrative Quote */}
        <div className="brutalist-border bg-primary text-surface p-6 sm:p-8 italic text-lg sm:text-xl font-medium border-l-[16px] border-l-surfaceDim">
          "It usually happens when I get angry. Everything turns black, and then it's there—the roar of the bombers, the explosions, the pain, the dead faces. That's when I lose control and start beating everything and everyone around me."
        </div>

        {/* Grid Layout for Details */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Column 1: Image & Basic Bio */}
          <div className="lg:col-span-1 space-y-8">
            {/* Technical Photograph */}
            <div className="brutalist-border bg-surface p-2 pb-8 relative group">
              <div className="absolute top-0 left-0 bg-primary text-surface px-2 py-1 text-xs font-mono z-10">SUBJECT REF. IMG</div>
              <div className="absolute bottom-2 right-2 font-mono text-[10px] opacity-50">SCANNED: 1994-08-12</div>
              <img 
                alt="Illustration of a rugged veteran in camouflage pants, black t-shirt, and sunglasses" 
                className="w-full h-auto object-cover border-2 border-border filter sepia-[.2] contrast-125" 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuAj9iK390ZqFKdqHlWpoFJT3ku4FgPRKp0CEHkUOgsc70iPFFN10B2Y4uzCKw-q5fKEtSW7DEegbE3IPEWgpJI10pRHQUQkroCZZRmdOmDi8fhE8bx6QLJlCAB7CiSxBs71sYWcQvJ43Aj8251qcgNGxUZiEPGCBLKo9_z3R8bsEXN8looyvFcvEvN48kwOZyxzC3xIpEyV963PmibDEyIkNEdn4I0b68fO9HEJYe8fFr-WYy3t1C9RGzPY3pRzf4cKJlM7wwf5GfYm" 
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Basic Info Box */}
            <div className="brutalist-border bg-surface p-6">
              <h3 className="text-2xl font-bold uppercase mb-4 border-b-2 border-border pb-2">Bio-Data</h3>
              <dl className="space-y-4 font-mono text-sm">
                <div>
                  <dt className="font-bold uppercase text-xs opacity-70">Profession</dt>
                  <dd className="text-lg">Unemployed, General Worker<br/>(Ex-Soldier)</dd>
                </div>
                <div>
                  <dt className="font-bold uppercase text-xs opacity-70">Living Standard</dt>
                  <dd className="text-lg">3-5</dd>
                </div>
                <div className="pt-4 border-t border-border border-dashed">
                  <p className="font-sans text-base">You are an ex-soldier and somewhat uncomfortable with civilian life. It's difficult to live without clear rules and commanders who tell you what to do. It breeds disorder. You probably fought in some small, dirty war in Africa, Southeast Asia or Latin America. Perhaps you were in the French Foreign Legion, the US Army, the Soviet Red Army, or a mercenary outfit.</p>
                </div>
              </dl>
            </div>
          </div>

          {/* Column 2 & 3: Details & Matrices */}
          <div className="lg:col-span-2 space-y-8">
            {/* Special Status (Personality & Dark Secret) */}
            <div className="brutalist-border bg-surface p-6 sm:p-8 grid-bg relative">
              <div className="absolute top-2 right-2 px-2 py-1 bg-surface border-2 border-border text-xs font-mono font-bold">PSYCH-EVAL REQUIRED</div>
              <h3 className="text-3xl font-black uppercase mb-6 bg-surface inline-block pr-4">Psychological Profile</h3>
              <div className="space-y-6 bg-surface p-4 border-2 border-border">
                <div>
                  <h4 className="text-xl font-bold uppercase border-b border-border pb-1 mb-2">Personality</h4>
                  <p className="font-sans text-lg">Violent, sentimental, you have an intense love-hate relationship with the military world. More or less mentally damaged by war experiences.</p>
                </div>
                <div>
                  <h4 className="text-xl font-bold uppercase border-b border-border pb-1 mb-2 text-red-900">Dark Secret</h4>
                  <ul className="list-disc list-inside font-mono text-sm space-y-1 marker:text-primary">
                    <li>Family secret</li>
                    <li>Victim of crime</li>
                    <li>Guilty of crime</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Traits Ledger */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Disadvantages */}
              <div className="brutalist-border bg-surface p-6 flex flex-col">
                <h3 className="text-2xl font-black uppercase mb-4 bg-primary text-surface p-2 text-center">Disadvantages</h3>
                <ul className="font-mono text-sm space-y-2 flex-1 border-l-2 border-border pl-4">
                  <li className="relative before:content-['>'] before:absolute before:-left-4 before:font-bold">Depression</li>
                  <li className="relative before:content-['>'] before:absolute before:-left-4 before:font-bold">Death wish</li>
                  <li className="relative before:content-['>'] before:absolute before:-left-4 before:font-bold">Phobia (afraid of sudden noises or the dark)</li>
                  <li className="relative before:content-['>'] before:absolute before:-left-4 before:font-bold">Mental constriction</li>
                  <li className="relative before:content-['>'] before:absolute before:-left-4 before:font-bold">Paranoia</li>
                  <li className="relative before:content-['>'] before:absolute before:-left-4 before:font-bold">Wanted (for desertion or crime)</li>
                  <li className="relative before:content-['>'] before:absolute before:-left-4 before:font-bold">Touchy</li>
                  <li className="relative before:content-['>'] before:absolute before:-left-4 before:font-bold">Habitual liar</li>
                  <li className="relative before:content-['>'] before:absolute before:-left-4 before:font-bold">Drug addiction</li>
                  <li className="relative before:content-['>'] before:absolute before:-left-4 before:font-bold">Mental compulsion</li>
                </ul>
              </div>

              {/* Advantages */}
              <div className="brutalist-border bg-surface p-6 flex flex-col">
                <h3 className="text-2xl font-black uppercase mb-4 bg-surfaceDim p-2 text-center border-b-4 border-border">Advantages</h3>
                <ul className="font-mono text-sm space-y-2 flex-1 border-l-2 border-border pl-4">
                  <li className="relative before:content-['+'] before:absolute before:-left-4 before:font-bold">Body awareness</li>
                  <li className="relative before:content-['+'] before:absolute before:-left-4 before:font-bold">Pacifism</li>
                  <li className="relative before:content-['+'] before:absolute before:-left-4 before:font-bold">Sixth sense</li>
                  <li className="relative before:content-['+'] before:absolute before:-left-4 before:font-bold">Endure hunger/thirst/cold/heat/pain/torture</li>
                </ul>
              </div>
            </div>

            {/* Skills Matrix */}
            <div className="brutalist-border bg-surface p-6 sm:p-8">
              <div className="flex items-center justify-between mb-6 border-b-4 border-border pb-2">
                <h3 className="text-3xl font-black uppercase">Tactical Skills Matrix</h3>
                <span className="font-mono text-xs font-bold border-2 border-border p-1 hidden sm:inline-block">AUTHORIZED PERSONNEL ONLY</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-x-8 gap-y-4 font-mono text-sm">
                {skills.map((skill, index) => (
                  <div key={index} className="flex items-center space-x-2 border-b border-border border-dashed pb-1">
                    <span className="w-2 h-2 bg-primary flex-shrink-0"></span>
                    <span>{skill}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
