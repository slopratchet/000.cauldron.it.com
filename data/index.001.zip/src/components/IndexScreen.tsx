import React, { useState } from 'react';
import { manualSections } from '../data/manualData';
import { ManualItem } from '../types';
import { Search, UserPlus, Dice5, HelpCircle, Ship, BookOpen } from 'lucide-react';

interface IndexScreenProps {
  onSelectItem: (item: ManualItem) => void;
  onOpenDiceRoller: () => void;
  onJoinPartyClick: () => void;
}

export default function IndexScreen({
  onSelectItem,
  onOpenDiceRoller,
  onJoinPartyClick
}: IndexScreenProps) {
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Handle lookup searching across all items
  const allItems = manualSections.flatMap(section => section.items);
  const filteredItems = searchQuery
    ? allItems.filter(item =>
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.content.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  const handleSearchSelect = (item: ManualItem) => {
    onSelectItem(item);
    setSearchQuery('');
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 md:px-8 select-none">
      {/* Main Title Banner */}
      <section className="my-8">
        <h2 className="font-accent text-6xl uppercase tracking-tighter text-black md:text-[110px] md:leading-[105px]">
          SYSTEM INDEX
        </h2>
        <div className="mt-2 flex flex-col justify-between font-mono text-xs font-semibold uppercase tracking-widest text-neutral-500 sm:flex-row">
          <span>DATA STACK // REFERENCE MANUAL V.70 // ACCESS: GRANTED</span>
        </div>
        <div className="mt-4 h-1.5 bg-black" />
      </section>

      {/* Interactive Search Tool */}
      <div className="relative mb-8 w-full">
        <div className="flex border-2 border-[#1b1b1b] bg-white shadow-[2px_2px_0px_0px_rgba(27,27,27,1)]">
          <input
            id="index-search-input"
            type="text"
            placeholder="TERM QUERY (e.g. Rage, Apocalypse, Dice)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full font-mono text-xs px-3 py-2 outline-none uppercase placeholder:text-neutral-400"
          />
          <div className="flex items-center gap-1.5 border-l-2 border-[#1b1b1b] bg-neutral-100 px-3 font-mono text-[10px] font-bold text-neutral-500">
            <Search className="h-3.5 w-3.5 text-neutral-400" /> QUERY
          </div>
        </div>

        {/* Search Results Dropdown Overlay */}
        {searchQuery && (
          <div className="absolute z-10 mt-2 w-full border-2 border-[#1b1b1b] bg-white p-2 font-mono shadow-[4px_4px_0px_0px_rgba(27,27,27,1)]">
            <p className="border-b border-[#1b1b1b]/10 pb-1 text-[10px] font-bold text-neutral-400 uppercase">
              QUERY REGISTER OUTCOME ({filteredItems.length} FOUND)
            </p>
            {filteredItems.length > 0 ? (
              <div className="max-h-60 overflow-y-auto divide-y divide-neutral-100">
                {filteredItems.map(item => (
                  <button
                    key={item.id}
                    onClick={() => handleSearchSelect(item)}
                    className="flex w-full cursor-pointer justify-between py-2.5 px-1.5 text-left text-xs uppercase hover:bg-neutral-100 font-semibold text-[#1b1b1b]"
                  >
                    <span>{item.title}</span>
                    <span className="text-blood-red font-bold">PAGE {item.page}</span>
                  </button>
                ))}
              </div>
            ) : (
              <p className="p-3 text-center text-xs italic text-neutral-500">No archives match the query.</p>
            )}
          </div>
        )}
      </div>

      {/* 3-Column Table of Contents Grid */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
        
        {/* ================= COLUMN 1 ================= */}
        <div className="flex flex-col">
          <div className="bg-black py-1 px-3 text-center text-xs font-mono font-bold tracking-widest text-[#fdfbf7]">
            DECK_01 // KNOW
          </div>
          
          <div className="mt-2 flex-grow border-2 border-[#1b1b1b] bg-[#fdfbf7] p-5 shadow-[2px_2px_0px_0px_rgba(27,27,27,1)]">
            {/* Title Block with Red Page Number */}
            <div className="flex justify-between items-baseline border-b border-neutral-300 pb-3 mb-4">
              <h3 className="font-accent text-[42px] leading-[40px] uppercase text-[#1b1b1b] tracking-wider">
                Know
              </h3>
              <span className="font-accent text-[34px] text-blood-red select-none pl-2">09</span>
            </div>

            {/* List Items */}
            <div className="space-y-4">
              {/* Welcome to a Dying World */}
              <button
                id="item-welcome-to-a-dying-world"
                onClick={() => onSelectItem(manualSections[0].items[0])}
                className="group flex w-full cursor-pointer items-end justify-between font-serif text-[17px] text-[#1b1b1b] hover:text-blood-red"
              >
                <span className="font-semibold text-left underline-offset-4 group-hover:underline">Welcome to a Dying World</span>
                <span className="mx-2 mb-1 flex-grow border-b border-dotted border-[#1b1b1b]/30 group-hover:border-blood-red" />
                <span className="font-mono text-xs font-bold bg-neutral-200/50 px-1.5 group-hover:bg-blood-red group-hover:text-white transition-colors">10</span>
              </button>

              {/* Walkers Between Worlds (Indented) */}
              <button
                id="item-walkers-between-worlds"
                onClick={() => onSelectItem(manualSections[0].items[1])}
                className="group flex w-full cursor-pointer items-end justify-between pl-6 font-serif text-[17px] text-neutral-600 hover:text-blood-red"
              >
                <span className="italic text-left group-hover:underline">Walkers Between Worlds</span>
                <span className="mx-2 mb-1 flex-grow border-b border-dotted border-[#1b1b1b]/15 group-hover:border-blood-red" />
                <span className="font-mono text-xs font-bold bg-neutral-200/50 px-1.5 group-hover:bg-blood-red group-hover:text-white transition-colors">10</span>
              </button>

              {/* What Do Werewolves Do? */}
              <button
                id="item-what-do-werewolves-do"
                onClick={() => onSelectItem(manualSections[0].items[2])}
                className="group flex w-full cursor-pointer items-end justify-between font-serif text-[17px] text-[#1b1b1b] hover:text-blood-red"
              >
                <span className="font-semibold text-left group-hover:underline">What Do Werewolves Do?</span>
                <span className="mx-2 mb-1 flex-grow border-b border-dotted border-[#1b1b1b]/30 group-hover:border-blood-red" />
                <span className="font-mono text-xs font-bold bg-neutral-200/50 px-1.5 group-hover:bg-blood-red group-hover:text-white transition-colors">11</span>
              </button>

              {/* Storytelling Games */}
              <div className="space-y-3">
                <button
                  id="item-storytelling-games"
                  onClick={() => onSelectItem(manualSections[0].items[3])}
                  className="group flex w-full cursor-pointer items-end justify-between font-serif text-[17px] text-[#1b1b1b] hover:text-blood-red"
                >
                  <span className="font-semibold text-left group-hover:underline">Storytelling Games</span>
                  <span className="mx-2 mb-1 flex-grow border-b border-dotted border-[#1b1b1b]/30 group-hover:border-blood-red" />
                  <span className="font-mono text-xs font-bold bg-neutral-200/50 px-1.5 group-hover:bg-blood-red group-hover:text-white transition-colors">11</span>
                </button>

                {/* The Storyteller (Indented) */}
                <button
                  id="item-the-storyteller"
                  onClick={() => onSelectItem(manualSections[0].items[4])}
                  className="group flex w-full cursor-pointer items-end justify-between pl-6 font-serif text-[17px] text-neutral-600 hover:text-blood-red"
                >
                  <span className="italic text-left group-hover:underline">The Storyteller</span>
                  <span className="mx-2 mb-1 flex-grow border-b border-dotted border-[#1b1b1b]/15 group-hover:border-blood-red" />
                  <span className="font-mono text-xs font-bold bg-neutral-200/50 px-1.5 group-hover:bg-blood-red group-hover:text-white transition-colors">11</span>
                </button>

                {/* The Players (Indented) */}
                <button
                  id="item-the-players"
                  onClick={() => onSelectItem(manualSections[0].items[5])}
                  className="group flex w-full cursor-pointer items-end justify-between pl-6 font-serif text-[17px] text-neutral-600 hover:text-blood-red"
                >
                  <span className="italic text-left group-hover:underline">The Players</span>
                  <span className="mx-2 mb-1 flex-grow border-b border-dotted border-[#1b1b1b]/15 group-hover:border-blood-red" />
                  <span className="font-mono text-xs font-bold bg-neutral-200/50 px-1.5 group-hover:bg-blood-red group-hover:text-white transition-colors">12</span>
                </button>
              </div>



              {/* Lexicon */}
              <button
                id="item-lexicon"
                onClick={() => onSelectItem(manualSections[0].items[6])}
                className="group flex w-full cursor-pointer items-end justify-between font-serif text-[17px] text-[#1b1b1b] hover:text-blood-red pt-2"
              >
                <span className="font-semibold text-left group-hover:underline">Lexicon</span>
                <span className="mx-2 mb-1 flex-grow border-b border-dotted border-[#1b1b1b]/30 group-hover:border-blood-red" />
                <span className="font-mono text-xs font-bold bg-neutral-200/50 px-1.5 group-hover:bg-blood-red group-hover:text-white transition-colors">15</span>
              </button>
            </div>
          </div>
        </div>

        {/* ================= COLUMN 2 ================= */}
        <div className="flex flex-col">
          <div className="bg-black py-1 px-3 text-center text-xs font-mono font-bold tracking-widest text-[#fdfbf7]">
            DECK_02 // ACTOR
          </div>
          
          <div className="mt-2 flex-grow border-2 border-[#1b1b1b] bg-[#fdfbf7] p-5 shadow-[2px_2px_0px_0px_rgba(27,27,27,1)]">
            {/* Title block with Red Page number */}
            <div className="flex justify-between items-baseline border-b border-neutral-300 pb-3 mb-4">
              <h3 className="font-accent text-[42px] leading-[40px] uppercase text-[#1b1b1b] tracking-wider">
                Actor
              </h3>
              <span className="font-accent text-[34px] text-blood-red select-none pl-2">17</span>
            </div>

            {/* List Items */}
            <div className="space-y-5">
              {/* Age of Apocalypse */}
              <div>
                <button
                  id="item-age-of-apocalypse"
                  onClick={() => onSelectItem(manualSections[1].items[0])}
                  className="group flex w-full cursor-pointer items-end justify-between font-serif text-[17px] text-[#1b1b1b] hover:text-blood-red"
                >
                  <span className="font-semibold text-left group-hover:underline">Age of Apocalypse</span>
                  <span className="mx-2 mb-1 flex-grow border-b border-dotted border-[#1b1b1b]/30 group-hover:border-blood-red" />
                  <span className="font-mono text-xs font-bold bg-neutral-200/50 px-1.5 group-hover:bg-blood-red group-hover:text-white transition-colors">17</span>
                </button>

                {/* Cometh the Hour (Indented) */}
                <button
                  id="item-cometh-the-hour"
                  onClick={() => onSelectItem(manualSections[1].items[1])}
                  className="group mt-2.5 flex w-full cursor-pointer items-end justify-between pl-6 font-serif text-[17px] text-neutral-600 hover:text-blood-red"
                >
                  <span className="italic text-left group-hover:underline">Cometh the Hour</span>
                  <span className="mx-2 mb-1 flex-grow border-b border-dotted border-[#1b1b1b]/15 group-hover:border-blood-red" />
                  <span className="font-mono text-xs font-bold bg-neutral-200/50 px-1.5 group-hover:bg-blood-red group-hover:text-white transition-colors">18</span>
                </button>
              </div>

              {/* Endless Enemies */}
              <div className="space-y-4 pt-1">
                <button
                  id="item-endless-enemies"
                  onClick={() => onSelectItem(manualSections[1].items[2])}
                  className="group flex w-full cursor-pointer items-end justify-between font-serif text-[17px] text-[#1b1b1b] hover:text-blood-red"
                >
                  <span className="font-semibold text-left group-hover:underline">Endless Enemies</span>
                  <span className="mx-2 mb-1 flex-grow border-b border-dotted border-[#1b1b1b]/30 group-hover:border-blood-red" />
                  <span className="font-mono text-xs font-bold bg-neutral-200/50 px-1.5 group-hover:bg-blood-red group-hover:text-white transition-colors">30</span>
                </button>

                {/* Agents of Entropy (Indented) */}
                <button
                  id="item-agents-of-entropy"
                  onClick={() => onSelectItem(manualSections[1].items[3])}
                  className="group flex w-full cursor-pointer items-end justify-between pl-6 font-serif text-[17px] text-neutral-600 hover:text-blood-red"
                >
                  <span className="italic text-left group-hover:underline">Agents of Entropy</span>
                  <span className="mx-2 mb-1 flex-grow border-b border-dotted border-[#1b1b1b]/15 group-hover:border-blood-red" />
                  <span className="font-mono text-xs font-bold bg-neutral-200/50 px-1.5 group-hover:bg-blood-red group-hover:text-white transition-colors">30</span>
                </button>

                {/* Agents of Stasis (Indented) */}
                <button
                  id="item-agents-of-stasis"
                  onClick={() => onSelectItem(manualSections[1].items[4])}
                  className="group flex w-full cursor-pointer items-end justify-between pl-6 font-serif text-[17px] text-neutral-600 hover:text-blood-red"
                >
                  <span className="italic text-left group-hover:underline">Agents of Stasis</span>
                  <span className="mx-2 mb-1 flex-grow border-b border-dotted border-[#1b1b1b]/15 group-hover:border-blood-red" />
                  <span className="font-mono text-xs font-bold bg-neutral-200/50 px-1.5 group-hover:bg-blood-red group-hover:text-white transition-colors">31</span>
                </button>
              </div>

              {/* Graphic/Atmospheric spacing block with high-contrast text */}
              <div className="mt-8 border border-neutral-300 p-4 font-mono text-[11px] leading-relaxed text-neutral-500 bg-[#e6e2d8]/20 bg-[radial-gradient(#cfc4c5_1px,transparent_1px)] [background-size:12px_12px]">
                <p className="font-bold text-[#1b1b1b] uppercase">MEM_INTEGRITY: OK</p>
                <p className="mt-1">
                  1970 System manual archives are loaded. Clicking titles accesses stored memory files immediately over local diagnostic channels.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* ================= COLUMN 3 ================= */}
        <div className="flex flex-col">
          <div className="bg-black py-1 px-3 text-center text-xs font-mono font-bold tracking-widest text-[#fdfbf7]">
            DECK_03 // ACTION
          </div>
          
          <div className="mt-2 flex-grow border-2 border-[#1b1b1b] bg-[#fdfbf7] p-5 shadow-[2px_2px_0px_0px_rgba(27,27,27,1)]">
            {/* Title block with Action (no page number) */}
            <div className="border-b border-neutral-300 pb-3 mb-4">
              <h3 className="font-accent text-[42px] leading-[40px] uppercase text-[#1b1b1b] tracking-wider">
                Action
              </h3>
            </div>

            {/* List with no page numbers as in screenshot */}
            <div className="space-y-4">
              {/* Time */}
              <button
                id="item-rule-time"
                onClick={() => onSelectItem(manualSections[2].items[0])}
                className="group flex w-full cursor-pointer justify-between font-serif text-[17px] font-semibold text-[#1b1b1b] hover:text-blood-red"
              >
                <span className="group-hover:underline">Time</span>
              </button>

              {/* Using Dice */}
              <div className="space-y-2">
                <button
                  id="item-rule-using-dice"
                  onClick={() => onSelectItem(manualSections[2].items[1])}
                  className="group flex w-full cursor-pointer justify-between font-serif text-[17px] font-semibold text-[#1b1b1b] hover:text-blood-red"
                >
                  <span className="group-hover:underline">Using Dice</span>
                </button>

                {/* Simple Tests (Indented) */}
                <button
                  id="item-rule-simple-tests"
                  onClick={() => onSelectItem(manualSections[2].items[2])}
                  className="group flex w-full cursor-pointer justify-between pl-6 font-serif text-[17px] text-neutral-600 hover:text-blood-red"
                >
                  <span className="italic group-hover:underline">Simple Tests</span>
                </button>

                {/* Dice Pools (Indented) */}
                <button
                  id="item-rule-dice-pools"
                  onClick={() => onSelectItem(manualSections[2].items[3])}
                  className="group flex w-full cursor-pointer justify-between pl-6 font-serif text-[17px] text-neutral-600 hover:text-blood-red"
                >
                  <span className="italic group-hover:underline">Dice Pools</span>
                </button>
              </div>

              {/* The Golden Rule */}
              <button
                id="item-rule-the-golden-rule"
                onClick={() => onSelectItem(manualSections[2].items[4])}
                className="group flex w-full cursor-pointer items-end justify-between font-serif text-[17px] text-[#1b1b1b] hover:text-blood-red"
              >
                <span className="font-semibold text-left group-hover:underline">The Golden Rule</span>
                <span className="mx-2 mb-1 flex-grow border-b border-dotted border-[#1b1b1b]/30 group-hover:border-blood-red" />
                <span className="font-mono text-xs font-bold bg-neutral-200/50 px-1.5 group-hover:bg-blood-red group-hover:text-white transition-colors">131</span>
              </button>

              {/* Ways of the Werewolves */}
              <div className="space-y-2 pt-1">
                <button
                  id="item-rule-ways-of-the-werewolves"
                  onClick={() => onSelectItem(manualSections[2].items[5])}
                  className="group flex w-full cursor-pointer justify-between font-serif text-[17px] font-semibold text-[#1b1b1b] hover:text-blood-red"
                >
                  <span className="group-hover:underline">Ways of the Werewolves</span>
                </button>

                {/* Rage (Indented) */}
                <button
                  id="item-rule-rage"
                  onClick={() => onSelectItem(manualSections[2].items[6])}
                  className="group flex w-full cursor-pointer justify-between pl-6 font-serif text-[17px] text-neutral-600 hover:text-blood-red"
                >
                  <span className="italic group-hover:underline">Rage</span>
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* Persistent Page Divider Bar */}
      <div className="mt-12 h-0.5 bg-[#1b1b1b]" />

      {/* SCRIPT Section Header */}
      <div className="mt-8">
        <h3 className="font-accent text-3xl uppercase tracking-widest text-[#1b1b1b]">
          SCRIPT
        </h3>
      </div>

      {/* Informational Action Boxes below manual */}
      <section className="mt-4 grid grid-cols-1 gap-6 md:grid-cols-2">
        {/* Dice Tool Banner block */}
        <div
          onClick={onOpenDiceRoller}
          className="flex cursor-pointer items-start gap-4 border-2 border-[#1b1b1b] bg-[#e6e2d8]/20 p-5 shadow-[4px_4px_0px_0px_rgba(217,119,6,1)] hover:bg-[#e6e2d8]/30"
        >
          <div className="border-2 border-[#1b1b1b] bg-white p-2 text-amber-700 shadow-[2px_2px_0px_0px_rgba(27,27,27,1)] select-none">
            <Dice5 className="h-6 w-6 stroke-[2]" />
          </div>
          <div>
            <h4 className="font-accent text-lg uppercase tracking-wide text-[#1b1b1b]">
              RPG d10 Dice Pool Simulator
            </h4>
            <p className="font-serif text-sm text-neutral-600 mt-1">
              Roll real ten-sided dice inside our operational mainframe simulator. Test dice pools, target difficulties, and analyze cancellations.
            </p>
          </div>
        </div>

        {/* Character Directory Block */}
        <div
          onClick={onJoinPartyClick}
          className="flex cursor-pointer items-start gap-4 border-2 border-[#1b1b1b] bg-[#e6e2d8]/20 p-5 shadow-[4px_4px_0px_0px_rgba(212,74,0,1)] hover:bg-[#e6e2d8]/30"
        >
          <div className="border-2 border-[#1b1b1b] bg-white p-2 text-blood-red shadow-[2px_2px_0px_0px_rgba(27,27,27,1)] select-none">
            <UserPlus className="h-6 w-6 stroke-[2]" />
          </div>
          <div>
            <h4 className="font-accent text-lg uppercase tracking-wide text-[#1b1b1b]">
              Join Chronos Systems Core Party
            </h4>
            <p className="font-serif text-sm text-neutral-600 mt-1">
              Connect your character file to the 1970 manual register. Unlock customized werewolf lineage records and tribe alignments.
            </p>
          </div>
        </div>
      </section>
      
      {/* Footer copyright section is handled globally in App.tsx */}
    </div>
  );
}
