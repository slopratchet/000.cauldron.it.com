import React from 'react';
import {
  User,
  FileText,
  Settings,
  SquareTerminal,
  Power,
  Download,
  TerminalSquare,
  Workflow,
  Activity
} from 'lucide-react';

export default function App() {
  const imgUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDenAoBDLerdZlPdMhOwkpKexVRhKNHkdImiJ4N0TgC3U6sorF6Aiw751VQLuZQAJehGN2N8pkYH5dPRhGtmPJNmnDylCI0Ubx2MsG16L7JH7LmCHgQCHcmKPMuVBBVylphJTh4MNxTNsL8fwSW65hRH85QYmk54-F1Mbd9NRG57rH7C_kAiFxvsV_FgCNM2RNleZI0KpCQf";

  return (
    <div className="flex flex-col h-screen bg-[#fcf9f8] text-[#1b1c1c] select-none font-['Source_Serif_4',serif]">
      <div className="flex flex-1 overflow-hidden">
        {/* MAIN AREA */}
        <main className="flex-1 flex flex-col pt-8 px-10 pb-0 overflow-y-auto overflow-x-hidden relative scrollbar-hide">
          <div className="flex flex-col flex-1 max-w-[1240px] w-full mx-auto">
            <h2 className="font-['Archivo_Narrow',sans-serif] text-[72px] leading-none font-[900] uppercase tracking-tighter mb-2">
              Biomechanical Anatomy
            </h2>
            <p className="font-['JetBrains_Mono',monospace] text-[11px] font-[500] leading-relaxed text-[#64635c] break-all max-w-[100%] mb-12 tracking-widest uppercase">
              CATALOG_ID: {imgUrl}
            </p>

            {/* Content Grid */}
            <div className="flex gap-10 items-stretch shrink-0 h-[580px]">
               {/* Left Col - Image */}
               <div className="flex-1 border-[3px] border-[#1b1c1c] flex flex-col relative bg-[#fcf9f8]">
                  <div className="absolute top-0 left-0 bg-[#1b1c1c] text-[#fcf9f8] px-4 py-[6px] font-['JetBrains_Mono',monospace] text-[13px] font-[700] tracking-widest uppercase z-10 border-b-[3px] border-r-[3px] border-[#1b1c1c]">
                    VISUAL_FEED_01
                  </div>
                  <div className="flex-1 p-[40px] flex items-center justify-center overflow-hidden h-full mt-4">
                    <img 
                      src={imgUrl} 
                      alt="Anatomy Diagram" 
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-contain mix-blend-multiply filter contrast-125 saturate-0" 
                    />
                  </div>
                  <div className="bg-[#1b1c1c] text-[#fcf9f8] px-6 py-3 font-['JetBrains_Mono',monospace] text-[14px] font-[700] tracking-[0.1em] uppercase border-t-[3px] border-[#1b1c1c]">
                    THE TOME: BIOMECHANICAL ANATOMY - 1970 EDITION
                  </div>
               </div>

               {/* Right Col - Stats Lists */}
               <div className="w-[420px] flex flex-col space-y-8 shrink-0 pt-0">
                  
                  {/* RIGGING COMPLEXITY */}
                  <div>
                    <div className="bg-[#1b1c1c] text-[#fcf9f8] px-4 py-[6px] font-['JetBrains_Mono',monospace] text-[13px] font-[700] tracking-widest uppercase inline-block">
                      RIGGING COMPLE...
                    </div>
                    <div className="border-[3px] border-[#1b1c1c] flex flex-col mt-[-1px]">
                      <div className="bg-[#e2e0d7] p-[12px] px-5 border-b-[3px] border-[#1b1c1c] font-['JetBrains_Mono',monospace] text-[14px] font-[700] tracking-[0.15em] uppercase">JOINT_NODES</div>
                      <div className="p-[12px] px-5 border-b-[3px] border-[#1b1c1c] font-['JetBrains_Mono',monospace] text-[14px] font-[700] tracking-[0.15em] uppercase">WEIGHT_MAPS</div>
                      <div className="bg-[#e2e0d7] p-[12px] px-5 border-b-[3px] border-[#1b1c1c] font-['JetBrains_Mono',monospace] text-[14px] font-[700] tracking-[0.15em] uppercase">DEFORMERS</div>
                      <div className="p-[12px] px-5 font-['JetBrains_Mono',monospace] text-[14px] font-[700] tracking-[0.15em] uppercase">DRIVEN_KEYS</div>
                    </div>
                  </div>

                  {/* ANIMATION LOOP */}
                  <div>
                    <div className="bg-[#1b1c1c] text-[#fcf9f8] px-4 py-[6px] flex items-center space-x-3 font-['JetBrains_Mono',monospace] text-[13px] font-[700] tracking-widest uppercase inline-block">
                      <div className="w-[10px] h-[10px] bg-[#ba1a1a] inline-block mb-[-2px]"></div>
                      <span className="inline-block">ANIMATION L...</span>
                    </div>
                    <div className="border-[3px] border-[#1b1c1c] flex flex-col mt-[-1px]">
                       <div className="p-4 flex flex-col bg-[#e2e0d7] justify-center min-h-[96px]">
                          <div className="text-center font-['JetBrains_Mono',monospace] text-[11px] font-[700] tracking-[0.2em] text-[#64635c] mb-2 uppercase">IDLE</div>
                          <div className="text-center font-['JetBrains_Mono',monospace] text-[22px] font-[900] tracking-[0.15em] uppercase text-[#1b1c1c]">ACTIVE</div>
                       </div>
                    </div>
                  </div>

                  {/* MATERIAL LOD B... */}
                  <div className="flex-1 flex flex-col">
                    <div className="bg-[#1b1c1c] text-[#fcf9f8] px-4 py-[6px] font-['JetBrains_Mono',monospace] text-[13px] font-[700] tracking-widest uppercase inline-block self-start">
                      MATERIAL LOD B...
                    </div>
                    <div className="border-[3px] border-[#1b1c1c] flex flex-col p-6 space-y-[24px] mt-[-1px] flex-1 justify-center bg-[#fcf9f8]">
                       <ProgressBar label="LOD_0 (HIGH)" percent={100} />
                       <ProgressBar label="LOD_1 (MED)" percent={100} />
                       <ProgressBar label="LOD_2 (LOW)" percent={22} /> 
                    </div>
                  </div>
               </div>
            </div>

            {/* Bottom Core Log */}
            <div className="flex gap-10 mt-24 pb-16 shrink-0">
               <div className="flex-1 flex flex-col">
                  <div className="bg-[#1b1c1c] text-[#fcf9f8] px-4 py-[6px] font-['JetBrains_Mono',monospace] text-[13px] font-[700] tracking-widest uppercase self-start border-[1px] border-[#1b1c1c]">
                    CORE_LOG_ENTRY
                  </div>
                  <div className="border-[3px] border-[#1b1c1c] p-[32px] mt-[-1px] bg-[#fcf9f8]">
                    <p className="text-[20px] leading-[1.7] text-justify text-[#1b1c1c] font-['Source_Serif_4',serif]">
                      Observed specimen exhibits high-frequency neural pulse activity. The skeletal structure, composed of "Synthetic Exoskyelten", suggests a 1970-era industrial fabrication combined with illegal cybernetic grafting. Initial scans indicate a volatile rigging complexity that exceeds standard system parameters. Caution is advised when engaging animation loops at high velocities.
                    </p>
                  </div>
               </div>
               <button className="min-w-[280px] border-[3px] border-[#1b1c1c] flex items-center justify-center px-10 py-6 hover:bg-[#1b1c1c] hover:text-[#fcf9f8] transition-colors mt-[30px] group bg-[#fcf9f8]">
                  <Download size={32} className="mr-6 stroke-[2.5px]" />
                  <span className="font-['JetBrains_Mono',monospace] font-[700] tracking-[0.15em] text-[20px]">EXPORT</span>
               </button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

function ProgressBar({ label, percent }: { label: string; percent: number }) {
  return (
    <div className="flex flex-col space-y-[12px] font-['JetBrains_Mono',monospace]">
       <div className="text-[13px] font-[700] tracking-[0.15em] uppercase text-[#1b1c1c]">{label}</div>
       <div className="bg-[#e5e2da] h-[18px] w-full border-[3px] border-[#1b1c1c] flex">
         <div className="bg-[#1b1c1c] h-full" style={{ width: `${percent}%` }}></div>
       </div>
    </div>
  );
}

