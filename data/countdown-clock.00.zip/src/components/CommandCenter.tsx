import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Activity,
  Terminal,
  BookOpen,
  Settings,
  Flame,
  Volume2,
  VolumeX,
  Play,
  Pause,
  RotateCcw,
  PlusCircle,
  Clock,
  Shield,
  FileText,
  User,
  ExternalLink,
  ChevronRight,
  Database,
  ArrowLeft,
  X,
  AlertOctagon
} from 'lucide-react';
import CornerAccents from './CornerAccents';
import { LogEntry, ArchiveFile } from '../types';
import { playClick, playBeep, playSuccess } from '../utils/audio';

interface CommandCenterProps {
  timeInSeconds: number;
  setTimeInSeconds: React.Dispatch<React.SetStateAction<number>>;
  isTimerRunning: boolean;
  setIsTimerRunning: (val: boolean) => void;
  systemStatus: string;
  setSystemStatus: (status: string) => void;
  onExit: () => void;
  key?: string | number;
}

export default function CommandCenter({
  timeInSeconds,
  setTimeInSeconds,
  isTimerRunning,
  setIsTimerRunning,
  systemStatus,
  setSystemStatus,
  onExit
}: CommandCenterProps) {
  const [activeTab, setActiveTab] = useState<'CONSOLE' | 'ARCHIVES' | 'REACTOR' | 'CONFIG'>('REACTOR');
  const [stabilityLevel, setStabilityLevel] = useState<number>(98.42);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  
  // Custom Log state
  const [logs, setLogs] = useState<LogEntry[]>([
    { id: '1', timestamp: '06:58:19', level: 'SYSTEM', message: 'Mainframe connected. Ingress socket bound to port 3000.', source: 'NETWORK' },
    { id: '2', timestamp: '06:58:20', level: 'INFO', message: 'Initiating Sequence Alpha. Epoch decay coefficient set to 1.00x.', source: 'SCHEDULER' },
    { id: '3', timestamp: '06:58:21', level: 'WARN', message: 'Stochastic variance detected in radioactive stability module.', source: 'REACTOR' },
    { id: '4', timestamp: '06:58:22', level: 'SYSTEM', message: 'User bypass authenticated. Manual superintendent terminal unlocked.', source: 'SECURITY' }
  ]);
  const [logInput, setLogInput] = useState<string>('');
  const [logLevel, setLogLevel] = useState<'INFO' | 'WARN' | 'ERROR' | 'SYSTEM'>('INFO');
  const logsEndRef = useRef<HTMLDivElement | null>(null);

  // Custom Archives state
  const [archives, setArchives] = useState<ArchiveFile[]>([
    {
      id: 'doc-alpha',
      title: 'The Epoch Alpha Directive',
      date: '1974-10-12',
      classification: 'EYES_ONLY',
      author: 'Dr. Arthur Sterling, Chief Superintendent',
      content: `This document establishes the parameters for the Alpha countdown. We have determined that the temporal epoch must be actively monitored. If the counter reaches zero without manual bypass synchronization, the stabilization decay matrix collapses. It is imperative that the supervisor maintains an active presence. The override code '7957' remains static across this system revision to ensure critical recovery access under harsh magnetic storm scenarios.`
    },
    {
      id: 'doc-beta',
      title: 'Stochastic Stability Calculations',
      date: '1975-02-28',
      classification: 'RESTRICTED',
      author: 'Lieutenant M. Vance, Lead Engineer',
      content: `Observations of the reactor's core stability show an inverse relationship with the decay rate. Toggling the stability slider directly impacts core temperature. If stability drops below 30%, visual and audio sirens are triggered. We have equipped the terminal with an emergency core-stabilization coolant bypass. In the event of stability decay below critical levels, immediately toggle the cooling levers to avoid containment breach.`
    },
    {
      id: 'doc-gamma',
      title: 'Maintenance Log: Port 3000 Leak',
      date: '1976-08-04',
      classification: 'UNCLASSIFIED',
      author: 'S. Cooper, Chief Technician',
      content: `The reverse proxy on Node 3000 has been acting up. We discovered that HMR (Hot Module Replacement) was causing memory leaks inside the telemetry loops. The control plane has disabled HMR permanently to preserve vacuum tube integrity. All future system edits will require full manual frame reloads. This guarantees the highest level of deterministic output.`
    }
  ]);
  const [selectedArchive, setSelectedArchive] = useState<ArchiveFile | null>(archives[0]);
  const [newArchiveTitle, setNewArchiveTitle] = useState('');
  const [newArchiveContent, setNewArchiveContent] = useState('');
  const [showAddArchive, setShowAddArchive] = useState(false);

  // Auto-scroll logs
  useEffect(() => {
    if (logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs]);

  // Periodic simulated logs
  useEffect(() => {
    const interval = setInterval(() => {
      if (isTimerRunning) {
        const randomEvents = [
          { msg: 'Epoch clock tick processed successfully.', level: 'INFO' as const, src: 'TIMEKEEPER' },
          { msg: 'Telemetry cycle completed. Drift: +0.003ms.', level: 'INFO' as const, src: 'DIAGNOSTICS' },
          { msg: 'Minor grid variance detected. Auto-balancing grid flux.', level: 'WARN' as const, src: 'REACTOR' }
        ];
        const event = randomEvents[Math.floor(Math.random() * randomEvents.length)];
        
        // Only trigger warning logs sometimes
        if (Math.random() > 0.6) {
          const now = new Date();
          const timestamp = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;
          
          setLogs(prev => [
            ...prev,
            {
              id: Date.now().toString(),
              timestamp,
              level: event.level,
              message: event.msg,
              source: event.src
            }
          ]);

          if (soundEnabled && event.level === 'WARN') {
            playBeep(400, 0.05, 'triangle', 0.02);
          }
        }
      }
    }, 4000);

    return () => clearInterval(interval);
  }, [isTimerRunning, soundEnabled]);

  // Audio trigger on state shifts
  const triggerBeep = (freq = 600, duration = 0.05) => {
    if (soundEnabled) {
      playBeep(freq, duration, 'sine', 0.05);
    }
  };

  // Switch tabs helper
  const selectTab = (tab: typeof activeTab) => {
    playClick();
    setActiveTab(tab);
  };

  // Add custom log
  const handleAddLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!logInput.trim()) return;
    
    playClick();
    const now = new Date();
    const timestamp = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;
    
    const newLog: LogEntry = {
      id: Date.now().toString(),
      timestamp,
      level: logLevel,
      message: logInput.trim(),
      source: 'SUPERINTENDENT'
    };

    setLogs(prev => [...prev, newLog]);
    setLogInput('');
  };

  // Submit custom archive
  const handleAddArchive = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newArchiveTitle.trim() || !newArchiveContent.trim()) return;

    playSuccess();
    const newDoc: ArchiveFile = {
      id: `doc-${Date.now()}`,
      title: newArchiveTitle.trim(),
      date: new Date().toISOString().split('T')[0],
      classification: 'SUPERINTENDENT_LOG',
      author: 'Manual Terminal Entry',
      content: newArchiveContent.trim()
    };

    setArchives(prev => [newDoc, ...prev]);
    setSelectedArchive(newDoc);
    setNewArchiveTitle('');
    setNewArchiveContent('');
    setShowAddArchive(false);
  };

  // Toggle Reactor Timer
  const handleToggleTimer = () => {
    triggerBeep(isTimerRunning ? 440 : 880, 0.1);
    setIsTimerRunning(!isTimerRunning);
  };

  // Format seconds to HH:MM:SS
  const formatTime = (time: number) => {
    const h = Math.floor(time / 3600).toString().padStart(2, '0');
    const m = Math.floor((time % 3600) / 60).toString().padStart(2, '0');
    const s = (time % 60).toString().padStart(2, '0');
    return `${h}:${m}:${s}`;
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="w-full h-full flex flex-col border-4 border-black bg-surface relative overflow-hidden"
      id="command-center-container"
    >
      <CornerAccents size="w-8 h-8" borderColor="border-black" />

      {/* Main Bar / Header */}
      <div className="w-full bg-black text-surface border-b-4 border-black px-6 py-4 flex justify-between items-center shrink-0" id="command-center-header">
        <div className="flex items-center gap-3">
          <Activity className="w-5 h-5 text-red-500 animate-pulse" />
          <span className="font-label font-bold text-xs md:text-sm tracking-[0.2em] uppercase">
            SUPERINTENDENT LEVEL ACCESS (COMMAND CONSOLE)
          </span>
        </div>
        <button
          onClick={() => {
            playClick();
            onExit();
          }}
          className="font-label text-xs uppercase bg-red-700 text-surface border-2 border-red-900 px-4 py-1.5 hover:bg-red-800 transition-colors flex items-center gap-1 cursor-pointer shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] active:translate-y-[2px] active:shadow-none"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          Lock Terminal
        </button>
      </div>

      {/* Primary Layout Area */}
      <div className="flex-grow flex overflow-hidden">
        
        {/* ASYMMETRIC SIDEBAR: Narrow utility selector */}
        <div className="w-[70px] md:w-[220px] bg-surface-container-high border-r-4 border-black flex flex-col justify-between shrink-0">
          {/* Top Tabs Grid */}
          <div className="flex flex-col">
            <div className="hidden md:block p-4 border-b-2 border-black bg-surface-container-highest">
              <span className="text-[10px] font-label text-neutral-500 uppercase tracking-widest block">OPERATING SYSTEM</span>
              <span className="text-xs font-label font-bold text-black block">ARCHIVE_OS_v1.74</span>
            </div>

            {/* Tab: Reactor Controls */}
            <button
              onClick={() => selectTab('REACTOR')}
              className={`w-full text-left p-4 md:p-5 border-b-2 border-black font-label font-bold text-sm uppercase flex items-center justify-center md:justify-start gap-3 transition-colors cursor-pointer ${
                activeTab === 'REACTOR'
                  ? 'bg-black text-surface'
                  : 'hover:bg-surface-container-highest text-black'
              }`}
            >
              <Flame className={`w-5 h-5 ${activeTab === 'REACTOR' ? 'text-red-500' : 'text-neutral-600'}`} />
              <span className="hidden md:inline">Reactor Matrix</span>
            </button>

            {/* Tab: System Console / Logs */}
            <button
              onClick={() => selectTab('CONSOLE')}
              className={`w-full text-left p-4 md:p-5 border-b-2 border-black font-label font-bold text-sm uppercase flex items-center justify-center md:justify-start gap-3 transition-colors cursor-pointer ${
                activeTab === 'CONSOLE'
                  ? 'bg-black text-surface'
                  : 'hover:bg-surface-container-highest text-black'
              }`}
            >
              <Terminal className={`w-5 h-5 ${activeTab === 'CONSOLE' ? 'text-green-500' : 'text-neutral-600'}`} />
              <span className="hidden md:inline">Log Console</span>
            </button>

            {/* Tab: Archive Records (Lore) */}
            <button
              onClick={() => selectTab('ARCHIVES')}
              className={`w-full text-left p-4 md:p-5 border-b-2 border-black font-label font-bold text-sm uppercase flex items-center justify-center md:justify-start gap-3 transition-colors cursor-pointer ${
                activeTab === 'ARCHIVES'
                  ? 'bg-black text-surface'
                  : 'hover:bg-surface-container-highest text-black'
              }`}
            >
              <BookOpen className={`w-5 h-5 ${activeTab === 'ARCHIVES' ? 'text-yellow-600' : 'text-neutral-600'}`} />
              <span className="hidden md:inline">Archive Files</span>
            </button>

            {/* Tab: Terminal Config */}
            <button
              onClick={() => selectTab('CONFIG')}
              className={`w-full text-left p-4 md:p-5 border-b-2 border-black font-label font-bold text-sm uppercase flex items-center justify-center md:justify-start gap-3 transition-colors cursor-pointer ${
                activeTab === 'CONFIG'
                  ? 'bg-black text-surface'
                  : 'hover:bg-surface-container-highest text-black'
              }`}
            >
              <Settings className={`w-5 h-5 ${activeTab === 'CONFIG' ? 'text-blue-500' : 'text-neutral-600'}`} />
              <span className="hidden md:inline">Sys Config</span>
            </button>
          </div>

          {/* Bottom Audio and Ref Sidebar block */}
          <div className="p-3 md:p-4 border-t-2 border-black space-y-3 bg-surface-container-low text-center md:text-left">
            <button
              onClick={() => {
                setSoundEnabled(!soundEnabled);
                playBeep(800, 0.05, 'sine', 0.1);
              }}
              className="w-full flex items-center justify-center md:justify-start gap-2 text-xs font-label uppercase text-neutral-700 hover:text-black hover:bg-surface-container-high py-1 px-2 border border-neutral-400 transition-all cursor-pointer"
            >
              {soundEnabled ? (
                <>
                  <Volume2 className="w-4 h-4 text-green-600 shrink-0" />
                  <span className="hidden md:inline">Mute Audio</span>
                </>
              ) : (
                <>
                  <VolumeX className="w-4 h-4 text-red-500 shrink-0" />
                  <span className="hidden md:inline">Enable Audio</span>
                </>
              )}
            </button>

            <div className="hidden md:block text-[9px] font-mono text-neutral-500 border-t border-dashed border-neutral-400 pt-2 leading-tight">
              CONTAINER_ID:<br />
              <span className="text-black font-semibold">AIS_BUILD_CLOUDRUN</span>
            </div>
          </div>
        </div>

        {/* EXPANSIVE CONTENT STAGE */}
        <div className="flex-grow flex flex-col bg-surface overflow-y-auto">
          
          {/* TAB CONTENT: REACTOR controls */}
          {activeTab === 'REACTOR' && (
            <div className="p-6 md:p-8 space-y-8">
              <div className="border-b-2 border-black pb-4">
                <span className="font-label text-xs uppercase bg-red-600 text-surface font-bold px-2.5 py-1">MATRIX OPERATION CENTER</span>
                <h2 className="font-headline text-3xl font-black mt-3 text-black uppercase">EPOCH PARAMETERS & FLUX DYNAMICS</h2>
                <p className="font-body text-neutral-700 text-lg mt-1 italic">
                  Calibrate decay coefficients, adjust stability matrices, and pause the physical progression.
                </p>
              </div>

              {/* Grid with main timer settings and status cards */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Core Live Monitor Panel */}
                <div className="lg:col-span-7 border-4 border-black p-6 bg-surface-container-low relative shadow-[6px_6px_0px_0px_rgba(0,0,0,1)]">
                  <CornerAccents size="w-4 h-4" />
                  <span className="text-[10px] font-label font-bold text-neutral-500 uppercase tracking-widest block">DECAY TELEMETRY</span>
                  <h3 className="font-headline text-xl font-bold uppercase text-black mt-1 mb-6">REAL-TIME ATOMIC SEQUENCE</h3>

                  {/* Monospace Countdown readout */}
                  <div className="bg-black text-[#50fa7b] font-label font-black text-4xl sm:text-5xl md:text-6xl p-6 border-2 border-black shadow-inner tracking-wider flex items-center justify-between font-mono mb-6">
                    <Clock className="w-8 h-8 text-green-500 animate-pulse" />
                    <span className="tabular-nums" id="reactor-timer-display">{formatTime(timeInSeconds)}</span>
                  </div>

                  {/* Controls Row */}
                  <div className="grid grid-cols-3 gap-3">
                    <button
                      onClick={handleToggleTimer}
                      className={`font-label font-bold text-xs md:text-sm py-3.5 border-2 border-black flex items-center justify-center gap-1.5 transition-all shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] active:translate-y-[2px] active:shadow-none cursor-pointer ${
                        isTimerRunning
                          ? 'bg-amber-100 text-amber-900 hover:bg-amber-200'
                          : 'bg-green-100 text-green-900 hover:bg-green-200'
                      }`}
                    >
                      {isTimerRunning ? (
                        <>
                          <Pause className="w-4 h-4" />
                          PAUSE TIMER
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4" />
                          RESUME TIMER
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => {
                        triggerBeep(300, 0.1);
                        setTimeInSeconds(8 * 3600); // Reset to 8 hours
                      }}
                      className="bg-neutral-100 text-black border-2 border-black font-label font-bold text-xs md:text-sm py-3.5 flex items-center justify-center gap-1.5 hover:bg-neutral-200 transition-all shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] active:translate-y-[2px] active:shadow-none cursor-pointer"
                    >
                      <RotateCcw className="w-4 h-4" />
                      RESET 8H
                    </button>

                    <button
                      onClick={() => {
                        triggerBeep(1000, 0.1);
                        setTimeInSeconds((prev) => Math.max(0, prev - 3600)); // Subtract an hour
                      }}
                      className="bg-red-50 text-red-900 border-2 border-red-900 font-label font-bold text-xs md:text-sm py-3.5 flex items-center justify-center gap-1.5 hover:bg-red-100 transition-all shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] active:translate-y-[2px] active:shadow-none cursor-pointer"
                    >
                      -1 HOUR
                    </button>
                  </div>
                </div>

                {/* Stability Matrix Regulator */}
                <div className="lg:col-span-5 border-4 border-black p-6 bg-surface-container relative shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] flex flex-col justify-between">
                  <CornerAccents size="w-4 h-4" />
                  <div>
                    <span className="text-[10px] font-label font-bold text-neutral-500 uppercase tracking-widest block">MANUAL CORE TUNING</span>
                    <h3 className="font-headline text-xl font-bold uppercase text-black mt-1 mb-4">STABILITY INDICES</h3>

                    {/* Stability Slider */}
                    <div className="space-y-4">
                      <div className="flex justify-between items-center font-label font-bold text-xs">
                        <span>CORE STABILITY LEVEL:</span>
                        <span className={stabilityLevel < 40 ? 'text-red-700 animate-pulse font-black' : 'text-black'}>
                          {stabilityLevel.toFixed(2)}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min="1"
                        max="100"
                        step="0.01"
                        value={stabilityLevel}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          setStabilityLevel(val);
                          if (val < 30) {
                            setSystemStatus('CRITICAL');
                            if (soundEnabled && Math.random() > 0.8) playBeep(260, 0.15, 'sawtooth', 0.05);
                          } else if (val < 70) {
                            setSystemStatus('DEGRADED');
                          } else {
                            setSystemStatus('STABLE');
                          }
                        }}
                        className="w-full accent-black cursor-pointer bg-neutral-300 h-2 border border-black"
                      />
                      <div className="flex justify-between text-[10px] font-label text-neutral-500 uppercase">
                        <span>0% COLLAPSE</span>
                        <span>50% NOMINAL</span>
                        <span>100% MAXIMUM</span>
                      </div>
                    </div>
                  </div>

                  {/* Stability diagnostic blocks */}
                  <div className="border-t-2 border-black pt-4 mt-6 space-y-2">
                    <div className="flex justify-between text-xs font-label">
                      <span>DECAY STATE PROFILE:</span>
                      <span className={`font-bold uppercase ${systemStatus === 'CRITICAL' ? 'text-red-700' : 'text-black'}`}>
                        {systemStatus}
                      </span>
                    </div>
                    <div className="flex justify-between text-xs font-label">
                      <span>COOLANT BYPASS:</span>
                      <span className="text-green-800 font-bold uppercase">ACTIVE (NOMINAL)</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Direct Quick Settings Bar */}
              <div className="border-2 border-black p-4 bg-surface-container-highest flex flex-col md:flex-row justify-between items-center gap-4">
                <div className="flex items-center gap-2">
                  <Settings className="w-5 h-5 text-black" />
                  <span className="font-label text-xs font-bold uppercase tracking-wider text-black">
                    QUICK RECALIBRATION:
                  </span>
                </div>
                <div className="flex gap-2 flex-wrap justify-center">
                  {['00:00:10', '00:05:00', '01:00:00', '12:00:00'].map((preset) => {
                    const parts = preset.split(':').map(Number);
                    const secs = parts[0] * 3600 + parts[1] * 60 + parts[2];
                    return (
                      <button
                        key={preset}
                        onClick={() => {
                          triggerBeep(700, 0.05);
                          setTimeInSeconds(secs);
                        }}
                        className="bg-surface text-black border border-black px-3 py-1 font-label text-xs uppercase hover:bg-black hover:text-surface transition-all cursor-pointer shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-y-[1px] active:shadow-none"
                      >
                        Set {preset}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB CONTENT: LOG CONSOLE */}
          {activeTab === 'CONSOLE' && (
            <div className="p-6 md:p-8 flex flex-col h-full space-y-4">
              <div className="border-b-2 border-black pb-4">
                <span className="font-label text-xs uppercase bg-green-700 text-surface font-bold px-2.5 py-1">SYSTEM_TELEMETRY_STREAM</span>
                <h2 className="font-headline text-3xl font-black mt-3 text-black uppercase">MAINFRAME LIVE MONITOR</h2>
                <p className="font-body text-neutral-700 text-lg mt-1 italic">
                  Read, filter, and append raw technical telemetry outputs from the server.
                </p>
              </div>

              {/* The Live Console Screen */}
              <div className="flex-grow border-4 border-black bg-black text-green-400 font-mono text-xs md:text-sm p-4 h-[350px] overflow-y-auto relative flex flex-col justify-between shadow-[inset_0px_0px_10px_0px_rgba(0,0,0,0.8)]">
                <div className="space-y-2.5">
                  {logs.map((log) => {
                    let levelColor = 'text-green-400';
                    if (log.level === 'WARN') levelColor = 'text-yellow-400';
                    if (log.level === 'ERROR') levelColor = 'text-red-500';
                    if (log.level === 'SYSTEM') levelColor = 'text-blue-400';

                    return (
                      <div key={log.id} className="flex flex-col md:flex-row md:items-start gap-1 md:gap-3 border-b border-neutral-900 pb-1.5">
                        <span className="text-neutral-500 shrink-0">[{log.timestamp}]</span>
                        <span className={`${levelColor} font-bold shrink-0 uppercase tracking-wider`}>
                          [{log.level}]
                        </span>
                        <span className="text-neutral-400 shrink-0 uppercase">[{log.source}]</span>
                        <span className="text-surface-dim font-medium break-all">{log.message}</span>
                      </div>
                    );
                  })}
                  <div ref={logsEndRef} />
                </div>
              </div>

              {/* Console Injection Form */}
              <form onSubmit={handleAddLog} className="border-4 border-black p-4 bg-surface-container-low grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
                <div className="md:col-span-2">
                  <select
                    value={logLevel}
                    onChange={(e) => {
                      playClick();
                      setLogLevel(e.target.value as any);
                    }}
                    className="w-full bg-surface text-black border-2 border-black p-2 font-label text-xs uppercase cursor-pointer"
                  >
                    <option value="INFO">INFO</option>
                    <option value="WARN">WARNING</option>
                    <option value="ERROR">ERROR</option>
                    <option value="SYSTEM">SYSTEM</option>
                  </select>
                </div>

                <div className="md:col-span-8 relative">
                  <span className="absolute left-3 top-2.5 font-mono text-neutral-500">$</span>
                  <input
                    type="text"
                    value={logInput}
                    onChange={(e) => setLogInput(e.target.value)}
                    placeholder="Append manual telemetry message to console feed..."
                    className="w-full bg-surface text-black border-2 border-black p-2 pl-7 font-mono text-xs md:text-sm focus:outline-none"
                  />
                </div>

                <div className="md:col-span-2">
                  <button
                    type="submit"
                    className="w-full bg-black text-surface hover:bg-neutral-900 border-2 border-transparent py-2 px-4 font-label text-xs uppercase font-bold cursor-pointer transition-all shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-y-[1px] active:shadow-none"
                  >
                    Inject Log
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB CONTENT: ARCHIVE RECORDS (Lore serif dossiers) */}
          {activeTab === 'ARCHIVES' && (
            <div className="p-6 md:p-8 flex flex-col h-full space-y-6">
              <div className="border-b-2 border-black pb-4 flex justify-between items-end flex-wrap gap-4">
                <div>
                  <span className="font-label text-xs uppercase bg-yellow-600 text-surface font-bold px-2.5 py-1">DOCUMENT_DOSSIER_ARCHIVE</span>
                  <h2 className="font-headline text-3xl font-black mt-3 text-black uppercase">THE CORE CHRONICLES</h2>
                  <p className="font-body text-neutral-700 text-lg mt-1 italic">
                    Read the historic journals and secret technical guidelines written by early mainframe superintendents.
                  </p>
                </div>

                <button
                  onClick={() => {
                    playClick();
                    setShowAddArchive(!showAddArchive);
                  }}
                  className="bg-black text-surface border-2 border-transparent px-4 py-2 font-label text-xs uppercase font-bold flex items-center gap-2 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] active:translate-y-[1px] active:shadow-none cursor-pointer"
                >
                  <PlusCircle className="w-4 h-4" />
                  Write Journal
                </button>
              </div>

              {showAddArchive ? (
                <motion.form
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  onSubmit={handleAddArchive}
                  className="border-4 border-black p-6 bg-surface-container-low space-y-4 relative"
                >
                  <button
                    type="button"
                    onClick={() => setShowAddArchive(false)}
                    className="absolute top-4 right-4 text-neutral-500 hover:text-black cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                  <h3 className="font-headline font-bold text-lg uppercase text-black">Compose New Archive Log</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="font-label text-xs font-bold uppercase text-neutral-600">Dossier / Log Title</label>
                      <input
                        type="text"
                        required
                        value={newArchiveTitle}
                        onChange={(e) => setNewArchiveTitle(e.target.value)}
                        placeholder="e.g. Sub-Reactor Fuel Variance"
                        className="w-full bg-surface text-black border-2 border-black p-2 font-label text-sm"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="font-label text-xs font-bold uppercase text-neutral-600">Classification Level</label>
                      <div className="p-2 bg-surface border-2 border-black font-label text-xs uppercase font-bold">
                        SUPERINTENDENT_LOG_EYES_ONLY
                      </div>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="font-label text-xs font-bold uppercase text-neutral-600">Journal Content (rendered in Newsreader serif)</label>
                    <textarea
                      required
                      rows={6}
                      value={newArchiveContent}
                      onChange={(e) => setNewArchiveContent(e.target.value)}
                      placeholder="Type the log dossier records here..."
                      className="w-full bg-surface text-black border-2 border-black p-3 font-body text-base"
                    />
                  </div>

                  <div className="flex justify-end gap-3">
                    <button
                      type="button"
                      onClick={() => setShowAddArchive(false)}
                      className="border-2 border-black px-4 py-2 font-label text-xs uppercase hover:bg-neutral-100 transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="bg-black text-surface border-2 border-transparent px-5 py-2 font-label text-xs uppercase font-bold hover:bg-neutral-900 transition-colors cursor-pointer shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]"
                    >
                      Commit Journal Log
                    </button>
                  </div>
                </motion.form>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start flex-grow">
                  
                  {/* Left Column list */}
                  <div className="lg:col-span-4 border-4 border-black bg-surface-container shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                    <div className="p-3 bg-black text-surface font-label text-xs uppercase font-bold tracking-wider">
                      INDEX OF RECORDS
                    </div>
                    <div className="divide-y-2 divide-black">
                      {archives.map((item) => (
                        <button
                          key={item.id}
                          onClick={() => {
                            playClick();
                            setSelectedArchive(item);
                          }}
                          className={`w-full text-left p-4 hover:bg-surface-container-high transition-colors cursor-pointer block ${
                            selectedArchive?.id === item.id ? 'bg-surface-container-highest border-l-8 border-black' : ''
                          }`}
                        >
                          <span className="text-[9px] font-mono text-neutral-500 uppercase block">{item.date}</span>
                          <span className="font-headline font-bold text-sm text-black block uppercase tracking-tight mt-1">
                            {item.title}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Right Column: Record Viewer */}
                  <div className="lg:col-span-8 border-4 border-black p-6 md:p-8 bg-surface-container-low shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] relative">
                    <CornerAccents size="w-6 h-6" />
                    
                    {selectedArchive ? (
                      <div className="space-y-6">
                        {/* Dossier Header metadata */}
                        <div className="border-b-2 border-dashed border-neutral-400 pb-4">
                          <div className="flex justify-between items-center flex-wrap gap-2">
                            <span className="text-xs font-label bg-black text-surface px-2 py-0.5 uppercase tracking-widest font-bold">
                              {selectedArchive.classification}
                            </span>
                            <span className="text-xs font-label text-neutral-600 font-bold font-mono">
                              DATE: {selectedArchive.date}
                            </span>
                          </div>
                          <h3 className="font-headline text-2xl font-black mt-3 text-black uppercase tracking-tight">
                            {selectedArchive.title}
                          </h3>
                          <div className="flex items-center gap-1 text-xs font-label text-neutral-600 mt-1">
                            <User className="w-3.5 h-3.5" />
                            <span>BY: {selectedArchive.author}</span>
                          </div>
                        </div>

                        {/* Dossier Content in sophisticated Newsreader serif */}
                        <div className="font-body text-base md:text-lg leading-relaxed text-neutral-900 space-y-4 font-normal" id="archive-reader-content">
                          {selectedArchive.content.split('\n\n').map((para, i) => (
                            <p key={i}>{para}</p>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-12 text-neutral-500 font-body">
                        Select a record file from the ledger index to read classified dossiers.
                      </div>
                    )}
                  </div>

                </div>
              )}
            </div>
          )}

          {/* TAB CONTENT: TERMINAL CONFIG */}
          {activeTab === 'CONFIG' && (
            <div className="p-6 md:p-8 space-y-8">
              <div className="border-b-2 border-black pb-4">
                <span className="font-label text-xs uppercase bg-blue-700 text-surface font-bold px-2.5 py-1">TERMINAL_PREFERENCE_REGISTRY</span>
                <h2 className="font-headline text-3xl font-black mt-3 text-black uppercase">SYSTEM & ENVIRONMENT MATRIX</h2>
                <p className="font-body text-neutral-700 text-lg mt-1 italic">
                  Review build settings, toggle warning triggers, and explore standard system capabilities.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Build details info card */}
                <div className="border-4 border-black p-6 bg-surface-container-low shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] relative">
                  <CornerAccents size="w-4 h-4" />
                  <span className="text-[10px] font-label font-bold text-neutral-500 uppercase tracking-widest block">ENVIRONMENT LEDGER</span>
                  <h3 className="font-headline text-lg font-bold uppercase text-black mt-1 mb-4">CONTAINER RUNTIME</h3>

                  <div className="space-y-3 font-label text-xs">
                    <div className="flex justify-between border-b border-dashed border-neutral-300 pb-2">
                      <span className="text-neutral-500 font-bold uppercase">INGRESS PORT:</span>
                      <span className="font-mono text-black font-bold">PORT 3000 (HTTP)</span>
                    </div>
                    <div className="flex justify-between border-b border-dashed border-neutral-300 pb-2">
                      <span className="text-neutral-500 font-bold uppercase">REVERSE PROXY:</span>
                      <span className="font-mono text-black">NGINX LOAD BALANCER</span>
                    </div>
                    <div className="flex justify-between border-b border-dashed border-neutral-300 pb-2">
                      <span className="text-neutral-500 font-bold uppercase">COMPILER ENGINE:</span>
                      <span className="font-mono text-black">VITE + ESBUILD (COMPLIANT)</span>
                    </div>
                    <div className="flex justify-between border-b border-dashed border-neutral-300 pb-2">
                      <span className="text-neutral-500 font-bold uppercase">HOT MODULES (HMR):</span>
                      <span className="text-red-700 font-bold uppercase">DISABLED (STATIONARY)</span>
                    </div>
                    <div className="flex justify-between pb-1">
                      <span className="text-neutral-500 font-bold uppercase">NODE RUNTIME:</span>
                      <span className="font-mono text-black">ES MODULES ENGINE (v22+)</span>
                    </div>
                  </div>
                </div>

                {/* Major capabilities list */}
                <div className="border-4 border-black p-6 bg-surface-container shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] relative">
                  <CornerAccents size="w-4 h-4" />
                  <span className="text-[10px] font-label font-bold text-neutral-500 uppercase tracking-widest block">MANIFEST LEDGER</span>
                  <h3 className="font-headline text-lg font-bold uppercase text-black mt-1 mb-4">MAJOR CAPABILITIES</h3>

                  <div className="space-y-3 font-label text-xs">
                    <div className="flex items-center gap-2 border-b border-dashed border-neutral-300 pb-2">
                      <Database className="w-4 h-4 text-black shrink-0" />
                      <span className="font-bold text-black font-mono">SERVER_SIDE_GEMINI_API</span>
                    </div>
                    <div className="flex items-center gap-2 border-b border-dashed border-neutral-300 pb-2">
                      <Shield className="w-4 h-4 text-black shrink-0" />
                      <span className="font-bold text-black font-mono">ANALOG_OVERRIDE_BYPASS_V4</span>
                    </div>
                    <div className="flex items-center gap-2 border-b border-dashed border-neutral-300 pb-2">
                      <Clock className="w-4 h-4 text-black shrink-0" />
                      <span className="font-bold text-black font-mono">DURABLE_STEADY_EPOCH_DECAY</span>
                    </div>
                    <div className="flex items-center gap-2 pb-1">
                      <FileText className="w-4 h-4 text-black shrink-0" />
                      <span className="font-bold text-black font-mono">CLASSIFIED_DOSSIER_LEDGER</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Developer notice banner */}
              <div className="border-4 border-red-900 bg-red-50 p-5 text-red-900 relative">
                <div className="flex items-start gap-3">
                  <AlertOctagon className="w-6 h-6 shrink-0 mt-0.5 text-red-800" />
                  <div>
                    <h4 className="font-headline font-bold uppercase text-red-950 text-sm md:text-base">WARNING: CORE REACTOR TERMINAL ACCESS</h4>
                    <p className="font-body text-xs md:text-sm text-red-900 mt-1">
                      Manipulating reactor variables can cause structural desynchronization. Ensure your decay indexes match current field parameters before locking the supervisor terminal.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </motion.div>
  );
}
