import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ShieldAlert, RefreshCw, XCircle, ArrowRight, CornerDownLeft, Lock } from 'lucide-react';
import CornerAccents from './CornerAccents';
import { playClick, playSuccess, playDenied } from '../utils/audio';

interface SecurityOverrideProps {
  onBypassSuccess: () => void;
  onAbort: () => void;
  systemStatus: string;
  key?: string | number;
}

export default function SecurityOverride({ onBypassSuccess, onAbort, systemStatus }: SecurityOverrideProps) {
  const [code, setCode] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [attempts, setAttempts] = useState<number>(3);
  const correctPasscode = '7957'; // Highlighted in the theme!

  const handleNumClick = (num: string) => {
    playClick();
    if (code.length < 4) {
      setCode((prev) => prev + num);
      setErrorMsg(null);
    }
  };

  const handleClear = () => {
    playClick();
    setCode('');
    setErrorMsg(null);
  };

  const handleSubmit = () => {
    if (code === correctPasscode) {
      playSuccess();
      onBypassSuccess();
    } else {
      playDenied();
      const nextAttempts = attempts - 1;
      setCode('');
      if (nextAttempts <= 0) {
        setErrorMsg('SECURITY TERMINAL LOCKOUT. RE-INITIATING EPOCH DECAY.');
        setAttempts(3); // Reset or simulate cooldown
      } else {
        setErrorMsg(`DECRYPT_FAILURE: INCORRECT PASSCODE MATRIX. ${nextAttempts} ATTEMPTS REMAIN.`);
        setAttempts(nextAttempts);
      }
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      className="w-full h-full flex flex-col border-4 border-black bg-surface relative overflow-hidden"
      id="security-override-container"
    >
      <CornerAccents size="w-8 h-8" borderColor="border-black" />

      {/* Header */}
      <div className="w-full bg-black text-surface border-b-4 border-black px-6 py-4 flex justify-between items-center shrink-0" id="security-header">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-red-500" />
          <span className="font-label font-bold text-xs md:text-sm tracking-[0.25em] uppercase">SYSTEM_OVERRIDE_AUTHORIZATION</span>
        </div>
        <button
          onClick={() => {
            playClick();
            onAbort();
          }}
          className="text-xs uppercase font-label border border-[#ababab] px-3 py-1 bg-[#1b1b1b] hover:bg-[#3b3b3b] text-surface transition-colors cursor-pointer"
        >
          Abort Sequence
        </button>
      </div>

      <div className="flex-grow grid grid-cols-1 md:grid-cols-12 overflow-y-auto">
        {/* Left Column: Lore and Instructions */}
        <div className="col-span-1 md:col-span-5 border-b-2 md:border-b-0 md:border-r-4 border-black p-6 md:p-8 flex flex-col justify-between bg-surface-container-low">
          <div className="space-y-6">
            <div>
              <span className="font-label text-xs font-bold bg-black text-surface px-2.5 py-1 uppercase tracking-widest">
                PROTOCOL CORE 01
              </span>
              <h3 className="font-headline text-3xl font-bold tracking-tight mt-4 text-black uppercase leading-tight">
                ANALOG BYPASS GATE
              </h3>
            </div>

            <div className="font-body text-base md:text-lg leading-relaxed text-neutral-800 space-y-4">
              <p>
                Under Subsection 4-C of the <em>Archive Directive</em>, manual override requires entering the stable decay matrix key currently assigned to this Epoch.
              </p>
              <p className="border-l-4 border-black pl-4 italic text-neutral-700 bg-surface-container">
                "The target state is governed by stability critical parameters. Do not attempt decryption unless authorized by the Field Superintendent."
              </p>
              <p>
                The bypass key correlates with the last sequence timestamp on the mainframe. A visual sequence hint is encoded inside the primary dial numbers.
              </p>
            </div>
          </div>

          <div className="mt-8 pt-4 border-t border-dashed border-neutral-400 space-y-3">
            <div className="flex justify-between text-xs font-label text-neutral-600">
              <span>HINT DECRYPTOR:</span>
              <span className="font-bold text-black font-mono">CODE: 7957</span>
            </div>
            <div className="flex justify-between text-xs font-label text-neutral-600">
              <span>SECURITY LEVEL:</span>
              <span className="text-red-700 font-bold">STABILITY_RESTRICTED</span>
            </div>
          </div>
        </div>

        {/* Right Column: Keypad & Input */}
        <div className="col-span-1 md:col-span-7 p-6 md:p-10 flex flex-col justify-center items-center bg-surface">
          
          {/* Status Alert Display */}
          <div className="w-full max-w-sm mb-6 text-center">
            {errorMsg ? (
              <div className="bg-red-100 border-2 border-red-800 text-red-900 p-3 font-label text-xs uppercase tracking-wider animate-bounce" id="passcode-error">
                {errorMsg}
              </div>
            ) : (
              <div className="bg-surface-container-highest border-2 border-black p-3 font-label text-xs text-neutral-700 uppercase tracking-widest flex items-center justify-center gap-2">
                <Lock className="w-4 h-4 text-black" />
                <span>ENTER 4-DIGIT DECAY MATRIX</span>
              </div>
            )}
          </div>

          {/* Passcode Monospace Indicator Blocks */}
          <div className="flex gap-4 mb-8" id="passcode-display">
            {[0, 1, 2, 3].map((idx) => {
              const char = code[idx];
              return (
                <div
                  key={idx}
                  className={`w-14 h-16 md:w-16 md:h-20 border-4 border-black flex items-center justify-center font-label font-black text-2xl md:text-3xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-all ${
                    char ? 'bg-black text-surface' : 'bg-surface-container-low text-neutral-400'
                  }`}
                >
                  {char ? '*' : '•'}
                </div>
              );
            })}
          </div>

          {/* Core Numeric Grid */}
          <div className="grid grid-cols-3 gap-3 w-full max-w-sm" id="keypad-grid">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
              <button
                key={num}
                onClick={() => handleNumClick(num)}
                className="bg-[#e5e2db] text-black border-2 border-black font-label font-bold text-xl py-4 hover:bg-black hover:text-surface active:translate-y-[2px] active:shadow-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all cursor-pointer"
              >
                {num}
              </button>
            ))}
            
            {/* Clear Button */}
            <button
              onClick={handleClear}
              className="bg-red-200 text-red-900 border-2 border-red-900 font-label font-bold text-sm py-4 hover:bg-red-900 hover:text-surface active:translate-y-[2px] active:shadow-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all cursor-pointer uppercase"
            >
              CLEAR
            </button>

            {/* Zero Button */}
            <button
              onClick={() => handleNumClick('0')}
              className="bg-[#e5e2db] text-black border-2 border-black font-label font-bold text-xl py-4 hover:bg-black hover:text-surface active:translate-y-[2px] active:shadow-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all cursor-pointer"
            >
              0
            </button>

            {/* Enter / Submit Button */}
            <button
              onClick={handleSubmit}
              disabled={code.length !== 4}
              className={`border-2 font-label font-bold text-sm py-4 active:translate-y-[2px] active:shadow-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all cursor-pointer uppercase flex items-center justify-center gap-1 ${
                code.length === 4
                  ? 'bg-green-700 text-surface border-green-900 hover:bg-green-800'
                  : 'bg-neutral-300 text-neutral-500 border-neutral-400 cursor-not-allowed shadow-none active:translate-y-0'
              }`}
            >
              <CornerDownLeft className="w-4 h-4" />
              ENTER
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
