import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'motion/react';
import MainCountdown from './components/MainCountdown';
import SecurityOverride from './components/SecurityOverride';
import CommandCenter from './components/CommandCenter';
import { ScreenType } from './types';
import { playAlarm, playBeep } from './utils/audio';

export default function App() {
  // Matches the exact screenshot countdown state with days: 03:07:59:57
  const [timeInSeconds, setTimeInSeconds] = useState<number>(3 * 24 * 3600 + 7 * 3600 + 59 * 60 + 57);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(true);
  const [screen, setScreen] = useState<ScreenType>('COUNTDOWN');
  const [systemStatus, setSystemStatus] = useState<string>('CRITICAL');

  // Decrement Countdown Timer
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isTimerRunning && timeInSeconds > 0) {
      interval = setInterval(() => {
        setTimeInSeconds((prev) => {
          if (prev <= 1) {
            setIsTimerRunning(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning, timeInSeconds]);

  // Periodic visual/audio alarm pulse if system status is CRITICAL
  useEffect(() => {
    let alarmInterval: NodeJS.Timeout | null = null;
    if (systemStatus === 'CRITICAL' && screen === 'COUNTDOWN') {
      alarmInterval = setInterval(() => {
        // Subtle alert sound and pulse
        playAlarm();
      }, 5000);
    }
    return () => {
      if (alarmInterval) clearInterval(alarmInterval);
    };
  }, [systemStatus, screen]);

  const handleOverrideRequest = () => {
    setScreen('OVERRIDE');
  };

  const handleBypassSuccess = () => {
    setScreen('COMMAND_CENTER');
  };

  const handleAbortOverride = () => {
    setScreen('COUNTDOWN');
  };

  const handleExitCommandCenter = () => {
    setScreen('COUNTDOWN');
  };

  return (
    <div className="bg-surface text-primary min-h-screen flex flex-col font-body texture-bg overflow-hidden relative select-text">

      {/* Main Content Stage Centered Frame */}
      <main className="flex-grow flex items-center justify-center relative z-10 p-4 md:p-8 w-full max-w-[1280px] mx-auto h-[100vh]">
        <div className="w-full h-[90vh] md:h-[85vh] relative flex flex-col" id="applet-primary-stage">
          <AnimatePresence mode="wait">
            {screen === 'COUNTDOWN' && (
              <MainCountdown
                key="countdown-screen"
                timeInSeconds={timeInSeconds}
                onOverrideClick={handleOverrideRequest}
                systemStatus={systemStatus}
              />
            )}
            
            {screen === 'OVERRIDE' && (
              <SecurityOverride
                key="override-screen"
                onBypassSuccess={handleBypassSuccess}
                onAbort={handleAbortOverride}
                systemStatus={systemStatus}
              />
            )}
            
            {screen === 'COMMAND_CENTER' && (
              <CommandCenter
                key="command-center-screen"
                timeInSeconds={timeInSeconds}
                setTimeInSeconds={setTimeInSeconds}
                isTimerRunning={isTimerRunning}
                setIsTimerRunning={setIsTimerRunning}
                systemStatus={systemStatus}
                setSystemStatus={setSystemStatus}
                onExit={handleExitCommandCenter}
              />
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Decorative Outer Terminal Border Scanline Effect */}
      <div className="absolute inset-0 pointer-events-none z-50 bg-[linear-gradient(rgba(18,16,16,0)_50%,_rgba(0,0,0,0.12)_50%),_linear-gradient(90deg,_rgba(255,0,0,0.03),_rgba(0,255,0,0.01),_rgba(0,0,255,0.03))] bg-[size:100%_4px,_6px_100%] opacity-40" />
    </div>
  );
}
