export type ScreenType = 'COUNTDOWN' | 'OVERRIDE' | 'COMMAND_CENTER';

export type SystemStatus = 'STABLE' | 'DEGRADED' | 'CRITICAL' | 'BYPASSED' | 'MUTED';

export interface LogEntry {
  id: string;
  timestamp: string;
  level: 'INFO' | 'WARN' | 'ERROR' | 'SYSTEM';
  message: string;
  source: string;
}

export interface ArchiveFile {
  id: string;
  title: string;
  date: string;
  classification: string;
  content: string;
  author: string;
}

export interface SecurityStatus {
  attemptsRemaining: number;
  unlocked: boolean;
  history: string[];
}
