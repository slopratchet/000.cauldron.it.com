import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route: Get system environment status (mock terminal logs check)
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ONLINE',
      node: 'ALPHA-7',
      timestamp: new Date().toISOString(),
      clearance: 'L4_CLEARANCE',
    });
  });

  // Vite integration based on environment
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Chronos Terminal backend running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Mainframe initialization failed:', err);
});
