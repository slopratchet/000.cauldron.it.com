import React from 'react';

// The User's precise, complete Clerk JSON Data Object (Fully integrated)
const USER_DATA = {
  "id": "user_3FkF7jESgmQRGSX40lTAsuJku64",
  "pathRoot": "/me",
  "externalId": null,
  "username": null,
  "emailAddresses": [
    {
      "id": "idn_3FkF7iupx91RfPOoVqOMFrioSpz",
      "pathRoot": "/me/email_addresses",
      "emailAddress": "glopratchet@gmail.com",
      "matchesSsoConnection": false,
      "linkedTo": [],
      "verification": {
        "pathRoot": "",
        "status": null,
        "strategy": null,
        "nonce": null,
        "message": null,
        "externalVerificationRedirectURL": null,
        "attempts": null,
        "expireAt": null,
        "error": null,
        "verifiedAtClient": null
      }
    }
  ],
  "phoneNumbers": [],
  "web3Wallets": [],
  "externalAccounts": [],
  "enterpriseAccounts": [],
  "passkeys": [],
  "organizationMemberships": [],
  "passwordEnabled": true,
  "firstName": "Globlous",
  "lastName": "Globs",
  "fullName": "Globlous Globs",
  "primaryEmailAddressId": "idn_3FkF7iupx91RfPOoVqOMFrioSpz",
  "primaryEmailAddress": {
    "id": "idn_3FkF7iupx91RfPOoVqOMFrioSpz",
    "pathRoot": "/me/email_addresses",
    "emailAddress": "glopratchet@gmail.com",
    "matchesSsoConnection": false,
    "linkedTo": [],
    "verification": {
      "pathRoot": "",
      "status": null,
      "strategy": null,
      "nonce": null,
      "message": null,
      "externalVerificationRedirectURL": null,
      "attempts": null,
      "expireAt": null,
      "error": null,
      "verifiedAtClient": null
    }
  },
  "primaryPhoneNumberId": null,
  "primaryPhoneNumber": null,
  "primaryWeb3WalletId": null,
  "primaryWeb3Wallet": null,
  "imageUrl": "https://img.clerk.com/eyJ0eXBlIjoiZGVmYXVsdCIsImlpZCI6Imluc18zM3FnQWN2VkFWYUQ2eXZEVjRaaW9rZm0xZUQiLCJyaWQiOiJ1c2VyXzNGa0Y3akVTZ21RUkdTWDQwbFRBc3VKa3U2NCIsImluaXRpYWxzIjoiR0cifQ",
  "hasImage": false,
  "twoFactorEnabled": false,
  "totpEnabled": false,
  "backupCodeEnabled": false,
  "publicMetadata": {},
  "unsafeMetadata": {
    "email": "glopratchet@gmail.com",
    "origin": "EARTHBOUND",
    "alignment": "PRIMAL",
    "archetype": "RUNNER",
    "registered_at": "2026-06-28T01:43:09.391Z"
  },
  "createOrganizationEnabled": true,
  "createOrganizationsLimit": null,
  "deleteSelfEnabled": true,
  "lastSignInAt": "2026-06-28T01:43:14.896Z",
  "legalAcceptedAt": null,
  "updatedAt": "2026-06-28T01:43:14.902Z",
  "createdAt": "2026-06-28T01:43:14.887Z",
  "cachedSessionsWithActivities": null
};

export default function App() {
  // Flat helper to ensure every parameter is checked, verified, and listed inside a highlightable schema table
  const flattenedParamsList: Array<{ key: string; val: any }> = [
    { key: "id", val: USER_DATA.id },
    { key: "pathRoot", val: USER_DATA.pathRoot },
    { key: "externalId", val: String(USER_DATA.externalId) },
    { key: "username", val: String(USER_DATA.username) },
    { key: "emailAddresses[0].id", val: USER_DATA.emailAddresses[0]?.id },
    { key: "emailAddresses[0].pathRoot", val: USER_DATA.emailAddresses[0]?.pathRoot },
    { key: "emailAddresses[0].emailAddress", val: USER_DATA.emailAddresses[0]?.emailAddress },
    { key: "emailAddresses[0].matchesSsoConnection", val: String(USER_DATA.emailAddresses[0]?.matchesSsoConnection) },
    { key: "emailAddresses[0].linkedTo", val: JSON.stringify(USER_DATA.emailAddresses[0]?.linkedTo) },
    { key: "emailAddresses[0].verification.pathRoot", val: String(USER_DATA.emailAddresses[0]?.verification.pathRoot || "EMPTY") },
    { key: "emailAddresses[0].verification.status", val: String(USER_DATA.emailAddresses[0]?.verification.status) },
    { key: "emailAddresses[0].verification.strategy", val: String(USER_DATA.emailAddresses[0]?.verification.strategy) },
    { key: "phoneNumbers", val: JSON.stringify(USER_DATA.phoneNumbers) },
    { key: "web3Wallets", val: JSON.stringify(USER_DATA.web3Wallets) },
    { key: "externalAccounts", val: JSON.stringify(USER_DATA.externalAccounts) },
    { key: "enterpriseAccounts", val: JSON.stringify(USER_DATA.enterpriseAccounts) },
    { key: "passkeys", val: JSON.stringify(USER_DATA.passkeys) },
    { key: "organizationMemberships", val: JSON.stringify(USER_DATA.organizationMemberships) },
    { key: "passwordEnabled", val: String(USER_DATA.passwordEnabled) },
    { key: "firstName", val: USER_DATA.firstName },
    { key: "lastName", val: USER_DATA.lastName },
    { key: "fullName", val: USER_DATA.fullName },
    { key: "primaryEmailAddressId", val: USER_DATA.primaryEmailAddressId },
    { key: "primaryEmailAddress.id", val: USER_DATA.primaryEmailAddress.id },
    { key: "primaryEmailAddress.pathRoot", val: USER_DATA.primaryEmailAddress.pathRoot },
    { key: "primaryEmailAddress.emailAddress", val: USER_DATA.primaryEmailAddress.emailAddress },
    { key: "primaryPhoneNumberId", val: String(USER_DATA.primaryPhoneNumberId) },
    { key: "primaryPhoneNumber", val: String(USER_DATA.primaryPhoneNumber) },
    { key: "primaryWeb3WalletId", val: String(USER_DATA.primaryWeb3WalletId) },
    { key: "primaryWeb3Wallet", val: String(USER_DATA.primaryWeb3Wallet) },
    { key: "imageUrl", val: USER_DATA.imageUrl },
    { key: "hasImage", val: String(USER_DATA.hasImage) },
    { key: "twoFactorEnabled", val: String(USER_DATA.twoFactorEnabled) },
    { key: "totpEnabled", val: String(USER_DATA.totpEnabled) },
    { key: "backupCodeEnabled", val: String(USER_DATA.backupCodeEnabled) },
    { key: "publicMetadata", val: JSON.stringify(USER_DATA.publicMetadata) },
    { key: "unsafeMetadata.email", val: USER_DATA.unsafeMetadata.email },
    { key: "unsafeMetadata.origin", val: USER_DATA.unsafeMetadata.origin },
    { key: "unsafeMetadata.alignment", val: USER_DATA.unsafeMetadata.alignment },
    { key: "unsafeMetadata.archetype", val: USER_DATA.unsafeMetadata.archetype },
    { key: "unsafeMetadata.registered_at", val: USER_DATA.unsafeMetadata.registered_at },
    { key: "createOrganizationEnabled", val: String(USER_DATA.createOrganizationEnabled) },
    { key: "createOrganizationsLimit", val: String(USER_DATA.createOrganizationsLimit) },
    { key: "deleteSelfEnabled", val: String(USER_DATA.deleteSelfEnabled) },
    { key: "lastSignInAt", val: USER_DATA.lastSignInAt },
    { key: "legalAcceptedAt", val: String(USER_DATA.legalAcceptedAt) },
    { key: "updatedAt", val: USER_DATA.updatedAt },
    { key: "createdAt", val: USER_DATA.createdAt },
    { key: "cachedSessionsWithActivities", val: String(USER_DATA.cachedSessionsWithActivities) }
  ];

  return (
    <div className="w-full min-h-screen bg-[#ebe8e1] flex flex-col items-center justify-start antialiased font-body relative overflow-x-hidden p-0 sm:p-4 select-text">
      {/* Dynamic CRT Scanline Overlay */}
      <div className="scanline"></div>

      {/* 77% scaled layout wrapper to shrink everything by exactly 23% (resulting in 77% size) */}
      <div 
        className="w-full flex justify-center items-start select-text" 
        style={{ 
          transform: 'scale(0.77)', 
          transformOrigin: 'top center', 
          width: '129.87%', 
          marginBottom: '-23%' 
        }}
      >
        {/* Main Container - Framed by "The Archive Protocol" Zero-Radius Heavy Borders */}
        <main className="w-full max-w-[1280px] bg-surface relative flex flex-col diagnostic-border texture-bg shadow-2xl select-text">
          
          {/* BOTTOM FULL-WIDTH DATABANK COMPONENT READOUT (Verifies ALL Clerk Parameters are Present & Highlightable) */}
          <section className="bg-surface-container-lowest p-8 select-text">
            <h3 className="font-display font-black text-2xl uppercase tracking-tighter text-primary mb-6 flex items-center gap-3 border-b-4 border-primary pb-2 select-text">
              <span className="material-symbols-outlined text-3xl select-text">database</span>
              <span>CLERK DATA SCHEMA</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 font-mono text-xs select-text">
              {flattenedParamsList.map((item, idx) => (
                <div 
                  key={idx} 
                  className="diagnostic-border p-3 bg-surface-container-low flex flex-col justify-between select-text hover:bg-surface-container-high transition-colors"
                >
                  <div className="text-[10px] text-primary/50 uppercase tracking-widest font-bold select-text mb-1 truncate">
                    {item.key}
                  </div>
                  <div className="font-bold text-primary select-text font-mono break-all text-sm leading-relaxed">
                    {item.val === null || String(item.val) === "null" ? (
                      <span className="text-primary/30 select-text">NULL</span>
                    ) : String(item.val) === "true" || item.val === true ? (
                      <span className="text-green-700 select-text">TRUE</span>
                    ) : String(item.val) === "false" || item.val === false ? (
                      <span className="text-red-700 select-text">FALSE</span>
                    ) : (
                      String(item.val)
                    )}
                  </div>
                </div>
              ))}
            </div>
          </section>

        </main>
      </div>
    </div>
  );
}
