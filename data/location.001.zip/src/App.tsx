/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export default function App() {
  return (
    <div className="flex flex-col md:flex-row antialiased selection:bg-primary selection:text-surface min-h-screen bg-surface font-sans text-on-surface">
      <main className="flex flex-col min-w-0 flex-1">
        <div className="p-4 md:p-8 flex-1 overflow-y-auto pattern-bg h-screen">
          <div className="max-w-7xl mx-auto space-y-8">
            
            {/* Header Block */}
            <div className="brutalist-border bg-surface p-6 sm:p-8 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
                <svg fill="none" height="120" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" width="120">
                  <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
                </svg>
              </div>
              <h1 className="text-5xl sm:text-7xl font-black uppercase tracking-tighter mb-2 leading-none">OUTPOST RECONNAISSANCE</h1>
              <h2 className="text-xl sm:text-2xl font-mono uppercase tracking-widest text-primary border-t-4 border-border pt-2 inline-block">
                High-Altitude Research Outpost // Sector Gamma-7
              </h2>
            </div>
            
            {/* Overview Image Section */}
            <div className="brutalist-border bg-surface p-2 relative">
              <div className="absolute top-0 left-0 bg-primary text-surface px-2 py-1 text-xs font-mono z-10">
                SATELLITE DOWNLINK // REF. IMAGE 89
              </div>
              <img 
                alt="High-altitude research outpost in a blizzard with radio towers and industrial pods" 
                className="w-full h-[300px] md:h-[400px] object-cover border-2 border-border grayscale" 
                src="https://lh3.googleusercontent.com/aida/ADBb0uitfP0IBdUByvgBxEjbQiozS0Ix8OdDvB_0TqE0wGEAZYC0BXX81-8ISwqGv-W1sW5vflEGzKCi08rS5ZxMJQIv_eV1_B-X91t-meCn34iFEMn2SDce7Ep2RTlan3mDrDp4xKuZcoKDsMf3RJR2z-7k6k1rwdN7kDY9Fqd8jCk4YJ2kdtbkZ1OoQxqgSjFfKCv99xoR12uyqxo1CtaSb_17dtmDXG4FjCm6CCWMb2lwfqRSY_Inzmo8HH5w"
              />
            </div>

            {/* Three-Column Data Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* Column 1: Climate Data */}
              <div className="space-y-6">
                <div className="brutalist-border bg-surface p-6 h-full flex flex-col">
                  <h3 className="text-2xl font-black uppercase mb-4 bg-primary text-surface p-2 text-center">Climate Data</h3>
                  <div className="flex-1 space-y-6">
                    <div className="space-y-2">
                      <div className="flex justify-between border-b border-border font-mono text-sm py-1">
                        <span className="font-bold">Avg Temp:</span>
                        <span>-45.5°C</span>
                      </div>
                      <div className="flex justify-between border-b border-border font-mono text-sm py-1">
                        <span className="font-bold">Wind Velocity:</span>
                        <span>142 km/h</span>
                      </div>
                      <div className="flex justify-between border-b border-border font-mono text-sm py-1">
                        <span className="font-bold">Precipitation:</span>
                        <span>Heavy Snowfall</span>
                      </div>
                      <div className="flex justify-between border-b border-border font-mono text-sm py-1">
                        <span className="font-bold">Visibility:</span>
                        <span>&lt; 5 Meters</span>
                      </div>
                    </div>
                    <div className="p-4 bg-surface-container-low border-2 border-border italic text-sm font-serif">
                      "Blizzard conditions are persistent. Isolation protocol active. Structural integrity currently monitored at 88% due to sustained gale-force impacts."
                    </div>
                  </div>
                </div>
              </div>

              {/* Column 2: Strategic Utility */}
              <div className="space-y-6">
                <div className="brutalist-border bg-surface p-6 h-full flex flex-col grid-bg">
                  <h3 className="text-2xl font-black uppercase mb-4 bg-surface border-2 border-border p-2 text-center">Strategic Utility</h3>
                  <div className="bg-surface p-4 border-2 border-border space-y-4 flex-1">
                    <div>
                      <h4 className="text-lg font-bold uppercase border-b border-border pb-1 mb-2">Network Hub</h4>
                      <p className="text-sm font-serif leading-relaxed">Central relay for sub-zero communication arrays. Critical for deep-range scanning across the Sector Gamma-7 expanse.</p>
                    </div>
                    <div>
                      <h4 className="text-lg font-bold uppercase border-b border-border pb-1 mb-2">Tactical Advantage</h4>
                      <ul className="list-none font-mono text-xs space-y-2">
                        <li className="flex items-start gap-2">
                          <span className="font-bold text-primary text-lg leading-none mt-0.5">•</span>
                          <span className="leading-tight">High-altitude visibility for thermal tracking.</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="font-bold text-primary text-lg leading-none mt-0.5">•</span>
                          <span className="leading-tight">Natural fortification via extreme terrain.</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="font-bold text-primary text-lg leading-none mt-0.5">•</span>
                          <span className="leading-tight">Secured underground storage bunkers.</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              {/* Column 3: Research Objectives */}
              <div className="space-y-6">
                <div className="brutalist-border bg-surface p-6 h-full flex flex-col">
                  <h3 className="text-2xl font-black uppercase mb-4 bg-surface-dim border-b-4 border-border p-2 text-center">Research Objectives</h3>
                  <div className="flex-1">
                    <ul className="font-mono text-sm space-y-3">
                      <li className="flex items-center space-x-3 border-b border-border border-dashed pb-2">
                        <span className="w-3 h-3 bg-primary shrink-0"></span>
                        <span>Atmospheric isotope analysis</span>
                      </li>
                      <li className="flex items-center space-x-3 border-b border-border border-dashed pb-2">
                        <span className="w-3 h-3 bg-primary shrink-0"></span>
                        <span>Deep-crust seismic monitoring</span>
                      </li>
                      <li className="flex items-center space-x-3 border-b border-border border-dashed pb-2">
                        <span className="w-3 h-3 bg-primary shrink-0"></span>
                        <span>Long-range signal decryption</span>
                      </li>
                      <li className="flex items-center space-x-3 border-b border-border border-dashed pb-2">
                        <span className="w-3 h-3 bg-primary shrink-0"></span>
                        <span>Permafrost organic sampling</span>
                      </li>
                      <li className="flex items-center space-x-3 border-b border-border border-dashed pb-2">
                        <span className="w-3 h-3 bg-primary shrink-0"></span>
                        <span>Sub-zero polymer stress testing</span>
                      </li>
                      <li className="flex items-center space-x-3 border-b border-border border-dashed pb-2">
                        <span className="w-3 h-3 bg-primary shrink-0"></span>
                        <span>Neural-link environmental acclimation</span>
                      </li>
                    </ul>
                    <div className="mt-6 pt-4 border-t-2 border-border border-double text-[10px] font-mono opacity-60">
                      AUTH: RESEARCH_COUNCIL_INTERNAL // CLASSIFIED
                    </div>
                  </div>
                </div>
              </div>

            </div>

            {/* Narrative Footer / Technical Note */}
            <div className="brutalist-border bg-primary text-surface p-6 sm:p-8 italic text-lg sm:text-xl font-medium border-l-[16px] border-l-surface-dim font-serif">
              "The silence at Gamma-7 isn't just a lack of sound; it's a presence. Between the gusts of the blizzard, the equipment hums a melody of cold logic. We are the only eyes on this peak, and the only ones who know what truly lies beneath the ice."
            </div>
            
          </div>
        </div>
      </main>
    </div>
  );
}
