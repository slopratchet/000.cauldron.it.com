/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// API route to generate custom retro RPG adventure sheets via Gemini 3.5 Flash
app.post("/api/records/generate", async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt) {
      res.status(400).json({ error: "Missing campaign outline/prompt parameter" });
      return;
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      res.status(500).json({
        error: "GEMINI_API_KEY environment variable is not configured. Please add it to your secrets panel in AI Studio.",
      });
      return;
    }

    // Initialize Gemini client securely
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `Generate a fully functional retro-RPG Interactive Adventure Sheet JSON for a D&D 5E/Tabletop campaign matching this concept: "${prompt}".

The output must match this exact structural schema:
{
  "meta": {
    "adventure_id": "VS-01",
    "title": "Module Title",
    "authors": ["Author"],
    "schemaVersion": "13.0_AAA_Engine",
    "design_philosophy": "4 hours etc",
    "system": "D&D 5th Edition (SRD 5.2)",
    "character_levels": "3-5"
  },
  "safety_and_accessibility": {
    "content_warnings": ["Child Endangerment", "Drowning", "Grief/Loss"],
    "dynamic_filters": {
      "filter_arachnophobia": {
        "target_entity": "monsters.giant_spider",
        "replacement_entity": "monsters.venomous_vine_blight",
        "text_scrub_array": ["webs", "spiders", "skittering", "eight legs", "spinnerets"]
      }
    }
  },
  "theme": {
    "core_concept": "Concept...",
    "moral_question": "Deep moral dilemma...",
    "mood": "大气/Melancholic/Tense"
  },
  "narrative": {
    "synopsis": "Full atmospheric overview synopsis sentence...",
    "dramatis_personae": {
      "elara": "Primary Questgiver description",
      "vorgun": "Guardian spirit description",
      "kailina": "Vorgun's deceased daughter, whose spirit is deeply anchored inside the barrow monument and yearns for peace.",
      "elric": "Oakhaven's historical founder, who established the wardstones but originally stole the monolith cores."
    },
    "story_beats": {
      "paradigm": "three_act_structure",
      "beats": {
        "inciting_incident": { "name": "Event", "linked_scene": "scene_arrival_at_oakhaven" },
        "plot_point_1": { "name": "Event 2", "linked_scene": "scene_journey_barrowmoors" },
        "climax": { "name": "Final Battle", "linked_scene": "scene_burial_chamber_climax" }
      }
    }
  },
  "journal": {
    "main_quest": {
      "id": "mq_vorguns_peace",
      "title": "Quest Title",
      "stages": {
        "Social Investigation": { "objective": "Social Investigation - Uncover the root cause of the endless tempest by investigating the Oakhaven warding stones, questioning council elders, and exploring hidden records regarding Vorgun's ancient pact.", "state": "completed", "trigger_start": "adventure_start" },
        "Wilderness Exploration": { "objective": "Wilderness Exploration - Navigating the perilous, mist-shrouded Barrowmoors to locate the ancient sentinel standing stones, survival guides, and forgotten pathways holding clues to the giants' curse.", "state": "active", "trigger_start": "scene_journey_barrowmoors" },
        "Spirit Climax Resolution": { "objective": "Spirit Climax Resolution - Infiltrating the deep barrow chambers beneath the highland crags, facing the spectral warden, and performing the sacred ritual of binding memory to calm Vorgun's rage.", "state": "locked", "trigger_start": "scene_burial_chamber_climax" }
      }
    }
  },
  "party_integration": {
    "background_hooks": {
      "acolyte": { "linked_secret": "secret_vorguns_true_death", "bonus": "Advantage on check to decode stones", "location": "Highland Warding Shrine" },
      "criminal": { "linked_secret": "secret_smugglers_tunnel", "bonus": "Knowledge of damp tunnels under the moors; bypasses one hazard challenge.", "location": "Smuggler Moors Outpost" },
      "sage": { "linked_secret": "secret_ancient_pact", "bonus": "Can translate ancient giant celestial scriptures without any ability checks.", "location": "Scribes Ancient Library" },
      "soldier": { "linked_secret": "secret_giant_guard_tactics", "bonus": "Gain +2 to bonus damage during encounters inside giant-themed locations.", "location": "Garrison Watchtower" },
      "outlander": { "linked_secret": "secret_willow_wisp", "bonus": "Immune to navigation penalties caused by dense swamp fog of the moors.", "location": "Whispering Heath Moors" },
      "folk_hero": { "linked_secret": "secret_ritualist_herbal", "bonus": "Allows players to double healing from short rest rations within Oakhaven.", "location": "Oakhaven Town Square" },
      "hermit": { "linked_secret": "secret_lost_conclave", "bonus": "Can hear telepathic residual memories on touch of any stone relics.", "location": "Solitary Crag Hermitage" },
      "noble": { "linked_secret": "secret_founders_betrayal", "bonus": "Direct high-profile alignment check benefits with town council elders.", "location": "Oakhaven High Manor" }
    }
  },
  "chronology": {
    "calendar_system": "Standard_365",
    "day_of_week": "Moonday",
    "month": "Olarune",
    "year": 998,
    "celestial_bodies": [
      { "name": "The Moon Name", "current_phase": "Waxing Crescent", "mechanical_impact": "Impact text" }
    ],
    "daily_cycle": {
      "dawn": "06:00",
      "dusk": "18:00",
      "on_dusk": { "action": "execute_procedure", "proc_id": "proc_night_terrors" }
    }
  },
  "lore_web": {
    "secrets": {
      "secret_vorguns_true_death": {
        "id": "secret_vorguns_true_death",
        "truth": "The secret reality of the giant...",
        "clues_required": 1,
        "clue_locations": ["handout_thieves_diary"]
      },
      "secret_smugglers_tunnel": {
        "id": "secret_smugglers_tunnel",
        "truth": "There is an old, half-collapsed mining shaft that leads directly behind the Oakhaven shrine into the Barrowmoors.",
        "clues_required": 2,
        "clue_locations": ["map_fragment", "guild_ledger"]
      },
      "secret_ancient_pact": {
        "id": "secret_ancient_pact",
        "truth": "The founders of Oakhaven swore an oath to never take gold or weapons from the burial mounds of the Storm Giants.",
        "clues_required": 2,
        "clue_locations": ["sacred_tome", "altar_inscription"]
      },
      "secret_giant_guard_tactics": {
        "id": "secret_giant_guard_tactics",
        "truth": "Vorgun's stone guards are vulnerable to thunder damage because of microfissures in their outer crystalline plating.",
        "clues_required": 1,
        "clue_locations": ["blacksmith_notes"]
      },
      "secret_willow_wisp": {
        "id": "secret_willow_wisp",
        "truth": "Will-o'-wisps in the swamp are actually the souls of original builders trying to guide travelers away from hazardous traps.",
        "clues_required": 2,
        "clue_locations": ["spirit_dialogue", "weathered_gravestone"]
      },
      "secret_founders_betrayal": {
        "id": "secret_founders_betrayal",
        "truth": "Oakhaven town founder Elric was the one who stole the original warding stone core, triggering the infinite rain storm.",
        "clues_required": 3,
        "clue_locations": ["diary_entry_7", "underground_shrine_inscription", "ancient_key_engraving"]
      },
      "secret_weeping_cairn": {
        "id": "secret_weeping_cairn",
        "truth": "The weeping cairn on the eastern swamp border is actually a high-density water elemental node draining localized wild magic streams.",
        "clues_required": 2,
        "clue_locations": ["ritualist_herbal", "cairn_engravings"]
      },
      "secret_hag_alliance": {
        "id": "secret_hag_alliance",
        "truth": "The Barrowmoor Hag was once Elder Elara's older sister, mutated decades ago by a cursed bargain with the primordial swamp deities.",
        "clues_required": 3,
        "clue_locations": ["forgotten_letter", "elara_bedroom_diary", "hag_confession"]
      },
      "secret_drowned_catacombs": {
        "id": "secret_drowned_catacombs",
        "truth": "There is a subterranean aquatic path directly to the burial chamber that is accessible only when the tide indicator falls below d4 dice thresholds.",
        "clues_required": 2,
        "clue_locations": ["fisher_tales", "mossy_hatch"]
      },
      "secret_vorgun_affinity": {
        "id": "secret_vorgun_affinity",
        "truth": "Vorgun's ghost will immediately stop attacks if an adventurer holds the celestial vial aloft and speaks his deceased daughter's true name 'Kailina'.",
        "clues_required": 1,
        "clue_locations": ["family_shrine_records"]
      },
      "secret_star_map": {
        "id": "secret_star_map",
        "truth": "The celestial star coordinates engraved high upon the chamber's roof reveal the real locations of three other ancient giant storm bastions across the continent.",
        "clues_required": 2,
        "clue_locations": ["buried_astrolabe", "tomb_pillars"]
      }
    }
  },
  "tension_engine": {
    "pool_mechanic": {
      "max_dice": 6,
      "die_type": "d6",
      "triggers_to_add_die": [
        "player_fails_stealth_check",
        "player_action:spellcast_unveils_ward",
        "player_action:prolonged_rest_in_wild",
        "player_action:touch_relic_without_ritual"
      ],
      "triggers_to_roll_pool": ["pool_reaches_max"],
      "on_roll_complication": { "condition": "roll_contains_1", "action": "execute_procedure", "proc_id": "proc_storm_escalates" }
    },
    "categories": [
      {
        "category_name": "Storm Fury",
        "description": "Atmospheric hazards brought on by Vorgun's mounting frustration.",
        "sub_complications": [
          { "name": "Forked Lightning Strike", "description": "Direct static discharge targeting metallic weapons or armor.", "severity": "High" },
          { "name": "Gale-Force Winds", "description": "All projectile attacks and airborne navigation suffer extreme penalties.", "severity": "Medium" },
          { "name": "Pelting Hail", "description": "Restricted visibility and continuous low-level cold damage over time.", "severity": "Low" }
        ]
      },
      {
        "category_name": "Swamp Terrors",
        "description": "The flora and fauna of the Barrowmoors stirred into aggression.",
        "sub_complications": [
          { "name": "Sinking Quicksand", "description": "Characters are trapped and restrained, requiring structural athletics to escape.", "severity": "High" },
          { "name": "Will-o'-Wisp Lure", "description": "Magical lights confuse party navigation, causing a random detour on the hex grid.", "severity": "Medium" },
          { "name": "Stagnant Gas Pocket", "description": "Highly flammable or toxic swamp gas can ignite or poison the party.", "severity": "Medium" }
        ]
      },
      {
        "category_name": "Ancient Curse",
        "description": "Metaphysical echo anomalies stemming from giant stone architecture.",
        "sub_complications": [
          { "name": "Haunting Voice of Vorgun", "description": "Fear-driven saving throwing checks against auditory memories of giant elders.", "severity": "High" },
          { "name": "Runic Feedback Siphon", "description": "Spells cast within 100 feet trigger magical backfires, draining slot charges.", "severity": "Medium" },
          { "name": "Stony Gaze projection", "description": "Ancient giant statues track eyes, petrifying flesh momentarily.", "severity": "High" }
        ]
      },
      {
        "category_name": "Resource Attrition",
        "description": "The degradation of equipment and mental fatigue in high stress.",
        "sub_complications": [
          { "name": "Spoiled Rations", "description": "Swamp moisture destroys supply packs, reducing short rest healing output.", "severity": "Low" },
          { "name": "Damp Torch Ignition Failure", "description": "Lighting items fail to combust, relying entirely on magical vision.", "severity": "Low" },
          { "name": "Rusting Crystals", "description": "Acidic mire weakens non-magical shields, reducing armor durability.", "severity": "Medium" }
        ]
      }
    ]
  },
  "audiovisual_cues": {
    "soundscapes": {
      "bgm_storm_exterior": { "asset_path": "audio/music/storm_tense.mp3", "loop": true },
      "bgm_sorrowful_ambient": { "asset_path": "audio/music/tomb_choir.mp3", "loop": true }
    },
    "lighting_states": {
      "village_dusk": { "ambient_light": "#4A5568", "fog_of_war": false, "intensity": 0.4 },
      "tomb_interior": { "ambient_light": "#1A1A24", "fog_of_war": true, "intensity": 0.1 }
    },
    "vfx_states": {
      "heavy_rain_particle": { "asset_path": "vfx/particles/rain_heavy.pfx", "density": 0.8 },
      "ghost_aura_particle": { "asset_path": "vfx/particles/spirit_aura_blue.pfx", "density": 0.5 }
    },
    "environment_groups": {
      "preset_stormy_village": {
        "name": "Stormy Village Preset",
        "description": "Binds the active rain storm to the dusk village setting.",
        "soundscape_id": "bgm_storm_exterior",
        "lighting_id": "village_dusk",
        "vfx_id": "heavy_rain_particle"
      },
      "preset_gloomy_tomb": {
        "name": "Gloomy Tomb Chamber Preset",
        "description": "Binds heavy tomb crypt lighting, sorrowful music, and spirit auras.",
        "soundscape_id": "bgm_sorrowful_ambient",
        "lighting_id": "tomb_interior",
        "vfx_id": "ghost_aura_particle"
      },
      "preset_peaceful_shrine": {
        "name": "Peaceful Cleared Shrine Preset",
        "description": "Binds fading storms, bright warm light, and clear calm atmosphere.",
        "soundscape_id": "sfx_storm_fading",
        "lighting_id": "bright_warm_light",
        "vfx_id": "ghost_aura_particle"
      }
    }
  },
  "definitions": {
    "entities": {
      "monsters": {
        "vorguns_ghost": { "name": "Ghost of Vorgun", "base_stat_block": "Ghost", "hp": 75, "size": "Huge", "default_vfx": "ghost_aura_particle", "locations": ["Burial Mound", "Inner Tomb Sarcophagus Chamber", "Ancient Spirit Throne Room"] },
        "barrow_ghoul": { "name": "Barrow Ghoul", "base_stat_block": "Ghoul", "hp": 22, "size": "Medium", "default_vfx": "decay_cloud_particle", "locations": ["Damp Barrowmoors", "The Forgotten Crypts", "Highlands Cemetery Outskirts"] },
        "lightning_mephit": { "name": "Lightning Mephit", "base_stat_block": "Mephit", "hp": 21, "size": "Small", "default_vfx": "spark_aura_particle", "locations": ["Sentinel Stone Monoliths", "Western Leyline Conduit", "Whispering Heath Summit"] },
        "barrowmoor_hag": { "name": "Barrowmoor Hag", "base_stat_block": "Green Hag", "hp": 82, "size": "Medium", "default_vfx": "swamp_fog_particle", "locations": ["Mistwood Wilds Swamp", "Elder-Lotus Glade", "Barrowmoor Smuggler Marsh-Hollow"] }
      },
      "npcs": {
        "elara": { "name": "Elara", "location": "Oakhaven Council Chambers", "roleplaying": { "ideal": "Community", "flaw": "Deeply suspicious of outsiders" } },
        "brennan": { "name": "Brennan the Blacksmith", "location": "Oakhaven Blacksmith Workshop", "roleplaying": { "ideal": "Craftsmanship", "flaw": "Extremely stubborn and narrow-minded" } },
        "kaelen": { "name": "Father Kaelen", "location": "Oakhaven Sanctuary Shrine", "roleplaying": { "ideal": "Faith", "flaw": "Naively trusts that good resolves everything" } },
        "mira": { "name": "Mira the Tavernkeep", "location": "Oakhaven Weeping Willow Tavern", "roleplaying": { "ideal": "Hospitality", "flaw": "Gossip-monger who leaks customer secrets" } },
        "dorn": { "name": "Dorn of the North", "location": "Oakhaven Town Border Gates", "roleplaying": { "ideal": "Vengeance", "flaw": "Refuses to adapt to local traditions" } },
        "lysandra": { "name": "Lady Lysandra", "location": "Oakhaven High Manor", "roleplaying": { "ideal": "Honor", "flaw": "Cares more about reputation than safety" } },
        "silas": { "name": "Silas the Smuggler", "location": "Barrowmoor Smuggler Marsh-Hollow", "roleplaying": { "ideal": "Freedom", "flaw": "Greedy and easily bought off in a crisis" } },
        "valya": { "name": "Valya the Herbalist", "location": "Barrowmoor Elder-Lotus Glade", "roleplaying": { "ideal": "Knowledge", "flaw": "Secretive about herb sources and recipes" } },
        "rowan": { "name": "Rowan the Ranger", "location": "Barrowmoor Mistwood Wilds", "roleplaying": { "ideal": "Nature Protection", "flaw": "Extremely antisocial and avoids Oakhaven" } },
        "theron": { "name": "Theron the Scribe", "location": "Oakhaven Archives Hall", "roleplaying": { "ideal": "Truth Preservation", "flaw": "Physically cowardly and panics easily" } },
        "althea": { "name": "Althea the Seer", "location": "Barrowmoor Forgotten Family Shrine", "roleplaying": { "ideal": "Insight", "flaw": "Speaks always in vague double-meanings" } },
        "gideon": { "name": "Commander Gideon", "location": "Oakhaven Guard Headquarters", "roleplaying": { "ideal": "Duty", "flaw": "Blindly follows outdated imperial directives" } },
        "eldrida": { "name": "Eldrida the Weeper", "location": "Barrowmoor Mourner Cairn", "roleplaying": { "ideal": "Remembrance", "flaw": "Prone to severe melancholic trances" } },
        "fletcher": { "name": "Fletcher the Fletcher", "location": "Oakhaven Archery Ranges", "roleplaying": { "ideal": "Precision", "flaw": "Obsessed with perfect symmetry" } },
        "jorund": { "name": "Jorund the Stonecutter", "location": "Oakhaven Quarry Site", "roleplaying": { "ideal": "Endurance", "flaw": "Extremely slow to take any critical action" } },
        "brishen": { "name": "Brishen the Fortune Teller", "location": "Oakhaven Caravan Guild", "roleplaying": { "ideal": "Fate Acceptance", "flaw": "Manipulates predictions for pocket change" } },
        "orla": { "name": "Orla the Swampsinger", "location": "Barrowmoor Sunken Swampland", "roleplaying": { "ideal": "Harmony", "flaw": "Mesmerized by deadly marsh echoes" } },
        "cassian": { "name": "Cassian the Rogue", "location": "Oakhaven Back-Alley Den", "roleplaying": { "ideal": "Acrobatics", "flaw": "Incurable compulsive gambler" } },
        "thora": { "name": "Thora the Shieldmaiden", "location": "Oakhaven Practice Ring", "roleplaying": { "ideal": "Protection", "flaw": "Quick-tempered and starts tavern brawls" } },
        "finbar": { "name": "Finbar the Fisher", "location": "Barrowmoor Cold Swamp Ridge", "roleplaying": { "ideal": "Simplicity", "flaw": "Always exaggerates the size of his catches" } }
      },
      "items": {
        "blade_of_guardianship": { "name": "Blade of Guardianship", "type": "Magic Greatsword", "properties": "Sentient (Lawful Good)", "location": "Vorgun's Sarcophagus Vault" },
        "stormrider_ring": { "name": "Stormrider Ring", "type": "Ring", "properties": "Provides absolute immunity to electrical shocks", "location": "Oakhaven Shrine Altar Box" },
        "barrow_scepter": { "name": "Barrow-Stone Scepter", "type": "Scepter", "properties": "Deals bonus damage specifically to hollow earth creatures", "location": "Barrowmoor Whispering Mounds" },
        "celestial_vial": { "name": "Vial of Celestial Tears", "type": "Vial", "properties": "Cures all minor physical and magical ailments instantly", "location": "Barrowmoor Family Shrine Records" },
        "crystalline_shield": { "name": "Crystalline Aegis", "type": "Shield", "properties": "Can reflect a light spell back at its original caster", "location": "Oakhaven Council Vault" },
        "skyward_bow": { "name": "Skyward Gaze Longbow", "type": "Longbow", "properties": "Allows aiming clearly from the ground through dense storms", "location": "Barrowmoor Treehouse Blind" },
        "giants_girdle": { "name": "Belt of Giant Might", "type": "Belt", "properties": "Temporarily grants raw strength to lift minor boulders", "location": "Vorgun's Burial Guard Chamber" },
        "gale_boots": { "name": "Gale-Step Boots", "type": "Boots", "properties": "Increases standard tactical speed over wetlands", "location": "Barrowmoor Wet Silt Reach" },
        "thunder_cleaver": { "name": "Thunder-Cleaver Battleaxe", "type": "Battleaxe", "properties": "Produces a loud boom when dealing critical hits", "location": "Oakhaven Founders Memorial" },
        "sentinel_cloak": { "name": "Sentinel Cloak of Vorgun", "type": "Cloak", "properties": "Allows silent movement while a heavy downpour is active", "location": "Vorgun's Deep Sarcophagus Alcove" },
        "conduit_staff": { "name": "Stormcore Conduit Staff", "type": "Staff", "properties": "Directs passive magic streams without draining slots", "location": "Barrowmoor Weeping Cairn Altar" },
        "runic_pennant": { "name": "Standard of the Restless", "type": "Banner", "properties": "Steadies allies' courage within 30 feet", "location": "Oakhaven Guard Watchtower" },
        "storm_beacon": { "name": "Heart Beacon Core", "type": "Relic Core", "properties": "Emits a soft pulse that reveals near invisible glyphs", "location": "Vorgun's Tomb Inner Crypt" },
        "ancient_key": { "name": "Elric's Founder Ring Key", "type": "Key Ring", "properties": "Unlocks the secure iron vault inside Oakhaven's shrine", "location": "Oakhaven Elder's Private Chest" }
      }
    },
    "tables": {
      "storm_echoes": {
        "name": "Echoes Table",
        "roll_type": "d12",
        "auto_trigger": { "type": "event", "event_name": "per_hex", "condition": "outdoors == true" },
        "entries": [
          {"roll": 1, "name": "Sorrow sound echoes", "script_id": "script_sorrow"},
          {"roll": 2, "name": "Lighting strike", "script_id": "script_lightning"},
          {"roll": 3, "name": "A sudden chill sweeps the moors", "script_id": "script_cold_snap"},
          {"roll": 4, "name": "The weeping giant's face appears in clouds", "script_id": "script_cloud_face"},
          {"roll": 5, "name": "A lightning bolt strikes an ancient hollow tree", "script_id": "script_lightning_strike"},
          {"roll": 6, "name": "A surge of magical electricity fills the humid air", "script_id": "script_power_surge"},
          {"roll": 7, "name": "A wave of static whisperings that sound like lost names", "script_id": "script_static_whispers"},
          {"roll": 8, "name": "The ground shakes from a distant subterranean thunderclap", "script_id": "script_distant_quake"},
          {"roll": 9, "name": "Phantom blue rain that does not wet physical garments", "script_id": "script_phantom_rain"},
          {"roll": 10, "name": "Runic wind picks up, carrying fine glowing sand crystals", "script_id": "script_runic_sand"},
          {"roll": 11, "name": "Wailing flutes echo in the gusts from the Eastern Peak", "script_id": "script_wailing_winds"},
          {"roll": 12, "name": "A sudden eclipse forces dusk state light levels", "script_id": "script_eclipse_state"}
        ]
      },
      "wilderness_hazards": {
        "name": "Wilderness Hazards Table",
        "roll_type": "d8",
        "auto_trigger": { "type": "event", "event_name": "on_failed_navigation", "condition": "is_swamp == true" },
        "entries": [
          {"roll": 1, "name": "Quicksand Sinkhole", "script_id": "script_sinkhole"},
          {"roll": 2, "name": "Acidic Muck Spores", "script_id": "script_spores"},
          {"roll": 3, "name": "Swamp Gas Explosion", "script_id": "script_gas_explosion"},
          {"roll": 4, "name": "Swarm of Leeches", "script_id": "script_leeches"},
          {"roll": 5, "name": "Runic Arc Arc-Lightning Static Shock", "script_id": "script_arc_shock"},
          {"roll": 6, "name": "Barrowmoor Silt Mudslide", "script_id": "script_mudslide"},
          {"roll": 7, "name": "Hallucinogenic Marsh Fern Pollen", "script_id": "script_fern_pollen"},
          {"roll": 8, "name": "Spectral Willow-the-Wisp Lure", "script_id": "script_willow_lure"}
        ]
      }
    },
    "handouts": {
      "handout_thieves_diary": {
        "id": "handout_thieves_diary",
        "type": "text",
        "content": "Secret note contents..."
      },
      "handout_elder_scroll": {
        "id": "handout_elder_scroll",
        "type": "parchment",
        "content": "...by decree of the Great Founder Elric, Oakhaven warrants eternal alliance and annual rune trade streams with the Silent King of the Southern Heights..."
      },
      "handout_blacksmith_blueprint": {
        "id": "handout_blacksmith_blueprint",
        "type": "blueprint",
        "content": "...mix three parts molten Oakhaven slate ore with one drop of electrified rain under severe storm condition to harden the steel against any runic kinetic burst..."
      },
      "handout_shrine_hymn": {
        "id": "handout_shrine_hymn",
        "type": "hymnal",
        "content": "...hear our voice, Wardens of the Tempest, let the lightning pass over our halls... we return the memories of the barrow graves..."
      },
      "handout_smuggler_map": {
        "id": "handout_smuggler_map",
        "type": "map sketch",
        "content": "...charcoal map sketch detail: bypass the deep moss quicksands of Hex [0, 1] by hugging the prehistoric stone cairns on the eastern marsh ribcage..."
      },
      "handout_vorgun_will": {
        "id": "handout_vorgun_will",
        "type": "scroll of memory",
        "content": "...my power shall rest with the Sentinel greatsword... let none awake the tomb unless the three runes of memory, rage, and honor are appeased in absolute peace..."
      },
      "handout_rangers_journal": {
        "id": "handout_rangers_journal",
        "type": "ranger's field journal",
        "content": "...spotted footprints near the standing monoliths. They aren't wild beasts; the gait is too heavy, drag markings of heavy iron greaves..."
      },
      "handout_herbalist_recipe": {
        "id": "handout_herbalist_recipe",
        "type": "herbalist recipe scroll",
        "content": "...Lotus roots mashed with morning dew. Suppresses the marsh sickness, but do not inhale the dark purple vapors..."
      },
      "handout_guard_roster": {
        "id": "handout_guard_roster",
        "type": "garrison duty roster",
        "content": "...post change at midnight. Watch the Southern Highway for Smuggler caravans. Report any flickering lights above the barrow tombs..."
      },
      "handout_scribes_chronicle": {
        "id": "handout_scribes_chronicle",
        "type": "chronicle fragment",
        "content": "...the Great Schism of Year 422. How the sacred wards of Oakhaven fell when the founding families forgot their ancient blood oaths to Vorgun..."
      },
      "handout_seers_prediction": {
        "id": "handout_seers_prediction",
        "type": "divination parchment",
        "content": "...when the silver storm rises on the eighth day, the sky will bleed pale blue lightning. Only the sentinel heart can absolute ground the surge..."
      }
    },
    "hexmaps": {
      "hex-00": { 
        "q": 0, "r": 0, "s": 0, 
        "layer": 0, 
        "scale_miles": 6, 
        "terrain_override": "village",
        "runic_wind": "Gentle Climatic Breeze",
        "etheric_pressure": "1.00 atm (Standard)",
        "relative_humidity": "42% (Normal)",
        "spectral_density": "1.2% Spore Ratio (Clear)",
        "acoustic_echo": "Open Field Free Resonance"
      },
      "hex-01": { 
        "q": 1, "r": -1, "s": 0, 
        "layer": 0, 
        "scale_miles": 6, 
        "terrain_override": "swamp",
        "runic_wind": "Erratic Gale Soughs",
        "etheric_pressure": "1.08 atm (Damp)",
        "relative_humidity": "93% (Saturating Fog)",
        "spectral_density": "45% Poison Spore Spikes",
        "acoustic_echo": "Muffled & Squelched Mud Dampening"
      },
      "hex-02": { 
        "q": 3, "r": -2, "s": -1, 
        "layer": -1, 
        "scale_ft": 5, 
        "terrain_override": "worked_stone (Subterranean Tomb)",
        "runic_wind": "Chill Static Chamber Draft",
        "etheric_pressure": "0.95 atm (Underground)",
        "relative_humidity": "65% (Dank Crypt Vapors)",
        "spectral_density": "15% Ectoplasmic Mist Index",
        "acoustic_echo": "Extreme Stonework Feedback Echo"
      },
      "hex-02-surface": { 
        "q": 3, "r": -2, "s": -1, 
        "layer": 0, 
        "scale_miles": 6, 
        "terrain_override": "worked_stone (Surface Entrance)",
        "runic_wind": "Severe Gale-Force Wind Blasts",
        "etheric_pressure": "1.05 atm",
        "relative_humidity": "85% (Storm-struck Peaks)",
        "spectral_density": "3.5% Arcane Static Spores",
        "acoustic_echo": "Deep howling mountain echo resonance"
      }
    },
    "screenplays": {
      "sp_vorguns_resolution": {
        "id": "sp_vorguns_resolution",
        "name": "A Ghost of a Chance",
        "slugline": { "text": "INT. VORGUN's TOMB - RESOLUTION", "vtt_automation": { "lighting": "bright_warm_light", "sfx": "sfx_storm_fading" } },
        "screenplay_blocks": [
          { "type": "action_line", "text": "The violent winds immediately die down. The phantom giant kneels, bowing its head in reverence." },
          { "type": "vtt_animation", "target_id": "vorguns_ghost", "animation_clip": "anim_kneel_and_offer_sword" }
        ]
      },
      "sp_arrival_oakhaven": {
        "id": "sp_arrival_oakhaven",
        "name": "Stormy Entrance",
        "slugline": { "text": "EXT. OAKHAVEN VILLAGE - DAY", "vtt_automation": { "lighting": "village_dusk", "sfx": "bgm_storm_exterior" } },
        "screenplay_blocks": [
          { "type": "action_line", "text": "Heavy rain pelts the wooden rooftops of Oakhaven as the adventurers walk in." }
        ]
      },
      "sp_elara_greeting": {
        "id": "sp_elara_greeting",
        "name": "Elder's Warning Prayer",
        "slugline": { "text": "INT. OAKHAVEN COUNCILS - NIGHT", "vtt_automation": { "lighting": "bright_warm_light", "sfx": "bgm_sorrowful_ambient" } },
        "screenplay_blocks": [
          { "type": "character", "name": "ELARA" },
          { "type": "dialogue", "text": "Please, travelers! The storm giants seek our ruin if we cannot appease Vorgun's restless soul!" }
        ]
      },
      "sp_storm_escalates": {
        "id": "sp_storm_escalates",
        "name": "The Tempest Rising",
        "slugline": { "text": "EXT. THE BARROWMOORS - NIGHT", "vtt_automation": { "lighting": "tomb_interior", "sfx": "bgm_storm_exterior" } },
        "screenplay_blocks": [
          { "type": "action_line", "text": "A massive fork of violet lightning strikes a nearby monolith, shaking the very earth beneath you." }
        ]
      },
      "sp_monolith_rune": {
        "id": "sp_monolith_rune",
        "name": "The Glowing Inscriptions",
        "slugline": { "text": "EXT. ANCIENT MONOLITH - DUSK", "vtt_automation": { "lighting": "village_dusk", "sfx": "sfx_storm_fading" } },
        "screenplay_blocks": [
          { "type": "action_line", "text": "The heavy stone runes begin to glow with a pale cold blue energy." }
        ]
      },
      "sp_tomb_breach": {
        "id": "sp_tomb_breach",
        "name": "Breaching the Mound",
        "slugline": { "text": "INT. TOMB ENTRANCE - DUNGEON", "vtt_automation": { "lighting": "tomb_interior", "sfx": "bgm_sorrowful_ambient" } },
        "screenplay_blocks": [
          { "type": "action_line", "text": "The giant iron-reinforced heavy stone doors grind open, revealing the dark void of Vorgun's tomb." }
        ]
      },
      "sp_ghost_apparition": {
        "id": "sp_ghost_apparition",
        "name": "Haunted Giant Apparition",
        "slugline": { "text": "INT. TOMB INNER CHAMBER - NIGHT", "vtt_automation: { "lighting": "tomb_interior", "sfx": "bgm_sorrowful_ambient" } },
        "screenplay_blocks": [
          { "type": "action_line", "text": "A huge, semi-transparent spectral figure rises from the central sarcophagus." }
        ]
      },
      "sp_relic_awakens": {
        "id": "sp_relic_awakens",
        "name": "Awakening of the Relic",
        "slugline": { "text": "INT. THE BURIAL MOUND - DAY", "vtt_automation": { "lighting": "bright_warm_light", "sfx": "sfx_storm_fading" } },
        "screenplay_blocks": [
          { "type": "action_line", "text": "The ancient sword atop the shrine pulses with bright static energy, humming with celestial power." }
        ]
      },
      "sp_spirit_restoration": {
        "id": "sp_spirit_restoration",
        "name": "Restoration of the Spirit",
        "slugline": { "text": "INT. VORGUN'S ALCOVE - DUSK", "vtt_automation": { "lighting": "bright_warm_light", "sfx": "sfx_storm_fading" } },
        "screenplay_blocks": [
          { "type": "action_line", "text": "The spectral giant closes its shining blue eyes as the runes return to their places. The storm finally breaks." }
        ]
      },
      "sp_ambient_whispers": {
        "id": "sp_ambient_whispers",
        "name": "Whispers from Cold Swamp",
        "slugline": { "text": "EXT. COLD SWAMP RIDGE - NIGHT", "vtt_automation": { "lighting": "tomb_interior", "sfx": "bgm_storm_exterior" } },
        "screenplay_blocks": [
          { "type": "action_line", "text": "Ghostly voices whisper through the moaning wind, telling ancient tales of honor and betrayal." }
        ]
      },
      "sp_climax_victory": {
        "id": "sp_climax_victory",
        "name": "Highlands Golden Rays",
        "slugline": { "text": "INT. SHATTERED SANCTUM - DAY", "vtt_automation": { "lighting": "bright_warm_light", "sfx": "sfx_storm_fading" } },
        "screenplay_blocks": [
          { "type": "action_line", "text": "Sunlight pierces through the cracked ceiling of the tomb, casting golden rays on the giant's silent sword." }
        ]
      }
    },
    "dialogue_trees": {
      "dt_elara_hub": {
        "id": "dt_elara_hub",
        "nodes": {
          "start": {
            "npc_text": "Greetings, traveler. Will you go braving the storm?",
            "speaking_intent": "Plea for assistance and communal safety regarding the missing youth",
            "player_options": [
              { "text": "Yes, we accept.", "next_node": "accept", "trigger_script": "seq_accept_main_quest", "speaking_intent": "Altruistic Heroic Undertaking" },
              { "text": "No, I need information.", "next_node": "lore_dump", "speaking_intent": "Fact-Finding & Local Lore Probe" }
            ]
          },
          "lore_dump": {
            "npc_text": "The storm is radiating from the tomb of the long dead Giant Vorgun...",
            "speaking_intent": "Sorrowful lore disclosure and defense of the misunderstood guardian giant",
            "player_options": [
              { "text": "Now we go help.", "next_node": "accept", "trigger_script": "seq_accept_main_quest", "speaking_intent": "Communal Duty Alliance & Resolute Resolve" }
            ]
          },
          "accept": {
            "npc_text": "May gods protect you. Seek the tomb.",
            "speaking_intent": "Solemn spiritual benediction and tactical road route brief",
            "player_options": [
              { "text": "[End Dialogue]", "next_node": "exit_dialogue", "speaking_intent": "Dismissal and Departure" }
            ]
          }
        }
      }
    }
  },
  "factions": {
    "oakhaven_villagers": { 
      "name": "Settlers", 
      "relations": { "restless_spirits": "Hostile" },
      "controlled_areas": ["Oakhaven Town Square", "Southern Farmlands", "Council High Hall"]
    },
    "restless_spirits": { 
      "name": "Spirits of the Barrowmoor", 
      "relations": { "oakhaven_villagers": "Hostile", "player_party": "Hostile" },
      "controlled_areas": ["Damp Barrowmoors", "The Forgotten Crypts", "Highlands Cemetery"]
    },
    "ironwood_circle": { 
      "name": "The Ironwood Circle", 
      "relations": { "oakhaven_villagers": "Neutral", "restless_spirits": "Hostile", "player_party": "Friendly" },
      "controlled_areas": ["Whispering Woods", "Sentinel Stone Monoliths", "Western Leyline Conduit"]
    },
    "storm_wardens": { 
      "name": "The Storm Wardens Brotherhood", 
      "relations": { "oakhaven_villagers": "Friendly", "restless_spirits": "Hostile", "player_party": "Friendly" },
      "controlled_areas": ["Lighthouse Citadel", "Garrison Watchtowers", "High Warding Shrines"]
    }
  },
  "locations": {
    "loc_oakhaven": { "id": "loc_oakhaven", "name": "Oakhaven", "type": "settlement", "hexmap_id": "hex-00", "default_lighting": "lighting_states.village_dusk" },
    "loc_barrowmoors": { "id": "loc_barrowmoors", "name": "The Moors", "type": "wilderness", "hexmap_id": "hex-01" },
    "loc_vorguns_tomb": { "id": "loc_vorguns_tomb", "name": "Vorgun's Tomb", "type": "dungeon", "hexmap_id": "hex-02", "default_lighting": "lighting_states.tomb_interior" }
  },
  "scripts": {
    "seq_accept_main_quest": { "id": "seq_accept_main_quest", "sequence": [] }
  },
  "procedures": {
    "global_weather": {
      "id": "proc_global_weather",
      "name": "The Weeping Sky",
      "trigger": { "type": "per_hour_outdoor" },
      "script": { "sequence": [{ "type": "apply_global_effect", "effect": "Light obscuration." }] }
    },
    "restless_souls_rise": {
      "id": "proc_restless_souls_rise",
      "name": "Midnight Apparition Uprising",
      "trigger": { "type": "nighttime_check" },
      "script": {
        "sequence": [
          { "type": "spawn_entities", "effect": "Restless phantoms manifest around the Barrowmoors." },
          { "type": "apply_fog", "effect": "Gloomy thick spiritual fog rises from the soil." }
        ]
      }
    },
    "wild_magic_surge": {
      "id": "proc_wild_magic_surge",
      "name": "Runic Storm Interference",
      "trigger": { "type": "spellcast_detected" },
      "script": {
        "sequence": [
          { "type": "magical_chaos", "effect": "Spells have a chance to trigger a random wild surge from the matrix." },
          { "type": "aurora_discharge", "effect": "Violent blue electromagnetic lightning flashes across the canopy, scrambling compass markers." },
          { "type": "mana_static", "effect": "Flickering runic particles cloud the air, amplifying arcane damage but increasing spell failure rate." },
          { "type": "geomagnetic_pull", "effect": "Gravitational anomalies lift loose daggers and artifacts in mid-air, rendering heavy armor taxing." },
          { "type": "spell_suppression", "effect": "Ancient sigils on monuments flare bright white, nullifying low-tier utility dynamic protective wards." },
          { "type": "planar_resonance", "effect": "Whispers of long-lost scholars echo from leyline nodes; grants fleeting inspiration but costs deep sanity." }
        ]
      }
    },
    "seismic_rumor_shudder": {
      "id": "proc_seismic_rumor_shudder",
      "name": "Barrow Ground Tremor",
      "trigger": { "type": "every_six_turns" },
      "script": {
        "sequence": [
          { "type": "camera_shake", "effect": "Earthquakes rumble down inside Vorgun's resting halls." }
        ]
      }
    },
    "lightning_discharge": {
      "id": "proc_lightning_discharge",
      "name": "Furious Static Discharge",
      "trigger": { "type": "per_round_combat" },
      "script": {
        "sequence": [
          { "type": "elemental_damage", "effect": "Lightning bolts strike high metal points randomly." }
        ]
      }
    }
  },
  "scenes": {
    "scene_arrival_at_oakhaven": {
      "id": "scene_arrival_at_oakhaven",
      "location_id": "loc_oakhaven",
      "description": "The initial arrival of the party at Oakhaven, seeking the council elders and investigating initial clues under dark clouds.",
      "constraints_fulfilled": ["State: Adventure Initiated", "Entity: Elder Elara Present", "VFX: Rain Overlay Enabled"],
      "actors": [{ "id": "elara", "role": "quest_giver" }],
      "social_encounters": [
        {
          "id": "soc_arrival_elara",
          "npc_id": "elara",
          "npc_name": "Elder Elara (The Grove Guardian)",
          "context": "As you step across the village threshold, Elder Elara approaches. Rain pours from her wooden cowl as she looks upon the party with serious eyes, pleading for you to find her grandson and secure the warding stones.",
          "skill_challenges": [
            {
              "skill": "Insight (Empathetic Assessment)",
              "dc": 11,
              "success_outcome": "You sense her deep grief and determination. She trusts you completely, revealing a shortcut through the barrowmoors (+100 XP, skip first environmental hazard).",
              "failure_outcome": "She is guarded and shares only the direct paths, warning that danger lies everywhere."
            }
          ]
        }
      ],
      "outcomes": [{ "condition": "world_state:main_quest_accepted == true", "next_scene_id": "scene_journey_barrowmoors" }],
      "screenplays_attached": ["sp_arrival_oakhaven", "sp_elara_greeting"]
    },
    "scene_oakhaven_council_meeting": {
      "id": "scene_oakhaven_council_meeting",
      "location_id": "loc_oakhaven",
      "description": "The tense deliberative summit where village elders argue and critical swamp security and reconnaissance updates are distributed.",
      "constraints_fulfilled": ["State: Council Council Summoned", "Weather: Heavy Rain"],
      "actors": [{ "id": "elara", "role": "moderator" }],
      "screenplays_attached": ["sp_elara_greeting"]
    },
    "scene_oakhaven_tavern_whispers": {
      "id": "scene_oakhaven_tavern_whispers",
      "location_id": "loc_oakhaven",
      "description": "Late-night hushed conversations and rumors shared over hot spiced mead regarding ghost sight in the northern moors.",
      "constraints_fulfilled": ["Time: Evening", "Tavern: Open"],
      "social_encounters": [
        {
          "id": "soc_tavern_barkeep",
          "npc_id": "barkeep_corbin",
          "npc_name": "Barkeep Corbin (Oakhaven Informant)",
          "context": "Barkeep Corbin cleans a wooden goblet, keeping his voice low as he whispers rumors of strange blue lightning striking the ancient tomb to the north.",
          "skill_challenges": [
            {
              "skill": "Deception/Persuasion (Gather Information)",
              "dc": 12,
              "success_outcome": "Corbin slips you a mapped layout of the outer burial grounds and notes that the spirits fear silvered steel weapons.",
              "failure_outcome": "Corbin gets nervous and clams up, refusing to talk about forbidden ghosts in front of other patrons."
            }
          ]
        }
      ],
      "screenplays_attached": ["sp_ambient_whispers"]
    },
    "scene_oakhaven_shrine_blessing": {
      "id": "scene_oakhaven_shrine_blessing",
      "location_id": "loc_oakhaven",
      "description": "A sacred divine ward activation ritual performed at the stone monolith altar to secure localized spiritual defense.",
      "constraints_fulfilled": ["Weather: Thunderstorm", "Aura: Divine Ward Active"],
      "screenplays_attached": ["sp_monolith_rune"]
    },
    "scene_journey_barrowmoors": {
      "id": "scene_journey_barrowmoors",
      "location_id": "loc_barrowmoors",
      "description": "An arduous swamp trek through dense fog, waterlogged soil, and ancient graves to reach the tomb of the restless giant.",
      "constraints_fulfilled": ["Required: Social Investigation Completed", "Quest Stage: main_quest_accepted == true", "Coordinates: Hex [0, 1] Discovered"],
      "outcomes": [],
      "screenplays_attached": ["sp_storm_escalates", "sp_monolith_rune", "sp_ambient_whispers"]
    },
    "scene_burial_chamber_climax": {
      "id": "scene_burial_chamber_climax",
      "location_id": "loc_vorguns_tomb",
      "description": "The wet stone burial sepulcher chamber where Vorgun's spirit hovers, radiating ancient lightning storm magic.",
      "constraints_fulfilled": ["Required: Wilderness Exploration Completed", "Encounter Key: vorguns_ghost Activated", "Clues Discovered: >= 2"],
      "encounters": [
        { "id": "enc_vorguns_ghost", "actors": [{ "entity_id": "monsters.vorguns_ghost", "quantity": 1 }], "on_actor_takes_damage": { "action": "add_die_to_tension_pool" } }
      ],
      "outcomes": [],
      "screenplays_attached": ["sp_vorguns_resolution", "sp_tomb_breach", "sp_ghost_apparition", "sp_relic_awakens", "sp_spirit_restoration", "sp_climax_victory"]
    }
  },
  "world_state": {
    "time_elapsed_hours": 0,
    "current_time_of_day": "12:00",
    "tension_pool_current_dice": 4,
    "discovered_clues": ["handout_thieves_diary"],
    "unlocked_secrets": [],
    "active_global_effects": [],
    "completed_scenes": ["scene_arrival_at_oakhaven"],
    "active_scene": "scene_journey_barrowmoors",
    "weather_vector": "Storm Intensity Tier 4 (Severe Electrified Runic Tempest)",
    "leyline_resonance": "74% Resonance Ratio (Leyline Nexus Sync Active)",
    "challenge_rating_tier": "Level 4 Challenge Rating",
    "time_before_tomb_collapse": "36 Hours Remaining",
    "critical_doom_factor": "Threat level 2 (Moderate Incident Hazard)",
    "planar_instability": "12% Instability Ratio (Planar Distortion Low)",
    "sanctuary_ward_level": "Level 3 Dynamic Protective Ward Active",
    "anomaly_gravitational_pull": "Gravity G-Force: 1.05g (Stable Terrain Pull)",
    "flags": {
      "rage_appeased": false,
      "memory_appeased": false,
      "main_quest_accepted": true,
      "storms_cease_fully": false
    },
    "dynamic_factions": {
      "oakhaven_villagers": { "attitude_to_party": "Friendly" }
    }
  }
}
`,
      config: {
        systemInstruction: "You are the Chronos Adventure compiler module. You produce beautiful, fully developed, theme-rich custom fantasy RPG adventure structures based strictly on the user's concept prompt. The response MUST be extremely clean, compliant, valid JSON adhering to the target schema precisely without markdown quotes outside the bracket block.",
        responseMimeType: "application/json"
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("Zero response received from the Gemini compilation model.");
    }

    const cleanedText = text.trim();
    const resultJson = JSON.parse(cleanedText);
    res.json(resultJson);
  } catch (error: any) {
    console.error("Gemini Scan Generation Failure:", error);
    res.status(500).json({ error: error.message || "Failed to parse synthesized campaign block" });
  }
});

// Configure Vite integration for dev vs prod running states
const startServer = async () => {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Chronos Hub] Full-stack Server locked on port ${PORT}`);
  });
};

startServer();
