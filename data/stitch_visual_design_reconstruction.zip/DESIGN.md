---
name: Chronos Systems Interface
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e4e2e1'
  on-surface: '#1b1c1c'
  on-surface-variant: '#4c4546'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0f0'
  outline: '#7e7576'
  outline-variant: '#cfc4c5'
  surface-tint: '#5e5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1b'
  on-primary-container: '#848484'
  inverse-primary: '#c6c6c6'
  secondary: '#5f5f58'
  on-secondary: '#ffffff'
  secondary-container: '#e2e0d7'
  on-secondary-container: '#64635c'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1d1c14'
  on-tertiary-container: '#878478'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c6'
  on-primary-fixed: '#1b1b1b'
  on-primary-fixed-variant: '#474747'
  secondary-fixed: '#e5e2da'
  secondary-fixed-dim: '#c9c6be'
  on-secondary-fixed: '#1c1c17'
  on-secondary-fixed-variant: '#474741'
  tertiary-fixed: '#e7e2d5'
  tertiary-fixed-dim: '#cbc6b9'
  on-tertiary-fixed: '#1d1c14'
  on-tertiary-fixed-variant: '#49473d'
  background: '#fcf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e1'
typography:
  display-xl:
    fontFamily: Archivo Narrow
    fontSize: 96px
    fontWeight: '900'
    lineHeight: 90px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Archivo Narrow
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 52px
  headline-md:
    fontFamily: Archivo Narrow
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 28px
  body-lg:
    fontFamily: Source Serif 4
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Source Serif 4
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.1em
  data-table:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
  headline-lg-mobile:
    fontFamily: Archivo Narrow
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 40px
spacing:
  grid-unit: 4px
  gutter-md: 16px
  margin-edge: 24px
  border-thick: 3px
  border-thin: 1px
---

## Brand & Style

This design system evokes the aesthetic of a high-fidelity 1970s tabletop RPG manual, blending the tactile quality of printed parchment with the rigid efficiency of early industrial computer interfaces. It is a "Retro-Futuristic Brutalist" style that prioritizes legibility, information density, and a sense of physical permanence.

The visual narrative is built on:
- **Printed Imperfection:** A "warm" paper-like base that suggests physical medium.
- **Industrial Rigidity:** Heavy black strokes, strict grid alignment, and monospaced data fields.
- **Authoritative Hierarchy:** Massive, unapologetic sans-serif headers contrasted against classic serif lore text and technical monospaced labels.
- **Tactile Depth:** Depth is achieved through thick, high-contrast borders and "stamped" visual elements rather than shadows or blurs.

## Colors

The palette is strictly limited to mimic the constraints of 1970s offset printing.

- **Primary (Deep Black):** Used for all structural borders, primary headings, and iconography. It represents ink.
- **Secondary (Parchment):** The universal background color, providing a warm, low-fatigue reading surface.
- **Tertiary (Dusty Gray):** Used for table headers, secondary UI surfaces, and subtle dividers to distinguish data sets without breaking the black/white contrast.
- **Status Colors:** Use high-saturation Red or Amber sparingly for "System Warnings" or "Critical Failures," maintaining a monochromatic feel elsewhere.

## Typography

Typography is the core of this design system, using three distinct voices:
1. **The Voice of Authority (Sans):** Heavyweight sans-serif for titles and navigation. It should feel loud, impactful, and "official."
2. **The Voice of Lore (Serif):** Traditional serif for long-form narrative text. It provides a literary, academic feel appropriate for an RPG "tome."
3. **The Voice of the Machine (Mono):** Technical data, stats, and metadata are exclusively monospaced to indicate "system" output.

**Scaling:** On mobile, reduce display sizes by 30% but maintain the heavy weights. All labels must remain in uppercase monospaced type for consistent "technical" feel.

## Layout & Spacing

This design system uses a **Rigid Grid** layout. 
- **The Container:** On desktop, use a 12-column grid with no rounded corners.
- **Gutters:** 16px (fixed) to ensure borders never touch unless intended.
- **Margins:** A wide 24px-48px outer margin mimics the "safe area" of a printed page.
- **Alignment:** Every element must snap to a 4px baseline grid. Text should be left-aligned (ragged right) for lore, and justified only in specific data tables.
- **Reflow:** On mobile, the sidebar collapses into a bottom-anchored industrial navigation bar. Content cards stack vertically with 1px black dividers.

## Elevation & Depth

Depth is conveyed through **Structural Framing** rather than light and shadow.

- **Level 0 (Base):** The Parchment surface (#F5F2E9).
- **Level 1 (Sections):** Defined by 1px black borders.
- **Level 2 (Active/Focus):** High-contrast inversion. When an item is selected, it fills with Deep Black (#000000) and the text becomes Parchment (#F5F2E9).
- **Lore Boxes:** Offset with a 3px heavy black border and a subtle internal padding to create a "inset" look.
- **Tables:** Use alternating row fills (Parchment vs. Dusty Gray) to maintain horizontal scan lines without adding vertical borders.

## Shapes

The design system is strictly **orthogonal**.
- **Corner Radius:** 0px for all elements (buttons, inputs, cards). 
- **Borders:** All UI components are defined by visible strokes. Never use shadow to define a shape boundary.
- **Visual Dividers:** Use solid black lines. For "system" status bars, use thick (8px+) solid blocks of black.

## Components

- **Industrial Buttons:** Rectangular, 0px radius, 2px black border. Hover state inverts colors (Black background, Parchment text). Label is always `label-mono`.
- **Character Stat Tables:** High-density grids. Headers are solid black with white monospaced text. Cells are separated by 1px dividers.
- **Lore Boxes:** Specialized cards for narrative text. They feature a "Header Tab" (a small black rectangle with white text) that overlaps the top border.
- **Navigation Rails:** Vertical sidebar using thick stroke-based industrial icons. Active states should use a "filled" version of the icon or a thick horizontal "selection notch."
- **Input Fields:** Labeled with monospaced text above the field. Field is a simple 1px black bottom-border (underline style) or a fully boxed 1px stroke.
- **Industrial Icons:** 24px grid, 2px stroke weight. No rounded caps or joins; use mitered (sharp) corners for all iconography.