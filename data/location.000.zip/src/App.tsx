/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Dossier from './components/Dossier';

export default function App() {
  return <Dossier />;
}
