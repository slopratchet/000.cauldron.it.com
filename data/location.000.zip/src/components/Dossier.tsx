export default function Dossier() {
  return (
    <div className="min-h-screen flex-col antialiased selection:bg-primary selection:text-surface flex">
      <main className="flex-1 flex flex-col min-w-0 bg-surface">
        <div className="p-4 md:p-8 flex-1 overflow-y-auto pattern-bg text-onSurface">
          <div className="max-w-7xl mx-auto space-y-8">
            
            {/* Header Block */}
            <div className="brutalist-border bg-surface p-6 sm:p-8 relative overflow-hidden flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div className="relative z-10">
                <h1 className="text-5xl sm:text-7xl font-black uppercase tracking-tighter mb-2 leading-none">
                  METROPOLIS RECON
                </h1>
                <h2 className="text-xl sm:text-2xl font-mono uppercase tracking-widest text-primary border-t-4 border-border pt-2 inline-block">
                  Urban Decay Study Plate 012
                </h2>
              </div>
              <div className="flex flex-col items-end text-right font-mono text-xs space-y-1">
                <div className="bg-primary text-surface px-2 py-1 font-bold">URBAN RUIN CONTEXT</div>
                <div>SCAN DATE: 1970-08-12</div>
                <div>SCALE: 1:5000</div>
              </div>
            </div>

            {/* Asymmetrical Grid Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Left Column (Wider): Visual Data */}
              <div className="lg:col-span-8 space-y-8">
                {/* Main Recon Image */}
                <div className="brutalist-border bg-surface p-2 pb-12 relative">
                  <div className="absolute top-4 left-4 bg-primary text-surface px-3 py-1 text-sm font-mono z-10 font-bold">
                    VISUAL FEED: SECTOR A-12
                  </div>
                  <img 
                    alt="High-contrast brutalist technical photograph of a sprawling urban ruin." 
                    className="w-full h-auto object-cover border-2 border-border" 
                    src="https://lh3.googleusercontent.com/aida/ADBb0uhwITCgUwC9T_XQGR7MnvzNs07UN-qZP2yLzaDkijnhPA-3ib8u1ESDTUs1jyDoMTvaEJMW0diLH9S2VTA2j_ODvSuEh8NuUgXT9wJArYqvCdVo71iW1mQGuwTnA-9Z14PrxAjTR89_tSZZ79DNJxBdYA22sd7Yi2Izuk-6xYbyxuk4-bcOmS7YSO7dNnT2blnHOrhF6YEDowN2DO4_DQrd8eBSa9QfWH_9rzzgDsUV6-D9UFiOtzFUvHEm"
                  />
                  <div className="absolute bottom-3 left-4 right-4 flex justify-between items-end font-mono text-[10px] uppercase opacity-60">
                    <div>// SENSORS DETECT HIGH STRUCTURAL DECAY //</div>
                    <div className="text-right">PLATE_012_REFERENCE</div>
                  </div>
                </div>

                {/* Biomass Infestation Matrix */}
                <div className="brutalist-border bg-surface p-6 sm:p-8 grid-bg">
                  <div className="flex items-center justify-between mb-6 border-b-4 border-border pb-2">
                    <h3 className="text-3xl font-black uppercase">Biomass Infestation</h3>
                    <span className="font-mono text-xs font-bold border-2 border-border px-2 py-1 bg-surface">
                      LEVEL 3 DETECTED
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="brutalist-border-medium p-4 bg-surface">
                      <h4 className="font-bold uppercase text-sm mb-2 border-b border-border">Biological Markers</h4>
                      <ul className="font-mono text-sm space-y-2">
                        <li className="flex items-start gap-2">
                          <span className="mt-1 w-2 h-2 bg-primary flex-shrink-0"></span>
                          <span>Aggressive vine propagation (Type-B)</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="mt-1 w-2 h-2 bg-primary flex-shrink-0"></span>
                          <span>Spore concentration in flooded zones</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="mt-1 w-2 h-2 bg-primary flex-shrink-0"></span>
                          <span>Nocturnal fauna activity (Unclassified)</span>
                        </li>
                      </ul>
                    </div>
                    <div className="brutalist-border-medium p-4 bg-surface">
                      <h4 className="font-bold uppercase text-sm mb-2 border-b border-border">Atmospheric Data</h4>
                      <div className="space-y-3 font-mono text-sm">
                        <div className="flex justify-between">
                          <span>HUMIDITY:</span><span className="font-bold">92%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>TOXICITY:</span><span className="font-bold text-red-600">MODERATE</span>
                        </div>
                        <div className="w-full bg-surfaceDim h-4 brutalist-border-medium relative overflow-hidden">
                          <div className="absolute inset-0 bg-primary w-3/4"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column (Narrower): Tactical Analysis */}
              <div className="lg:col-span-4 space-y-8">
                
                {/* Collapse Risk Box */}
                <div className="brutalist-border bg-primary text-surface p-6">
                  <h3 className="text-2xl font-black uppercase mb-4 border-b-2 border-white/30 pb-2">Collapse Risk</h3>
                  <div className="space-y-4 font-sans text-lg">
                    <p className="leading-tight">
                      Structural integrity of monoliths is compromised. Zone A displays imminent failure indicators.
                    </p>
                    <div className="brutalist-border-medium border-surface/50 bg-white/10 p-3 font-mono text-xs">
                      <p className="font-bold mb-1">WARNINGS:</p>
                      <ul className="list-none space-y-1">
                        <li>- Severe rebar corrosion</li>
                        <li>- Foundation displacement</li>
                        <li>- Hydrostatic pressure buildup</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Infiltration Routes */}
                <div className="brutalist-border bg-surface p-6 relative">
                  <div className="absolute -top-3 right-4 bg-surface px-2 border-2 border-border text-[10px] font-bold font-mono">
                    ENHANCED INTEL
                  </div>
                  <h3 className="text-2xl font-black uppercase mb-4 border-b-2 border-border pb-2">Infiltration Routes</h3>
                  <div className="space-y-3">
                    <div className="brutalist-border-medium p-3 bg-surfaceDim mt-2 bg-opacity-30">
                      <span className="text-xs font-bold font-mono text-primary uppercase block mb-1">
                        Primary Route: Sub-Street
                      </span>
                      <p className="text-sm">Accessible via flooded subway vents. High stealth, medium hazard from structural shifting.</p>
                    </div>
                    <div className="brutalist-border-medium p-3">
                      <span className="text-xs font-bold font-mono text-primary uppercase block mb-1">
                        Secondary: Aerial
                      </span>
                      <p className="text-sm">Rappelling from Sector B skyscrapers. Visible to long-range sensors but avoids ground hazards.</p>
                    </div>
                  </div>
                </div>

                {/* Technical Specs Nested Grid */}
                <div className="brutalist-border bg-surfaceDim p-4 font-mono text-xs space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-2 border border-border bg-surface">
                      <span className="block font-bold opacity-50 uppercase">Grid Ref</span>
                      <span className="text-sm">XP-884-01</span>
                    </div>
                    <div className="p-2 border border-border bg-surface">
                      <span className="block font-bold opacity-50 uppercase">Sector ID</span>
                      <span className="text-sm">METRO-RUIN-12</span>
                    </div>
                  </div>
                  <div className="p-2 border border-border bg-surface">
                    <span className="block font-bold opacity-50 uppercase mb-1">Status Report</span>
                    <p className="leading-relaxed">
                      Urban decay has reached terminal velocity. Natural reclamation is exceeding forecasted rates. Suggest immediate evacuation or fortification of subterranean bunkers.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Data Footer */}
            <div className="flex flex-col sm:flex-row justify-between items-center brutalist-border bg-surface p-4 text-xs font-mono uppercase tracking-widest gap-4">
              <div className="flex gap-4">
                <span>// CHRONOS SYSTEM</span>
                <span className="opacity-40">TERMINAL INTERFACE</span>
              </div>
              <div className="flex gap-4">
                <span className="font-bold">END OF FILE</span>
                <span className="bg-primary text-surface px-2">REF: TOME-1970-PLT-012</span>
              </div>
            </div>
            
          </div>
        </div>
      </main>
    </div>
  );
}
