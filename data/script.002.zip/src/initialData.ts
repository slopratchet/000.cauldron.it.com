import { Operation } from './types';

export const INITIAL_OPERATIONS: Operation[] = [
  {
    id: 'jaguar_shark',
    title: 'Operation: Jaguar Shark',
    location: 'MEDITERRANEAN SEA',
    time: '0400 HRS',
    target: 'JAGUAR SHARK',
    clearanceLevel: 'LEVEL 4',
    metadataCode: 'LOG: 001-A // REC: LO-FI',
    objectives: [
      { id: 'obj1', text: 'Establish primary motivation (Revenge).', checked: true },
      { id: 'obj2', text: 'Introduce the Belafonte crew dynamic.', checked: false },
      { id: 'obj3', text: 'Ensure weapon systems are armed.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'steve',
        name: 'SUBJECT_01: ZISSOU, STEVE',
        role: 'Oceanographer & Expedition Leader',
        description: 'Narcissistic tendencies. Obsessive fixation on specific marine fauna. High leadership charisma but questionable tactical judgment.',
        notes: '>> Note: Monitor for signs of erratic behavior post-Esteban incident.',
        status: 'ACTIVE'
      },
      {
        id: 'esteban',
        name: 'SUBJECT_02: ESTEBAN DU PLANTIER',
        role: 'Chief Diver & Loyal Partner',
        description: 'Loyal operative. Highly skilled in sub-surface photography. Experienced underwater camera work.',
        notes: '>> Note: Deceased during underwater filming incident. Target species suspected.',
        status: 'DECEASED'
      },
      {
        id: 'klaus',
        name: 'SUBJECT_03: DAIMLER, KLAUS',
        role: 'German First Mate',
        description: 'Rigid adherence to protocol. Secretly insecure about sibling-like dynamics. Protective over the captain.',
        notes: '>> Note: Prone to silent fits of jealousy when new members join "Zissou Society".',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      {
        id: 'l1',
        type: 'heading',
        text: 'EXT. RESEARCH VESSEL BELAFONTE - DAY'
      },
      {
        id: 'l2',
        type: 'action',
        text: "The Belafonte cuts through the choppy Mediterranean. It's an old, refitted minesweeper, painted sea-foam green with yellow trim. A red tracking light blinks intermittently on the main mast."
      },
      {
        id: 'l3',
        type: 'dialogue',
        characterName: 'STEVE ZISSOU (V.O.)',
        text: "Let me tell you about my boat. She's a good ship. A little tired, maybe. But she's seen things. Like the thing that ate my friend.",
        parenthetical: ''
      },
      {
        id: 'l4',
        type: 'heading',
        text: 'INT. BELAFONTE BRIDGE - CONTINUOUS'
      },
      {
        id: 'l5',
        type: 'action',
        text: 'Steve stands at the helm, wearing his signature red beanie. He looks through a pair of heavy binoculars. KLAUS, the German first mate, stands rigidly nearby.'
      },
      {
        id: 'l6',
        type: 'dialogue',
        characterName: 'KLAUS',
        text: 'Sonar is picking up anomalous mass at bearing 2-niner-0. Depth 400 meters.',
        parenthetical: ''
      },
      {
        id: 'l7',
        type: 'dialogue',
        characterName: 'STEVE',
        text: 'Is it him?',
        parenthetical: '(lowering binoculars)'
      },
      {
        id: 'l8',
        type: 'dialogue',
        characterName: 'KLAUS',
        text: "It's big, Steve. Too big for a normal shark. The radar spectrum is shifting to a bright yellow-colored ripple.",
        parenthetical: ''
      },
      {
        id: 'l9',
        type: 'alert',
        text: 'Steve turns. His eyes are dead, focused on an invisible point.'
      },
      {
        id: 'l10',
        type: 'dialogue',
        characterName: 'STEVE',
        text: "Arm the depth charges. Load the glocks. We're going fishing. Tell the interns to bring my slippers and a thermos of Campari.",
        parenthetical: ''
      },
      {
        id: 'l11',
        type: 'heading',
        text: 'INT. SUB-DECK WEAPONS LOCKER - MINUTES LATER'
      },
      {
        id: 'l12',
        type: 'action',
        text: 'A pale, yellowish overhead light bulb flickers. Klaus is carefully arranging rubber-coated spear-guns and several steel-cased tracking beacons on a wool blanket.'
      },
      {
        id: 'l13',
        type: 'dialogue',
        characterName: 'KLAUS',
        text: "We only have three heavy-caliber cartridges left. The budget office denied the requisition for the titanium harpoons.",
        parenthetical: '(sighing deeply)'
      },
      {
        id: 'l14',
        type: 'dialogue',
        characterName: 'STEVE',
        text: "We'll use standard iron spikes then. And tell Pele to start playing the Portuguese acoustic track. It stabilizes my central balance mechanism.",
        parenthetical: '(unlatching a rusty compartment)'
      },
      {
        id: 'l15',
        type: 'alert',
        text: 'The ship engines roar suddenly. A vibration rattles the glass test tubes on the research shelves.'
      },
      {
        id: 'l16',
        type: 'dialogue',
        characterName: 'KLAUS',
        text: "If we go down there, Steve... we must do it precisely by the book. No dynamic solo dive runs.",
        parenthetical: '(eyebrows tense)'
      },
      {
        id: 'l17',
        type: 'dialogue',
        characterName: 'STEVE',
        text: "Klaus, I am the book. I wrote the screenplay, remember? Now secure the safety lines.",
        parenthetical: '(patting Klaus on the cheek)'
      }
    ]
  },
  {
    id: 'midnight_abyss',
    title: 'Operation: Midnight Abyss',
    location: 'MARIANA DEEP',
    time: '2345 HRS',
    target: 'BLACK ABYSSAL JELLY',
    clearanceLevel: 'LEVEL 5',
    metadataCode: 'LOG: 042-B // REC: UNDERWATER',
    objectives: [
      { id: 'obj_m1', text: 'Submerge Bathysphere to 3000m.', checked: true },
      { id: 'obj_m2', text: 'Calibrate fluorescent camera filters.', checked: false },
      { id: 'obj_m3', text: 'Avoid hull collapse pressure.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'steve_abyss',
        name: 'SUBJECT_01: ZISSOU, STEVE',
        role: 'Submersible Pilot',
        description: 'Commanding local bathysphere. Uncomfortable in tight spaces but denies it vehemently.',
        notes: '>> Note: Claims he can detect pressure anomalies using his "bad knee".',
        status: 'ACTIVE'
      },
      {
        id: 'ned',
        name: 'SUBJECT_04: PLIMPTON, NED',
        role: 'Co-Pilot & Associate',
        description: 'Southern charm, wears vintage pilot leather jacket. Extremely polite but holds deep unvoiced questions.',
        notes: '>> Note: Operational focus is high. Trust factor is optimal.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      {
        id: 'm_l1',
        type: 'heading',
        text: 'INT. DEEP-SEA BATHYSPHERE - NIGHT'
      },
      {
        id: 'm_l2',
        type: 'action',
        text: 'Pitch blackness outside the heavy viewport. Inside, the cabin is bathed in a sickly crimson glow. Condensation drips from the curved steel roof plates.'
      },
      {
        id: 'm_l3',
        type: 'dialogue',
        characterName: 'NED',
        text: 'Pressure is exceeding three hundred atmospheres, Captain. She is creaking in a way I do not enjoy.',
        parenthetical: '(tapping the dial gauge)'
      },
      {
        id: 'm_l4',
        type: 'dialogue',
        characterName: 'STEVE',
        text: 'That is just the joints settling. They do that on old vessels. Do not panic, Kingsley.',
        parenthetical: '(taking a sip of campari)'
      },
      {
        id: 'm_l5',
        type: 'dialogue',
        characterName: 'NED',
        text: "My name is Ned, actually. And I am quite concerned that the emergency ballasts are full of salt water rather than compressed air.",
        parenthetical: ''
      },
      {
        id: 'm_l6',
        type: 'alert',
        text: 'A profound groaning sound ripples through the iron sphere. Outside, a massive, bioluminescent sapphire light flashes briefly.'
      },
      {
        id: 'm_l7',
        type: 'dialogue',
        characterName: 'STEVE',
        text: 'Ready the flash bulbs. That was not settling. That was a signature glowing tentacle. It is beautiful, in a highly dangerous way.',
        parenthetical: '(squinting through the glass)'
      },
      {
        id: 'm_l8',
        type: 'heading',
        text: 'EXT. GLASS VIEWPORT - SPECTRUM SWEEP'
      },
      {
        id: 'm_l9',
        type: 'action',
        text: 'An enormous, translucent bell-shaped entity floats past. Dozens of glowing filaments drift like neon spaghetti, barely avoiding the hull of the vessel.'
      },
      {
        id: 'm_l10',
        type: 'dialogue',
        characterName: 'NED',
        text: "Did you hear that sound, Steve? It was like a low-frequency hum. Is it calling out to us?",
        parenthetical: '(adjusting headphones)'
      },
      {
        id: 'm_l11',
        type: 'dialogue',
        characterName: 'STEVE',
        text: "No, Ned. It is calling to the jellyfish in sector four. They have highly structured social schedules.",
        parenthetical: '(smiling thinly)'
      },
      {
        id: 'm_l12',
        type: 'alert',
        text: 'The bathysphere electric grid fails temporarily. Only the phosphorus-dial instrumentation remains visible.'
      }
    ]
  },
  {
    id: 'peli_cove',
    title: 'Operation: Pelican Cove',
    location: 'GALAPAGOS ISLES',
    time: '0715 HRS',
    target: 'BEARDED PELICAN',
    clearanceLevel: 'LEVEL 2',
    metadataCode: 'LOG: 003-C // REC: MONO-TRACK',
    objectives: [
      { id: 'obj_p1', text: 'Anchor ship near the volcanic basalt rock.', checked: false },
      { id: 'obj_p2', text: 'Collect nesting dynamic feather samples.', checked: true },
      { id: 'obj_p3', text: 'Secure perimeter from rival cartographers.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'eleanor',
        name: 'SUBJECT_05: ZISSOU, ELEANOR',
        role: 'Chief Director of Science & Strategy',
        description: 'The real intelligence behind the society. Elegant, chain-smoker, highly skeptical of tactical choices.',
        notes: '>> Note: Retains operational safety override codes.',
        status: 'ACTIVE'
      },
      {
        id: 'hennessey',
        name: 'SUBJECT_06: ALISTAIR HENNESSEY',
        role: 'Rival Sea Explorer',
        description: 'Ex-husband of Eleanor. Impeccably dressed, heavily capitalized, commands a high-tech naval corvette.',
        notes: '>> Note: Claims Zissou stole his acoustic mapping blueprints.',
        status: 'CLASSIFIED'
      }
    ],
    scriptLines: [
      {
        id: 'p_l1',
        type: 'heading',
        text: 'EXT. VOLCANIC COVE - MORNING'
      },
      {
        id: 'p_l2',
        type: 'action',
        text: 'Thick sulfurous steam floats off the boiling shoreline. Eleanor stands on the rubber inflatable dinghy, holding a silver thermos flask.'
      },
      {
        id: 'p_l3',
        type: 'dialogue',
        characterName: 'ELEANOR',
        text: "Your coordinates are off by forty nautical yards, Alistair. As usual, your satellite compass is compensating for a lack of intuition.",
        parenthetical: '(staring across the bay)'
      },
      {
        id: 'p_l4',
        type: 'dialogue',
        characterName: 'HENNESSEY',
        text: "Nonsense, Eleanor. We have triple-redundant quartz clocks from Munich on this deck. The precision is unquestionable.",
        parenthetical: '(waving a dynamic gold watch)'
      },
      {
        id: 'p_l5',
        type: 'heading',
        text: 'EXT. ROCKY SHORELINE - PEBBLE PATH'
      },
      {
        id: 'p_l6',
        type: 'action',
        text: 'A flock of strange, gray-bearded seabirds waddles aggressively across the basalt rock. Steve watches them with intense suspicion.'
      },
      {
        id: 'p_l7',
        type: 'dialogue',
        characterName: 'ELEANOR',
        text: "Look at their postures, Alistair. They are completely unimpressed by your Munich quartz timing arrays.",
        parenthetical: '(puffing on a long cigarette)'
      },
      {
        id: 'p_l8',
        type: 'dialogue',
        characterName: 'HENNESSEY',
        text: "Perhaps. But they have excellent aerodynamic coefficient. I might buy two of these islands to construct a private sanctuary.",
        parenthetical: '(shrugging coolly)'
      },
      {
        id: 'p_l9',
        type: 'alert',
        text: 'A sudden territorial alarm sounds in the distance. An auxiliary helicopter from Hennessey’s fleet circles overhead.'
      }
    ]
  },
  {
    id: 'electric_eel',
    title: 'Operation: Electric Eel',
    location: 'AMAZON SEGMENT',
    time: '1200 HRS',
    target: 'VOLTAIC SERPENT',
    clearanceLevel: 'LEVEL 3',
    metadataCode: 'LOG: 004-D // REC: HIGH-FIDELITY',
    objectives: [
      { id: 'obj_e1', text: 'Insulate the submersible battery housings.', checked: true },
      { id: 'obj_e2', text: 'Document current discharges.', checked: false },
      { id: 'obj_e3', text: 'Do not handle creatures with wet gloves.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'pele',
        name: 'SUBJECT_07: PELE DOS SANTOS',
        role: 'Brazilian Safety Officer & Musician',
        description: 'Plays acoustic Portuguese versions of 70s rock classics. Unusually calm under extreme pressure.',
        notes: '>> Note: Refuses to wear standard safety shoes.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      {
        id: 'e_l1',
        type: 'heading',
        text: 'INT. SUBMERSIBLE ENGINE ROOM - MIDDAY'
      },
      {
        id: 'e_l2',
        type: 'action',
        text: 'Sparks fly from a rusty transformer. Pele quietly strums his acoustic guitar in the corner, ignoring the orange system warnings.'
      },
      {
        id: 'e_l3',
        type: 'dialogue',
        characterName: 'PELE',
        text: "The current is beautiful today. It has a high syncopated rhythm. But the insulation is melting.",
        parenthetical: '(laughing softly)'
      },
      {
        id: 'e_l4',
        type: 'heading',
        text: 'INT. MAIN PASSENGER DECK - CONTINUOUS'
      },
      {
        id: 'e_l5',
        type: 'action',
        text: 'A green warning lamp starts revolving. Steve enters, adjusting a rubber safety apron and carrying cardboard-wrapped copper rods.'
      },
      {
        id: 'e_l6',
        type: 'dialogue',
        characterName: 'STEVE',
        text: "Pele, stop that beautiful, melancholic song immediately. We need to ground this reactor before the voltaic monster discharges through our bilge pump.",
        parenthetical: ''
      },
      {
        id: 'e_l7',
        type: 'dialogue',
        characterName: 'PELE',
        text: "Yes, Captain. But the song was about a fish that traveled to Portugal to find its mother. It matches this swampy scenery perfectly.",
        parenthetical: '(stowing his wooden box)'
      },
      {
        id: 'e_l8',
        type: 'alert',
        text: 'An enormous blue spark arcs from the console panel, temporarily blinding the crew and turning all radar monitors to fuzzy noise.'
      }
    ]
  },
  {
    id: 'frostbite_base',
    title: 'Operation: Frostbite',
    location: 'SVALBARD OUTPOST',
    time: '0200 HRS',
    target: 'ARCTIC GLOW CRAB',
    clearanceLevel: 'LEVEL 4',
    metadataCode: 'LOG: 005-F // REC: MAGNETIC',
    objectives: [
      { id: 'obj_f1', text: 'Ignite the diesel generator heaters.', checked: true },
      { id: 'obj_f2', text: 'Melt ice samples with propane torch.', checked: false },
      { id: 'obj_f3', text: 'Keep tracking transceiver free of ice.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'vladimir',
        name: 'SUBJECT_08: VLADIMIR SOKOLOV',
        role: 'Hydrometeorology Consultant',
        description: 'Stoic, hates cold climates but stays for the research budget. Wears a heavy wolfskin jacket.',
        notes: '>> Note: Speaks exclusively in precise scientific measurements.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      {
        id: 'f_l1',
        type: 'heading',
        text: 'INT. ARCTIC RADAR HUT - DEAD OF NIGHT'
      },
      {
        id: 'f_l2',
        type: 'action',
        text: 'A ferocious wind rattles the corrugated metal sheets. Vladimir is meticulously filing a pencil with a small copper blade.'
      },
      {
        id: 'f_l3',
        type: 'dialogue',
        characterName: 'VLADIMIR',
        text: "The temperature has dropped another four point two degrees. The radar oil is freezing inside its casing.",
        parenthetical: '(without looking up)'
      },
      {
        id: 'f_l4',
        type: 'heading',
        text: 'EXT. SNOWPLANE RUNWAY - CONTINUOUS'
      },
      {
        id: 'f_l5',
        type: 'action',
        text: 'Flurries of dense arctic ice crystals sweep horizontally. Steve is struggling to erect a metal antenna mast, wearing a blue wool scarf.'
      },
      {
        id: 'f_l6',
        type: 'dialogue',
        characterName: 'STEVE',
        text: "Vladimir! Start the propane torch. My fingertips are completely numb, and the tracking needle is stuck at absolute zero!",
        parenthetical: '(shouting against the gale)'
      },
      {
        id: 'f_l7',
        type: 'dialogue',
        characterName: 'VLADIMIR',
        text: "Propane does not ignite cleanly at this altitude and humidity. We should use kerosene lamps from Sweden.",
        parenthetical: '(shaking a copper cylinder)'
      },
      {
        id: 'f_l8',
        type: 'alert',
        text: 'A loud arctic crack echoes down the fjord. A massive sheet of ice shelves into the freezing deep water with a thunderous roar.'
      }
    ]
  },
  {
    id: 'obsidian_vault',
    title: 'Operation: Obsidian Vault',
    location: 'SICILIAN RIFT',
    time: '1800 HRS',
    target: 'MAGMA ANEMONE',
    clearanceLevel: 'LEVEL 1',
    metadataCode: 'LOG: 006-G // REC: THERMAL',
    objectives: [
      { id: 'obj_o1', text: 'Calibrate high-temperature thermal glass.', checked: false },
      { id: 'obj_o2', text: 'Deliver volcanic rock core samples.', checked: false },
      { id: 'obj_o3', text: 'Activate emergency coolant pumps.', checked: true, isCritical: true }
    ],
    characters: [
      {
        id: 'steve_obs',
        name: 'SUBJECT_01: ZISSOU, STEVE',
        role: 'Lead Volcanologist Diver',
        description: 'Impatient. Reluctant to wear protective silver asbestos jumpsuits because they "itch".',
        notes: '>> Note: Claims lava currents are identical to deep reef patterns.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      {
        id: 'o_l1',
        type: 'heading',
        text: 'EXT. VOLCANIC CRATER RIM - SUNSET'
      },
      {
        id: 'o_l2',
        type: 'action',
        text: 'Red hot cinders fly into the warm evening air. Steve stands right at the edge of the direct caldera mouth, adjusting his goggles.'
      },
      {
        id: 'o_l3',
        type: 'dialogue',
        characterName: 'STEVE',
        text: "It looks very dramatic, Eleanor. Put some yellow lens filters on the central camera deck immediately.",
        parenthetical: '(coughing on volcanic ash)'
      },
      {
        id: 'o_l4',
        type: 'heading',
        text: 'INT. THERMAL PROTECTION CAPSULE - CONTINUOUS'
      },
      {
        id: 'o_l5',
        type: 'action',
        text: 'Orange smoke fills the tiny observation compartment. Steel-belted dials indicate temperatures reaching critical levels.'
      },
      {
        id: 'o_l6',
        type: 'dialogue',
        characterName: 'ELEANOR',
        text: "Your goggles are literally melting, Steve. If you do not activate the coolant spray, we will lose the main recording gear.",
        parenthetical: '(operating a brass regulator)'
      },
      {
        id: 'o_l7',
        type: 'dialogue',
        characterName: 'STEVE',
        text: "The recording gear is secondary to the visual narrative. We need to capture the exact pigment of that magma bloom.",
        parenthetical: '(wiping sweat)'
      },
      {
        id: 'o_l8',
        type: 'alert',
        text: 'The volcanic tremor intensifies, throwing loose lenses and recording film rolls across the iron deck.'
      }
    ]
  },
  {
    id: 'coconut_caper',
    title: 'Operation: Coconut Caper',
    location: 'MADAGASCAR SHORE',
    time: '1430 HRS',
    target: 'COCONUT ROBBER CRAB',
    clearanceLevel: 'LEVEL 2',
    metadataCode: 'LOG: 007-H // REC: PORTABLE',
    objectives: [
      { id: 'obj_c1', text: 'Lure robber crab with salted beef scraps.', checked: true },
      { id: 'obj_c2', text: 'Retrieve stolen radio transmitter casing.', checked: false },
      { id: 'obj_c3', text: 'Ensure compass dials do not get sand-logged.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'klaus_coconut',
        name: 'SUBJECT_03: DAIMLER, KLAUS',
        role: 'Isle Scout Leader',
        description: 'Armed with a miniature Swiss army knife and highly organized map cases.',
        notes: '>> Note: Constantly worried about camp hygiene.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      {
        id: 'c_l1',
        type: 'heading',
        text: 'EXT. MADAGASCAR JUNGLE EDGE - SUNNY'
      },
      {
        id: 'c_l2',
        type: 'action',
        text: 'A giant three-foot crab is carrying away a metallic tactical sonar transmitter. Klaus is pursuing it cautiously.'
      },
      {
        id: 'c_l3',
        type: 'dialogue',
        characterName: 'KLAUS',
        text: "Drop the machinery, you aggressive crustacean. It is official research society hardware!",
        parenthetical: '(pointing his wooden megaphone)'
      },
      {
        id: 'c_l4',
        type: 'heading',
        text: 'EXT. SAND DUNES - MINUTES LATER'
      },
      {
        id: 'c_l5',
        type: 'action',
        text: 'Steve watches from the rubber boat, eating salted peanut snacks while Klaus attempts a flanking dive maneuver.'
      },
      {
        id: 'c_l6',
        type: 'dialogue',
        characterName: 'STEVE',
        text: "Klaus! Try approaching from the side of the shell. Crabs have terrible lateral visibility. Use the peanut bag as a distraction.",
        parenthetical: '(chewing calmly)'
      },
      {
        id: 'c_l7',
        type: 'dialogue',
        characterName: 'KLAUS',
        text: "The crab does not want the salted peanuts, Steve! It is strangely attracted to our high-frequency magnetic compass dials!",
        parenthetical: '(running awkwardly on wet sand)'
      },
      {
        id: 'c_l8',
        type: 'alert',
        text: 'The crab clicks its colossal pincers, snapping a wooden measuring stick in half with an echoing crunch.'
      }
    ]
  },
  {
    id: 'pink_flamingo',
    title: 'Operation: Pink Flamingo',
    location: 'ANDES ALTIPIANO',
    time: '0800 HRS',
    target: 'SPIKED CHILEAN FLAMINGO',
    clearanceLevel: 'LEVEL 3',
    metadataCode: 'LOG: 008-I // REC: CHROMATIC',
    objectives: [
      { id: 'obj_fl1', text: 'Mount optical tracking tele-lens on tripod.', checked: false },
      { id: 'obj_fl2', text: 'Count salt lake sub-flocks.', checked: true },
      { id: 'obj_fl3', text: 'Avoid sudden movements that spook target.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'jane',
        name: 'SUBJECT_09: WINSLETT, JANE',
        role: 'Investigative Journalist',
        description: 'Sharp-eyed, writes for Oceanographic World. Asks deep, uncomfortable questions about budget anomalies.',
        notes: '>> Note: Keep notebook under surveillance.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      {
        id: 'fl_l1',
        type: 'heading',
        text: 'EXT. HIGH SALT LAGOON - MORNING'
      },
      {
        id: 'fl_l2',
        type: 'action',
        text: 'A flock of thousands of pink birds reflects perfectly on the motionless, salty water surface. Jane clicks her pen repeatedly.'
      },
      {
        id: 'fl_l3',
        type: 'dialogue',
        characterName: 'JANE',
        text: "Tell me, Steve. Does the public foundation realize you spent eighty thousand dollars on customized red cashmere beanies?",
        parenthetical: '(raising an eyebrow)'
      },
      {
        id: 'fl_l4',
        type: 'heading',
        text: 'EXT. TRIPOD STATION - OVERLOOK'
      },
      {
        id: 'fl_l5',
        type: 'action',
        text: 'Steve is adjusting a complex 35mm optical viewfinder while the high Andean wind whistles through his thin linen shirt.'
      },
      {
        id: 'fl_l6',
        type: 'dialogue',
        characterName: 'STEVE',
        text: "It was a critical team building expense, Jane. In oceanography, a cold head leads to fragmented scientific calculations.",
        parenthetical: '(adjusting focus dial)'
      },
      {
        id: 'fl_l7',
        type: 'dialogue',
        characterName: 'JANE',
        text: "And the customized leather-bound journal books for the crew? Was that also required to protect their scientific minds?",
        parenthetical: '(writing notes)'
      },
      {
        id: 'fl_l8',
        type: 'alert',
        text: 'The flamingos take flight simultaneously, creating a roaring pink vortex of wings and mud droplets against the clear blue sky.'
      }
    ]
  },
  {
    id: 'albatross_ridge',
    title: 'Operation: Albatross Ridge',
    location: 'FALKLAND REEFS',
    time: '1640 HRS',
    target: 'GREAT STORM ALBATROSS',
    clearanceLevel: 'LEVEL 2',
    metadataCode: 'LOG: 009-J // REC: WINDY',
    objectives: [
      { id: 'obj_ar1', text: 'Gauge gale-force wind shifts.', checked: true },
      { id: 'obj_ar2', text: 'Deploy thermal anemometer arrays.', checked: false },
      { id: 'obj_ar3', text: 'Lock down main deck sails and masts.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'anne',
        name: 'SUBJECT_10: ANNE-MARIE SAKOWITZ',
        role: 'Script Supervisor & Intern',
        description: 'Tired. Always has a pile of clipboards and polaroid cameras dangling from her neck.',
        notes: '>> Note: Unpaid position. Keep morale high via complimentary tea.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      {
        id: 'ar_l1',
        type: 'heading',
        text: 'EXT. BOW OF THE BELAFONTE - GALE WIND'
      },
      {
        id: 'ar_l2',
        type: 'action',
        text: 'Huge ocean waves crash right over the wooden deck rail. Anne-Marie is holding down a fluttering yellow script sheet.'
      },
      {
        id: 'ar_l3',
        type: 'dialogue',
        characterName: 'ANNE-MARIE',
        text: "The continuity is ruined, Captain! The wind blew Esteban's memorial scrapbook straight into the gray abyss!",
        parenthetical: '(screaming over the storm engine roar)'
      },
      {
        id: 'ar_l4',
        type: 'heading',
        text: 'INT. RADIO SHACK - CONTINUOUS'
      },
      {
        id: 'ar_l5',
        type: 'action',
        text: 'Heavy brass instruments sway back and forth as the vessel heels over at twenty degrees. Steve struggles to maintain his feet.'
      },
      {
        id: 'ar_l6',
        type: 'dialogue',
        characterName: 'STEVE',
        text: "Anne-Marie! Get me the backup logs immediately! We need to record the bird's flight trajectory before the weather deck is flooded.",
        parenthetical: ''
      },
      {
        id: 'ar_l7',
        type: 'dialogue',
        characterName: 'ANNE-MARIE',
        text: "I am literally holding onto the mast with my teeth, Steve! I cannot fetch folders in these meteorological conditions!",
        parenthetical: '(muffled by winds)'
      },
      {
        id: 'ar_l8',
        type: 'alert',
        text: 'An enormous white albatross sweeps past the bridge windows, its massive wingspan spanning eight feet of wet timber deck.'
      }
    ]
  },
  {
    id: 'mariana_sinkhole',
    title: 'Operation: Mariana Sinkhole',
    location: 'SINKHOLE ARCH',
    time: '0100 HRS',
    target: 'BLUE BOTTOM FEEDER',
    clearanceLevel: 'LEVEL 5',
    metadataCode: 'LOG: 010-K // REC: STATIC',
    objectives: [
      { id: 'obj_ms1', text: 'Initiate nuclear light beacons.', checked: false },
      { id: 'obj_ms2', text: 'Trace seismic sub-shore echoes.', checked: false },
      { id: 'obj_ms3', text: 'Retain contact with the deck transmitter.', checked: true, isCritical: true }
    ],
    characters: [
      {
        id: 'bose',
        name: 'SUBJECT_11: BOSE COSTELLO',
        role: 'Sound Recorder & Radio operator',
        description: 'Perpetually wearing oversized headphones. Speaks in a quiet whispering baritone.',
        notes: '>> Note: Claims he can hear the migration song of giant squids.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      {
        id: 'ms_l1',
        type: 'heading',
        text: 'INT. DEEPEST RADAR BAY - DEEP NIGHT'
      },
      {
        id: 'ms_l2',
        type: 'action',
        text: 'The sonar screen sweeps slow green sweeps. Bose tilts his head, listening to the static whistles on the radio receiver.'
      },
      {
        id: 'ms_l3',
        type: 'dialogue',
        characterName: 'BOSE COSTELLO',
        text: "It's not ocean noise, Steve. It's a structured code. They are humming classical symphonies down there.",
        parenthetical: '(holding speaker cone to his ear)'
      },
      {
        id: 'ms_l4',
        type: 'heading',
        text: 'INT. HELM CONSOLE - LATER'
      },
      {
        id: 'ms_l5',
        type: 'action',
        text: 'Steve Zissou stands behind Bose, slowly drinking cold black coffee from a chipped ceramic mug with the society logo.'
      },
      {
        id: 'ms_l6',
        type: 'dialogue',
        characterName: 'STEVE',
        text: "What kind of symphony? Beethoven? Or is it more of a modern synthesized beat? Be descriptive, Bose.",
        parenthetical: ''
      },
      {
        id: 'ms_l7',
        type: 'dialogue',
        characterName: 'BOSE COSTELLO',
        text: "It sounds like ancient nautical folk songs. Highly compressed by depth pressures. It's very beautiful, in an alarming way.",
        parenthetical: '(adjusting filters)'
      },
      {
        id: 'ms_l8',
        type: 'alert',
        text: 'A massive seismic shudder spikes the recording tape, sending ink needles scribbling in wild jagged lines on the graph rolls.'
      }
    ]
  },
  {
    id: 'blue_lagoon',
    title: 'Operation: Blue Lagoon',
    location: 'FIJI ARCHIPELAGO',
    time: '1500 HRS',
    target: 'SAPPHIRE REEF STAR',
    clearanceLevel: 'LEVEL 1',
    metadataCode: 'LOG: 011-L // REC: STEREO',
    objectives: [
      { id: 'obj_bl1', text: 'Deploy custom diving cages.', checked: true },
      { id: 'obj_bl2', text: 'Photograph underwater coral structures.', checked: false },
      { id: 'obj_bl3', text: 'Monitor oxygen levels continuously.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'diver_bill',
        name: 'SUBJECT_12: UYENO, BILL',
        role: 'Lead Combat Swimmer',
        description: 'Ex-military tactical advisor. Constantly sharpens knives on a leather strap.',
        notes: '>> Note: Speaks only when absolutely necessary.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      {
        id: 'bl_l1',
        type: 'heading',
        text: 'EXT. BLUE LAGOON REEF - AFTERNOON'
      },
      {
        id: 'bl_l2',
        type: 'action',
        text: 'Clear turquoise water shimmers. Bill checks his diving valves while standing in the yellow diving cage suspended from the derrick.'
      },
      {
        id: 'bl_l3',
        type: 'dialogue',
        characterName: 'BILL',
        text: "Oxygen is eighty percent. Corals are clean. Ready when you are, Captain.",
        parenthetical: '(nodding slowly)'
      },
      {
        id: 'bl_l4',
        type: 'heading',
        text: 'EXT. RESEARCH BOAT DECK - CONTINUOUS'
      },
      {
        id: 'bl_l5',
        type: 'action',
        text: 'Steve stands at the winch controls, wearing yellow rubber gloves and chewing on an unlit cigar tip.'
      },
      {
        id: 'bl_l6',
        type: 'dialogue',
        characterName: 'STEVE',
        text: "Lower the camera rigs first, Bill. I don't want you getting distracted by those sapphire starfish before we calibrate our primary exposure focus.",
        parenthetical: ''
      },
      {
        id: 'bl_l7',
        type: 'dialogue',
        characterName: 'BILL',
        text: "Understood. The fish are unusually calm today. They seem to be watching the derrick cords.",
        parenthetical: '(tightening straps)'
      },
      {
        id: 'bl_l8',
        type: 'alert',
        text: 'The cage chain grinds loudly against the iron spool. A sudden underwater shadow glides silently past the diving chamber.'
      }
    ]
  },
  {
    id: 'golden_octopus',
    title: 'Operation: Golden Octopus',
    location: 'CARIBBEAN RIDGE',
    time: '1000 HRS',
    target: 'AUREUM CEPHALOPOD',
    clearanceLevel: 'LEVEL 3',
    metadataCode: 'LOG: 012-M // REC: POLAROID',
    objectives: [
      { id: 'obj_go1', text: 'Secure waterproof polaroid film rolls.', checked: false },
      { id: 'obj_go2', text: 'Identify neon golden tentacles.', checked: false },
      { id: 'obj_go3', text: 'Avoid sharp coral protrusions.', checked: true, isCritical: true }
    ],
    characters: [
      {
        id: 'phillip',
        name: 'SUBJECT_13: PHILLIP COUDREAU',
        role: 'French Submarine Chef',
        description: 'Snobbish culinary artist. Insists on preparing five-course seafood meals in a tiny vessel kitchen.',
        notes: '>> Note: Often uses rare marine mosses as species seasoning.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      {
        id: 'go_l1',
        type: 'heading',
        text: 'INT. SUBMARINE GALLEY - MORNING'
      },
      {
        id: 'go_l2',
        type: 'action',
        text: 'Delicious steam wafts off a copper soup pot. Phillip is stirring it with a decorated silver fork.'
      },
      {
        id: 'go_l3',
        type: 'dialogue',
        characterName: 'PHILLIP',
        text: "The golden octopus is not a target for a spear, Steve. It is the crown jewel of our bouillabaisse menu!",
        parenthetical: '(raising white chef hat)'
      },
      {
        id: 'go_l4',
        type: 'heading',
        text: 'INT. MAIN OBSERVATION COCKPIT - CONTINUOUS'
      },
      {
        id: 'go_l5',
        type: 'action',
        text: 'Steve stands in front of a curved glass dashboard, staring through a magnifying eyepiece at the coral wall.'
      },
      {
        id: 'go_l6',
        type: 'dialogue',
        characterName: 'STEVE',
        text: "Philip, this is a scientific survey, not a Michelin restaurant cruise. We are here to photograph and catalogue, not to sauté.",
        parenthetical: '(tapping the glass)'
      },
      {
        id: 'go_l7',
        type: 'dialogue',
        characterName: 'PHILLIP',
        text: "Sautéing *is* science, Captain. The way the golden skin crisps in olive oil requires precise thermal alignment!",
        parenthetical: '(waving a dynamic iron spoon)'
      },
      {
        id: 'go_l8',
        type: 'alert',
        text: 'A loud suction scrape sound clicks on the viewport outer glass as a golden tentacle covers the camera lens array.'
      }
    ]
  },
  {
    id: 'tiger_shark_1',
    title: 'Operation: Tiger Shark - Phase I',
    location: 'CORAL SEA',
    time: '0600 HRS',
    target: 'TIGER SHARK OF NEON DEPTHS',
    clearanceLevel: 'LEVEL 4',
    metadataCode: 'LOG: 013-T1 // REC: MONO',
    objectives: [
      { id: 'obj_t1_1', text: 'Map the entry vector of the shallow sandbars.', checked: true },
      { id: 'obj_t1_2', text: 'Calibrate the underwater optical filters.', checked: false },
      { id: 'obj_t1_3', text: 'Engage sub-surface radio link.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'steve',
        name: 'SUBJECT_01: ZISSOU, STEVE',
        role: 'Oceanographer & Expedition Leader',
        description: 'Obsessed with large predatory marine life.',
        notes: '>> Note: Claims he can track stripes by eye.',
        status: 'ACTIVE'
      },
      {
        id: 'klaus',
        name: 'SUBJECT_03: DAIMLER, KLAUS',
        role: 'First Mate',
        description: 'Protective first mate.',
        notes: '>> Note: Preoccupied with supply inventories.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      { id: 't1_l1', type: 'heading', text: 'EXT. BELAFONTE FOREDECK - SUNRISE' },
      { id: 't1_l2', type: 'action', text: 'Pale orange sunlight reflects off the stainless steel winches. Steve stands with his foot on the direct gunwale rails, looking through a retro brass scope.' },
      { id: 't1_l3', type: 'dialogue', characterName: 'STEVE', text: "Klaus, look at those turquoise ripples. They are perfect for a classic 70s scope sweep. Set up the camera deck immediately.", parenthetical: '(pointing with a half-eaten carrot)' },
      { id: 't1_l4', type: 'dialogue', characterName: 'KLAUS', text: "The camera is still moist from yesterday's rain, Steve. We should wait for the lens elements to dry.", parenthetical: '(wiping a bronze wrench)' },
      { id: 't1_l5', type: 'dialogue', characterName: 'STEVE', text: "Lenses do not dry by waiting, Klaus. They dry by action. Ready the dinghy.", parenthetical: '' },
      { id: 't1_l6', type: 'alert', text: 'A splash sounds near the anchor chain, scattering a flock of seagulls into the clear orange sky.' }
    ]
  },
  {
    id: 'tiger_shark_2',
    title: 'Operation: Tiger Shark - Phase II',
    location: 'CORAL RIFT',
    time: '0830 HRS',
    target: 'TIGER SHARK OF NEON DEPTHS',
    clearanceLevel: 'LEVEL 4',
    metadataCode: 'LOG: 014-T2 // REC: HIGH-FIDELITY',
    objectives: [
      { id: 'obj_t2_1', text: 'Assemble the heavy dynamic harpoon.', checked: true },
      { id: 'obj_t2_2', text: 'Check the safety clips on the winch.', checked: true },
      { id: 'obj_t2_3', text: 'Test underwater acoustic microphone.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'klaus',
        name: 'SUBJECT_03: DAIMLER, KLAUS',
        role: 'First Mate',
        description: 'Prone to fits of organizational discipline.',
        notes: '>> Note: Claims he double-checked all clips.',
        status: 'ACTIVE'
      },
      {
        id: 'pele',
        name: 'SUBJECT_07: PELE DOS SANTOS',
        role: 'Safety Officer & Musician',
        description: 'Plays acoustic Portuguese rock.',
        notes: '>> Note: Humourous disposition.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      { id: 't2_l1', type: 'heading', text: 'INT. BELAFONTE MACHINE SHOP - MORNING' },
      { id: 't2_l2', type: 'action', text: 'A single neon tube flickers overhead. Klaus is meticulously filing a long, notched iron bolt while Pele hums on a five-string guitar.' },
      { id: 't2_l3', type: 'dialogue', characterName: 'KLAUS', text: "If Steve thinks he can spear a twenty-foot striped shark with a twelve-gauge iron spike, he is completely out of his scientific mind.", parenthetical: '(blowing metal dust off)' },
      { id: 't2_l4', type: 'dialogue', characterName: 'PELE', text: "But the spike is beautiful, Klaus. It has an excellent heavy balance. It is also very photographic.", parenthetical: '(tuning a peg)' },
      { id: 't2_l5', type: 'dialogue', characterName: 'KLAUS', text: "Science is not photographic, Pele! Science is systematic calculation!", parenthetical: '(scowling)' },
      { id: 't2_l6', type: 'alert', text: 'The intercom speaker crackles to life on the gray wooden wall with high-pitched static.' }
    ]
  },
  {
    id: 'tiger_shark_3',
    title: 'Operation: Tiger Shark - Phase III',
    location: 'CORAL SHELF',
    time: '1015 HRS',
    target: 'TIGER SHARK OF NEON DEPTHS',
    clearanceLevel: 'LEVEL 4',
    metadataCode: 'LOG: 015-T3 // REC: MAGNETIC',
    objectives: [
      { id: 'obj_t3_1', text: 'Trace Sonar frequency static.', checked: false },
      { id: 'obj_t3_2', text: 'Determine temperature boundary layers.', checked: true },
      { id: 'obj_t3_3', text: 'Verify navigation dial synchronization.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'steve',
        name: 'SUBJECT_01: ZISSOU, STEVE',
        role: 'Oceanographer',
        description: 'Restless leader.',
        notes: '>> Note: Dislikes repetitive sonar beeps.',
        status: 'ACTIVE'
      },
      {
        id: 'bose',
        name: 'SUBJECT_11: BOSE COSTELLO',
        role: 'Sound Recorder',
        description: 'Hears fine frequencies.',
        notes: '>> Note: Claims he hears the seabed creaking.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      { id: 't3_l1', type: 'heading', text: 'INT. SONAR CABIN - BRIGHT DAY' },
      { id: 't3_l2', type: 'action', text: 'An ancient oscilloscope displays a glowing green pulse. Bose wears heavy padded leather headphones, listening to the oceanic sweep.' },
      { id: 't3_l3', type: 'dialogue', characterName: 'STEVE', text: "Give me the numbers, Bose. Are you hearing the low register hum of the stripes? Or is it just ambient tide noise?", parenthetical: '(leaning over the console)' },
      { id: 't3_l4', type: 'dialogue', characterName: 'BOSE COSTELLO', text: "It's a rhythmic vibration, Captain. Like a big piston moving at sixteen beats per minute. That shark has a very powerful heart.", parenthetical: '(squinting)' },
      { id: 't3_l5', type: 'dialogue', characterName: 'STEVE', text: "That is not cardiac rhythm, Bose. That is the creature tail fin sweeping parallel currents.", parenthetical: '' },
      { id: 't3_l6', type: 'alert', text: 'An intense high-frequency squeal resonates from the speaker cone, causing both men to cover their ears.' }
    ]
  },
  {
    id: 'tiger_shark_4',
    title: 'Operation: Tiger Shark - Phase IV',
    location: 'CORAL ATILLO',
    time: '1130 HRS',
    target: 'TIGER SHARK OF NEON DEPTHS',
    clearanceLevel: 'LEVEL 4',
    metadataCode: 'LOG: 016-T4 // REC: MONO-TRACK',
    objectives: [
      { id: 'obj_t4_1', text: 'Document acoustic calming melodies.', checked: true },
      { id: 'obj_t4_2', text: 'Deploy the floating cork indicators.', checked: false },
      { id: 'obj_t4_3', text: 'Ensure engine exhaust is buffered.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'pele',
        name: 'SUBJECT_07: PELE DOS SANTOS',
        role: 'Safety Officer & Musician',
        description: 'Brazilian officer, plays melancholic rock classics.',
        notes: '>> Note: Excellent musical repertoire.',
        status: 'ACTIVE'
      },
      {
        id: 'steve',
        name: 'SUBJECT_01: ZISSOU, STEVE',
        role: 'Captain',
        description: 'Loves music but hates delays.',
        notes: '>> Note: Drinks black tea during acoustic recitals.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      { id: 't4_l1', type: 'heading', text: 'EXT. STERN OF THE BELAFONTE - NOON' },
      { id: 't4_l2', type: 'action', text: 'The sea is glassy and calm. Pele sits on a yellow wooden crate, strumming a gentle Bossa Nova tune. Steve stands near, tapping a silver spoon on his cup.' },
      { id: 't4_l3', type: 'dialogue', characterName: 'PELE', text: "The song is about a fish who wished for wings, Captain. It is very popular in Salvador. It reminds the shark of comfortable things.", parenthetical: '(singing in Portuguese)' },
      { id: 't4_l4', type: 'dialogue', characterName: 'STEVE', text: "I do not think the shark speaks Portuguese, Pele. But the tempo is very pleasing. Keep playing until we hit the deep trench.", parenthetical: '(shading his eyes)' },
      { id: 't4_l5', type: 'dialogue', characterName: 'PELE', text: "The music is a universal frequency, Captain. Even stripes can feel the syncopation.", parenthetical: '' },
      { id: 't4_l6', type: 'alert', text: 'A long bubble slick appears parallel to the boat, moving in a perfect straight trajectory.' }
    ]
  },
  {
    id: 'tiger_shark_5',
    title: 'Operation: Tiger Shark - Phase V',
    location: 'RIVAL BOUNDARY',
    time: '1300 HRS',
    target: 'TIGER SHARK OF NEON DEPTHS',
    clearanceLevel: 'LEVEL 5',
    metadataCode: 'LOG: 017-T5 // REC: TRANSCRIPT',
    objectives: [
      { id: 'obj_t5_1', text: 'Monitor the rival high-tech naval corvette.', checked: true },
      { id: 'obj_t5_2', text: 'Refuse Hennessey’s tracking proposals.', checked: true },
      { id: 'obj_t5_3', text: 'Keep our blueprint map cases locked.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'eleanor',
        name: 'SUBJECT_05: ZISSOU, ELEANOR',
        role: 'Director of Strategy',
        description: 'Calculating strategian.',
        notes: '>> Note: Distrusts Alistair Hennessey completely.',
        status: 'ACTIVE'
      },
      {
        id: 'hennessey',
        name: 'SUBJECT_06: ALISTAIR HENNESSEY',
        role: 'Rival Sea Explorer',
        description: 'Rich, arrogant rival traveler.',
        notes: '>> Note: Commands the high-tech mapping yacht.',
        status: 'CLASSIFIED'
      }
    ],
    scriptLines: [
      { id: 't5_l1', type: 'heading', text: 'EXT. MID-EASTERN BOUNDARY REEF - MIDDAY' },
      { id: 't5_l2', type: 'action', text: 'A high-speed white Yacht with twin radar dishes cruises alongside. Alistair Hennessey talks through an ivory-handled loud-hailer.' },
      { id: 't5_l3', type: 'dialogue', characterName: 'HENNESSEY', text: "Steve! I hear you are hunting the giant striped anomaly with 1940s mine-sweeper gears! Would you like to lease our digital mapping array? Friendly rate!", parenthetical: '(laughing with sparkling teeth)' },
      { id: 't5_l4', type: 'dialogue', characterName: 'ELEANOR', text: "Ignore him, Steve. His digital mapping array is a proprietary disaster that crash-loops every eighteen nautical miles.", parenthetical: '(smoking calmly)' },
      { id: 't5_l5', type: 'dialogue', characterName: 'HENNESSEY', text: "ELEANOR! My beloved strategist! Do not be so harsh! The Munich quartz clocks are functioning perfectly today!", parenthetical: '' },
      { id: 't5_l6', type: 'alert', text: 'A loud automatic mechanical bell sounds from Hennessey’s yacht, indicating a satellite ping sequence.' }
    ]
  },
  {
    id: 'tiger_shark_6',
    title: 'Operation: Tiger Shark - Phase VI',
    location: 'TIGER CANYON',
    time: '1430 HRS',
    target: 'TIGER SHARK OF NEON DEPTHS',
    clearanceLevel: 'LEVEL 4',
    metadataCode: 'LOG: 018-T6 // REC: COMPACT',
    objectives: [
      { id: 'obj_t6_1', text: 'Calibrate diving bell pressure hatches.', checked: false },
      { id: 'obj_t6_2', text: 'Deploy the backup heavy anchors.', checked: true },
      { id: 'obj_t6_3', text: 'Secure oxygen manifold balance.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'steve',
        name: 'SUBJECT_01: ZISSOU, STEVE',
        role: 'Expedition Pilot',
        description: 'Impatient about deep tests.',
        notes: '>> Note: Claims he can breathe shallow under pressure offsets.',
        status: 'ACTIVE'
      },
      {
        id: 'klaus',
        name: 'SUBJECT_03: DAIMLER, KLAUS',
        role: 'First Mate & Safety Lead',
        description: 'Constantly checks heavy brass valves.',
        notes: '>> Note: Weary of Steve’s fast-track maneuvers.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      { id: 't6_l1', type: 'heading', text: 'INT. BELAFONTE REAR DECK - CRANE BAY' },
      { id: 't6_l2', type: 'action', text: 'A heavy yellow steel diving chamber oscillates on a thick hemp cable. Klaus is checking the rubber hatch gaskets with a dynamic greasy finger.' },
      { id: 't6_l3', type: 'dialogue', characterName: 'KLAUS', text: "The gasket has a micro-fracture, Steve. We cannot submerge this chamber beyond two hundred atmospheres unless we seal it with rubber grease.", parenthetical: '(showing grease smudge)' },
      { id: 't6_l4', type: 'dialogue', characterName: 'STEVE', text: "Apply the grease, Klaus! We do not have three hours to wait for an industrial inspection. The neon tiger is on the move down there.", parenthetical: '(putting on a yellow wetsuit)' },
      { id: 't6_l5', type: 'dialogue', characterName: 'KLAUS', text: "If we leak, Steve... your screenplay ends in a very damp, dark underwater sequence.", parenthetical: '' },
      { id: 't6_l6', type: 'alert', text: 'A loud clanking sound echoes off the steel hull as the winch brake slips two inches.' }
    ]
  },
  {
    id: 'tiger_shark_7',
    title: 'Operation: Tiger Shark - Phase VII',
    location: 'DEEP COVE SHIFT',
    time: '1545 HRS',
    target: 'TIGER SHARK OF NEON DEPTHS',
    clearanceLevel: 'LEVEL 4',
    metadataCode: 'LOG: 019-T7 // REC: LO-FI',
    objectives: [
      { id: 'obj_t7_1', text: 'Prepare pickling sardine bait baskets.', checked: true },
      { id: 'obj_t7_2', text: 'Mount underwater flood lights.', checked: false },
      { id: 'obj_t7_3', text: 'Ensure shark cages are locked to secondary cables.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'phillip',
        name: 'SUBJECT_13: PHILLIP COUDREAU',
        role: 'French Submarine Chef',
        description: 'Snobbish culinary artist.',
        notes: '>> Note: Furious that Steve is using high-grade fish for bait.',
        status: 'ACTIVE'
      },
      {
        id: 'steve',
        name: 'SUBJECT_01: ZISSOU, STEVE',
        role: 'Captain',
        description: 'Prefers dynamic action.',
        notes: '>> Note: Claims fish heads are the perfect olfactory tracker.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      { id: 't7_l1', type: 'heading', text: 'INT. BELAFONTE GALLEY - AFTERNOON' },
      { id: 't7_l2', type: 'action', text: 'A strong smell of garlic and vinegar fills the tiny space. Phillip watches in absolute disgust as Steve stuffs three vintage copper cans of pickled sardines into an iron wire mesh bait bucket.' },
      { id: 't7_l3', type: 'dialogue', characterName: 'PHILLIP', text: "This is premium imported French seafood, Captain! It was meant for the opening night gala in Rome! You are throwing cultural treasure to a mindless striped fish!", parenthetical: '(waving a silver tongs)' },
      { id: 't7_l4', type: 'dialogue', characterName: 'STEVE', text: "The Rome gala was canceled three weeks ago because the budget was frozen, Philip. Now, this seafood is a powerful scientific olfactory luring agent.", parenthetical: '(clamping the bucket lid)' },
      { id: 't7_l5', type: 'dialogue', characterName: 'PHILLIP', text: "It is an culinary outrage. My ancestors are weeping in Paris.", parenthetical: '' },
      { id: 't7_l6', type: 'alert', text: 'The vessel lists heavily to port as a massive underwater ripple sweeps beneath the hull.' }
    ]
  },
  {
    id: 'tiger_shark_8',
    title: 'Operation: Tiger Shark - Phase VIII',
    location: 'SINKING TRENCH',
    time: '1700 HRS',
    target: 'TIGER SHARK OF NEON DEPTHS',
    clearanceLevel: 'LEVEL 4',
    metadataCode: 'LOG: 020-T8 // REC: MAGNETIC',
    objectives: [
      { id: 'obj_t8_1', text: 'Reach the 500-meter threshold.', checked: true },
      { id: 'obj_t8_2', text: 'Verify thermal insulation jacket.', checked: false },
      { id: 'obj_t8_3', text: 'Avoid internal glass viewport strain.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'steve_abyss',
        name: 'SUBJECT_01: ZISSOU, STEVE',
        role: 'Sub Pilot',
        description: 'Unmoved by structural strain noises.',
        notes: '>> Note: Continues to chew on unlit cigar.',
        status: 'ACTIVE'
      },
      {
        id: 'ned',
        name: 'SUBJECT_04: PLIMPTON, NED',
        role: 'Co-Pilot & Companion',
        description: 'Southern explorer, extremely focused.',
        notes: '>> Note: Taps the analog dial gauge recursively.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      { id: 't8_l1', type: 'heading', text: 'INT. SUBMERSIBLE PILOTING CAPSULE - TWILIGHT' },
      { id: 't8_l2', type: 'action', text: 'Heavy iron rivets creak under depth. Outside, the water is a deep, leaden gray-blue. A single yellow dial glow illuminates Steve’s leather-gloved hands steering the control stick.' },
      { id: 't8_l3', type: 'dialogue', characterName: 'NED', text: "Hull strain indicators are approaching eighty percent, Steve. The vertical hydroplanes are sluggish. The pressure down here is beautiful, but deadly.", parenthetical: '(squinting out)' },
      { id: 't8_l4', type: 'dialogue', characterName: 'STEVE', text: "Sluggish is normal for this model, Ned. It was refitted in Hamburg during the late sixties. Just keep the oxygen balance at eighteen percent.", parenthetical: '(adjusting fuel throttle)' },
      { id: 't8_l5', type: 'dialogue', characterName: 'NED', text: "I have a strange feeling we are not the only vessel descending into this trench today.", parenthetical: '' },
      { id: 't8_l6', type: 'alert', text: 'A low-register acoustic ping reverberates through the steel dome, repeating every three seconds.' }
    ]
  },
  {
    id: 'tiger_shark_9',
    title: 'Operation: Tiger Shark - Phase IX',
    location: 'SHADOW ARCHIPELAGO',
    time: '1830 HRS',
    target: 'TIGER SHARK OF NEON DEPTHS',
    clearanceLevel: 'LEVEL 4',
    metadataCode: 'LOG: 021-T9 // REC: HI-FI',
    objectives: [
      { id: 'obj_t9_1', text: 'Trace giant shadow on the sonar sensor spectrum.', checked: false },
      { id: 'obj_t9_2', text: 'Deploy the optical beacon flares.', checked: true },
      { id: 'obj_t9_3', text: 'Confirm camera power pack charge.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'bose',
        name: 'SUBJECT_11: BOSE COSTELLO',
        role: 'Radio Officer',
        description: 'Detects deep signals.',
        notes: '>> Note: Weary of signal ghosts.',
        status: 'ACTIVE'
      },
      {
        id: 'steve',
        name: 'SUBJECT_01: ZISSOU, STEVE',
        role: 'Expedition commander',
        description: 'Determined to document.',
        notes: '>> Note: Keeps hand on camera toggle switch.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      { id: 't9_l1', type: 'heading', text: 'INT. DECK CONTROL CABIN - NIGHT' },
      { id: 't9_l2', type: 'action', text: 'Pitch blackness surrounds the console. The green sonar sweeps highlight a massive, twenty-five foot elongated silhouette standing motionless near the trench ridge.' },
      { id: 't9_l3', type: 'dialogue', characterName: 'BOSE COSTELLO', text: "It is hovering, Captain. No movement for forty seconds. It has locked onto our sonar emitter signal frequency.", parenthetical: '(adjusting high-frequency knobs)' },
      { id: 't9_l4', type: 'dialogue', characterName: 'STEVE', text: "Turn off the active pinger, Bose! Switch to passive capture mode. We do not want to scare him with artificial high frequencies.", parenthetical: '(leaning close to radar screen)' },
      { id: 't9_l5', type: 'dialogue', characterName: 'BOSE COSTELLO', text: "The signal is switching to a double octave. It sounds almost like an engine hum. Is Alistair Hennessey trailing us?", parenthetical: '' },
      { id: 't9_l6', type: 'alert', text: 'An enormous white spotlight flashes in the deep water, highlighting Hennessey’s yellow submarine cruising past.' }
    ]
  },
  {
    id: 'tiger_shark_10',
    title: 'Operation: Tiger Shark - Phase X',
    location: 'SHARK SANCTUARY',
    time: '2000 HRS',
    target: 'TIGER SHARK OF NEON DEPTHS',
    clearanceLevel: 'LEVEL 5',
    metadataCode: 'LOG: 022-T10 // REC: HIGH-FIDELITY',
    objectives: [
      { id: 'obj_t10_1', text: 'Photograph the neon stripes close-up.', checked: false },
      { id: 'obj_t10_2', text: 'Ensure the acoustic recorder is functional.', checked: true },
      { id: 'obj_t10_3', text: 'Secure crew retreat vector.', checked: false, isCritical: true }
    ],
    characters: [
      {
        id: 'steve_abyss',
        name: 'SUBJECT_01: ZISSOU, STEVE',
        role: 'Oceanographer & Explorer',
        description: 'Finally face-to-face with his legendary target.',
        notes: '>> Note: Highly emotional sub-surface interaction.',
        status: 'ACTIVE'
      },
      {
        id: 'ned',
        name: 'SUBJECT_04: PLIMPTON, NED',
        role: 'Co-Pilot & Companion',
        description: 'Observant, quiet, watching the viewport.',
        notes: '>> Note: Confirms target size is unprecedented.',
        status: 'ACTIVE'
      }
    ],
    scriptLines: [
      { id: 't10_l1', type: 'heading', text: 'INT. DEEP REEF CAVERN - NIGHT' },
      { id: 't10_l2', type: 'action', text: 'A massive, glowing Tiger Shark cruises slowly into the high-power spotlight beam. Its skin is patterned with luminescent, neon-yellow stripes. Its eye is dark, reflecting the vessel lights.' },
      { id: 't10_l3', type: 'dialogue', characterName: 'STEVE', text: "Look at him, Ned. He is completely magnificent. No malice. Just a golden, structured organism moving through the silent dark.", parenthetical: '(tears welling slightly in eyes)' },
      { id: 't10_l4', type: 'dialogue', characterName: 'NED', text: "He is beautiful, Steve. Did you bring the Polaroid camera? The color spectrum is fading fast.", parenthetical: '(smiling gently)' },
      { id: 't10_l5', type: 'dialogue', characterName: 'STEVE', text: "No, Ned. This shot is the screenplays mental preservation. It does not require film rolls to exist.", parenthetical: '' },
      { id: 't10_l6', type: 'alert', text: 'The neon tiger shark sweeps its massive tail, turning slowly back into the vast blue-black void of the ocean canyon.' }
    ]
  }
];
